﻿namespace CarRentSys
{
    partial class frmMakeRental
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Cost = new Label();
            lblEquip = new Label();
            grpCustInfo = new GroupBox();
            txtSurname = new TextBox();
            Surname = new Label();
            btnAddCust = new Button();
            txtForename = new TextBox();
            txtLicence = new TextBox();
            txtEmail = new TextBox();
            Forename = new Label();
            txtPhoneNum = new TextBox();
            LicenceNumber = new Label();
            Email = new Label();
            PhoneNumber = new Label();
            btnPay = new Button();
            lblRentalNum = new Label();
            txtRentNum = new TextBox();
            txtCustID = new TextBox();
            lblCustID = new Label();
            txtStatus = new TextBox();
            lblStatus = new Label();
            grpRental = new GroupBox();
            cboTimeTo = new ComboBox();
            cboTimeFrom = new ComboBox();
            dateReturn = new DateTimePicker();
            dateStart = new DateTimePicker();
            btnCarSearch = new Button();
            lblReturnTime = new Label();
            lblReturnDate = new Label();
            lblRebtStartTime = new Label();
            lblstartDate = new Label();
            cboCarTypes = new ComboBox();
            label2 = new Label();
            grpCars = new GroupBox();
            grpRentalCosts = new GroupBox();
            txtRegNum = new TextBox();
            lblRegNum = new Label();
            txtTotalCost = new TextBox();
            label3 = new Label();
            grdAvailableCars = new DataGridView();
            chkBoxEquip = new CheckBox();
            grpEquip = new GroupBox();
            grpEquipInfo = new GroupBox();
            txtEquipmentID = new TextBox();
            label1 = new Label();
            txtFullCost = new TextBox();
            label4 = new Label();
            btnSearchEquipment = new Button();
            grdAvailableEquip = new DataGridView();
            grpEquipCheck = new GroupBox();
            grpRentalPay = new GroupBox();
            grpCustInfo.SuspendLayout();
            grpRental.SuspendLayout();
            grpCars.SuspendLayout();
            grpRentalCosts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdAvailableCars).BeginInit();
            grpEquip.SuspendLayout();
            grpEquipInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdAvailableEquip).BeginInit();
            grpEquipCheck.SuspendLayout();
            grpRentalPay.SuspendLayout();
            SuspendLayout();
            // 
            // Cost
            // 
            Cost.AutoSize = true;
            Cost.Location = new Point(696, 53);
            Cost.Margin = new Padding(6, 0, 6, 0);
            Cost.Name = "Cost";
            Cost.Size = new Size(0, 32);
            Cost.TabIndex = 8;
            // 
            // lblEquip
            // 
            lblEquip.AutoSize = true;
            lblEquip.Location = new Point(0, 49);
            lblEquip.Margin = new Padding(6, 0, 6, 0);
            lblEquip.Name = "lblEquip";
            lblEquip.Size = new Size(130, 32);
            lblEquip.TabIndex = 36;
            lblEquip.Text = "Equipment";
            // 
            // grpCustInfo
            // 
            grpCustInfo.Controls.Add(txtSurname);
            grpCustInfo.Controls.Add(Surname);
            grpCustInfo.Controls.Add(btnAddCust);
            grpCustInfo.Controls.Add(txtForename);
            grpCustInfo.Controls.Add(txtLicence);
            grpCustInfo.Controls.Add(txtEmail);
            grpCustInfo.Controls.Add(Forename);
            grpCustInfo.Controls.Add(txtPhoneNum);
            grpCustInfo.Controls.Add(LicenceNumber);
            grpCustInfo.Controls.Add(Email);
            grpCustInfo.Controls.Add(PhoneNumber);
            grpCustInfo.Location = new Point(1171, 548);
            grpCustInfo.Margin = new Padding(6);
            grpCustInfo.Name = "grpCustInfo";
            grpCustInfo.Padding = new Padding(6);
            grpCustInfo.Size = new Size(865, 435);
            grpCustInfo.TabIndex = 39;
            grpCustInfo.TabStop = false;
            grpCustInfo.Text = "Customer Information";
            grpCustInfo.Visible = false;
            // 
            // txtSurname
            // 
            txtSurname.Location = new Point(444, 60);
            txtSurname.Margin = new Padding(6);
            txtSurname.MaxLength = 30;
            txtSurname.Name = "txtSurname";
            txtSurname.Size = new Size(162, 39);
            txtSurname.TabIndex = 13;
            // 
            // Surname
            // 
            Surname.AutoSize = true;
            Surname.Location = new Point(332, 66);
            Surname.Margin = new Padding(6, 0, 6, 0);
            Surname.Name = "Surname";
            Surname.Size = new Size(109, 32);
            Surname.TabIndex = 12;
            Surname.Text = "Surname";
            // 
            // btnAddCust
            // 
            btnAddCust.ForeColor = SystemColors.Highlight;
            btnAddCust.Location = new Point(0, 326);
            btnAddCust.Margin = new Padding(6);
            btnAddCust.Name = "btnAddCust";
            btnAddCust.Size = new Size(865, 102);
            btnAddCust.TabIndex = 11;
            btnAddCust.Text = "Add customer";
            btnAddCust.UseVisualStyleBackColor = true;
            btnAddCust.Click += btnAddCust_Click;
            // 
            // txtForename
            // 
            txtForename.Location = new Point(124, 53);
            txtForename.Margin = new Padding(6);
            txtForename.MaxLength = 30;
            txtForename.Name = "txtForename";
            txtForename.Size = new Size(162, 39);
            txtForename.TabIndex = 11;
            // 
            // txtLicence
            // 
            txtLicence.Location = new Point(186, 252);
            txtLicence.Margin = new Padding(6);
            txtLicence.MaxLength = 9;
            txtLicence.Name = "txtLicence";
            txtLicence.Size = new Size(260, 39);
            txtLicence.TabIndex = 7;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(78, 192);
            txtEmail.Margin = new Padding(6);
            txtEmail.MaxLength = 30;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(357, 39);
            txtEmail.TabIndex = 6;
            // 
            // Forename
            // 
            Forename.AutoSize = true;
            Forename.Location = new Point(0, 60);
            Forename.Margin = new Padding(6, 0, 6, 0);
            Forename.Name = "Forename";
            Forename.Size = new Size(121, 32);
            Forename.TabIndex = 0;
            Forename.Text = "Forename";
            // 
            // txtPhoneNum
            // 
            txtPhoneNum.Location = new Point(175, 124);
            txtPhoneNum.Margin = new Padding(6);
            txtPhoneNum.MaxLength = 12;
            txtPhoneNum.Name = "txtPhoneNum";
            txtPhoneNum.Size = new Size(260, 39);
            txtPhoneNum.TabIndex = 5;
            // 
            // LicenceNumber
            // 
            LicenceNumber.AutoSize = true;
            LicenceNumber.Location = new Point(0, 269);
            LicenceNumber.Margin = new Padding(6, 0, 6, 0);
            LicenceNumber.Name = "LicenceNumber";
            LicenceNumber.Size = new Size(188, 32);
            LicenceNumber.TabIndex = 2;
            LicenceNumber.Text = "Licence Number";
            // 
            // Email
            // 
            Email.AutoSize = true;
            Email.Location = new Point(0, 203);
            Email.Margin = new Padding(6, 0, 6, 0);
            Email.Name = "Email";
            Email.Size = new Size(71, 32);
            Email.TabIndex = 1;
            Email.Text = "Email";
            // 
            // PhoneNumber
            // 
            PhoneNumber.AutoSize = true;
            PhoneNumber.Location = new Point(0, 130);
            PhoneNumber.Margin = new Padding(6, 0, 6, 0);
            PhoneNumber.Name = "PhoneNumber";
            PhoneNumber.Size = new Size(177, 32);
            PhoneNumber.TabIndex = 0;
            PhoneNumber.Text = "Phone Number";
            // 
            // btnPay
            // 
            btnPay.ForeColor = SystemColors.Highlight;
            btnPay.Location = new Point(0, 31);
            btnPay.Margin = new Padding(6);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(1179, 118);
            btnPay.TabIndex = 40;
            btnPay.Text = "Pay for rental";
            btnPay.UseVisualStyleBackColor = true;
            btnPay.Click += btnPay_Click_1;
            // 
            // lblRentalNum
            // 
            lblRentalNum.AutoSize = true;
            lblRentalNum.Location = new Point(0, 233);
            lblRentalNum.Margin = new Padding(6, 0, 6, 0);
            lblRentalNum.Name = "lblRentalNum";
            lblRentalNum.Size = new Size(175, 32);
            lblRentalNum.TabIndex = 41;
            lblRentalNum.Text = "Rental Number";
            // 
            // txtRentNum
            // 
            txtRentNum.Location = new Point(173, 222);
            txtRentNum.Margin = new Padding(6);
            txtRentNum.MaxLength = 9;
            txtRentNum.Name = "txtRentNum";
            txtRentNum.ReadOnly = true;
            txtRentNum.Size = new Size(270, 39);
            txtRentNum.TabIndex = 42;
            txtRentNum.TextAlign = HorizontalAlignment.Right;
            // 
            // txtCustID
            // 
            txtCustID.Location = new Point(604, 215);
            txtCustID.Margin = new Padding(6);
            txtCustID.MaxLength = 9;
            txtCustID.Name = "txtCustID";
            txtCustID.ReadOnly = true;
            txtCustID.Size = new Size(270, 39);
            txtCustID.TabIndex = 43;
            txtCustID.TextAlign = HorizontalAlignment.Right;
            // 
            // lblCustID
            // 
            lblCustID.AutoSize = true;
            lblCustID.Location = new Point(457, 222);
            lblCustID.Margin = new Padding(6, 0, 6, 0);
            lblCustID.Name = "lblCustID";
            lblCustID.Size = new Size(147, 32);
            lblCustID.TabIndex = 44;
            lblCustID.Text = "Customer ID";
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(1112, 222);
            txtStatus.Margin = new Padding(6);
            txtStatus.MaxLength = 1;
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(47, 39);
            txtStatus.TabIndex = 47;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(945, 228);
            lblStatus.Margin = new Padding(6, 0, 6, 0);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(151, 32);
            lblStatus.TabIndex = 48;
            lblStatus.Text = "Rental Status";
            // 
            // grpRental
            // 
            grpRental.Controls.Add(cboTimeTo);
            grpRental.Controls.Add(cboTimeFrom);
            grpRental.Controls.Add(dateReturn);
            grpRental.Controls.Add(dateStart);
            grpRental.Controls.Add(btnCarSearch);
            grpRental.Controls.Add(lblReturnTime);
            grpRental.Controls.Add(lblReturnDate);
            grpRental.Controls.Add(lblRebtStartTime);
            grpRental.Controls.Add(lblstartDate);
            grpRental.Controls.Add(cboCarTypes);
            grpRental.Controls.Add(label2);
            grpRental.Controls.Add(Cost);
            grpRental.Location = new Point(32, 47);
            grpRental.Margin = new Padding(6);
            grpRental.Name = "grpRental";
            grpRental.Padding = new Padding(6);
            grpRental.Size = new Size(1138, 410);
            grpRental.TabIndex = 49;
            grpRental.TabStop = false;
            grpRental.Text = "Enter Rental Requirements";
            // 
            // cboTimeTo
            // 
            cboTimeTo.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTimeTo.FormattingEnabled = true;
            cboTimeTo.Location = new Point(607, 198);
            cboTimeTo.Margin = new Padding(6);
            cboTimeTo.Name = "cboTimeTo";
            cboTimeTo.Size = new Size(175, 40);
            cboTimeTo.TabIndex = 56;
            // 
            // cboTimeFrom
            // 
            cboTimeFrom.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTimeFrom.FormattingEnabled = true;
            cboTimeFrom.Location = new Point(609, 132);
            cboTimeFrom.Margin = new Padding(6);
            cboTimeFrom.Name = "cboTimeFrom";
            cboTimeFrom.Size = new Size(175, 40);
            cboTimeFrom.TabIndex = 55;
            // 
            // dateReturn
            // 
            dateReturn.Format = DateTimePickerFormat.Custom;
            dateReturn.Location = new Point(206, 203);
            dateReturn.Margin = new Padding(6);
            dateReturn.MinDate = new DateTime(2024, 7, 3, 0, 0, 0, 0);
            dateReturn.Name = "dateReturn";
            dateReturn.Size = new Size(175, 39);
            dateReturn.TabIndex = 54;
            dateReturn.Value = new DateTime(2024, 7, 3, 0, 0, 0, 0);
            // 
            // dateStart
            // 
            dateStart.Format = DateTimePickerFormat.Custom;
            dateStart.Location = new Point(206, 132);
            dateStart.Margin = new Padding(6);
            dateStart.MinDate = new DateTime(2024, 7, 2, 0, 0, 0, 0);
            dateStart.Name = "dateStart";
            dateStart.Size = new Size(175, 39);
            dateStart.TabIndex = 53;
            dateStart.ValueChanged += dateStart_ValueChanged;
            // 
            // btnCarSearch
            // 
            btnCarSearch.ForeColor = SystemColors.Highlight;
            btnCarSearch.Location = new Point(0, 292);
            btnCarSearch.Margin = new Padding(6);
            btnCarSearch.Name = "btnCarSearch";
            btnCarSearch.Size = new Size(1138, 118);
            btnCarSearch.TabIndex = 44;
            btnCarSearch.Text = "Search for cars";
            btnCarSearch.UseVisualStyleBackColor = true;
            btnCarSearch.Click += btnCarSearch_Click;
            // 
            // lblReturnTime
            // 
            lblReturnTime.AutoSize = true;
            lblReturnTime.Location = new Point(468, 220);
            lblReturnTime.Margin = new Padding(6, 0, 6, 0);
            lblReturnTime.Name = "lblReturnTime";
            lblReturnTime.Size = new Size(139, 32);
            lblReturnTime.TabIndex = 43;
            lblReturnTime.Text = "Return time";
            // 
            // lblReturnDate
            // 
            lblReturnDate.AutoSize = true;
            lblReturnDate.Location = new Point(58, 215);
            lblReturnDate.Margin = new Padding(6, 0, 6, 0);
            lblReturnDate.Name = "lblReturnDate";
            lblReturnDate.Size = new Size(141, 32);
            lblReturnDate.TabIndex = 40;
            lblReturnDate.Text = "Return Date";
            // 
            // lblRebtStartTime
            // 
            lblRebtStartTime.AutoSize = true;
            lblRebtStartTime.Location = new Point(468, 149);
            lblRebtStartTime.Margin = new Padding(6, 0, 6, 0);
            lblRebtStartTime.Name = "lblRebtStartTime";
            lblRebtStartTime.Size = new Size(122, 32);
            lblRebtStartTime.TabIndex = 39;
            lblRebtStartTime.Text = " start time";
            // 
            // lblstartDate
            // 
            lblstartDate.AutoSize = true;
            lblstartDate.Location = new Point(69, 149);
            lblstartDate.Margin = new Padding(6, 0, 6, 0);
            lblstartDate.Name = "lblstartDate";
            lblstartDate.Size = new Size(119, 32);
            lblstartDate.TabIndex = 36;
            lblstartDate.Text = "Start Date";
            // 
            // cboCarTypes
            // 
            cboCarTypes.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCarTypes.FormattingEnabled = true;
            cboCarTypes.Location = new Point(206, 53);
            cboCarTypes.Margin = new Padding(4, 2, 4, 2);
            cboCarTypes.Name = "cboCarTypes";
            cboCarTypes.Size = new Size(242, 40);
            cboCarTypes.TabIndex = 35;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(26, 60);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(178, 32);
            label2.TabIndex = 34;
            label2.Text = "Select Car Type";
            // 
            // grpCars
            // 
            grpCars.Controls.Add(grpRentalCosts);
            grpCars.Controls.Add(grdAvailableCars);
            grpCars.Location = new Point(32, 497);
            grpCars.Margin = new Padding(6);
            grpCars.Name = "grpCars";
            grpCars.Padding = new Padding(6);
            grpCars.Size = new Size(995, 525);
            grpCars.TabIndex = 50;
            grpCars.TabStop = false;
            grpCars.Text = "Select Car";
            grpCars.Visible = false;
            // 
            // grpRentalCosts
            // 
            grpRentalCosts.Controls.Add(txtRegNum);
            grpRentalCosts.Controls.Add(lblRegNum);
            grpRentalCosts.Controls.Add(txtTotalCost);
            grpRentalCosts.Controls.Add(label3);
            grpRentalCosts.Location = new Point(30, 335);
            grpRentalCosts.Margin = new Padding(6);
            grpRentalCosts.Name = "grpRentalCosts";
            grpRentalCosts.Padding = new Padding(6);
            grpRentalCosts.Size = new Size(904, 119);
            grpRentalCosts.TabIndex = 51;
            grpRentalCosts.TabStop = false;
            grpRentalCosts.Text = "Rental info";
            grpRentalCosts.Visible = false;
            // 
            // txtRegNum
            // 
            txtRegNum.Enabled = false;
            txtRegNum.Location = new Point(169, 34);
            txtRegNum.Margin = new Padding(6);
            txtRegNum.MaxLength = 10;
            txtRegNum.Name = "txtRegNum";
            txtRegNum.ReadOnly = true;
            txtRegNum.Size = new Size(260, 39);
            txtRegNum.TabIndex = 54;
            // 
            // lblRegNum
            // 
            lblRegNum.AutoSize = true;
            lblRegNum.Location = new Point(19, 41);
            lblRegNum.Margin = new Padding(6, 0, 6, 0);
            lblRegNum.Name = "lblRegNum";
            lblRegNum.Size = new Size(149, 32);
            lblRegNum.TabIndex = 53;
            lblRegNum.Text = "Reg Number";
            // 
            // txtTotalCost
            // 
            txtTotalCost.Location = new Point(686, 31);
            txtTotalCost.Margin = new Padding(6);
            txtTotalCost.MaxLength = 7;
            txtTotalCost.Name = "txtTotalCost";
            txtTotalCost.ReadOnly = true;
            txtTotalCost.Size = new Size(153, 39);
            txtTotalCost.TabIndex = 52;
            txtTotalCost.Text = "0.00";
            txtTotalCost.TextAlign = HorizontalAlignment.Right;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(622, 34);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(61, 32);
            label3.TabIndex = 51;
            label3.Text = "Cost";
            // 
            // grdAvailableCars
            // 
            grdAvailableCars.AllowUserToAddRows = false;
            grdAvailableCars.AllowUserToDeleteRows = false;
            grdAvailableCars.BackgroundColor = SystemColors.ButtonHighlight;
            grdAvailableCars.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdAvailableCars.Location = new Point(30, 51);
            grdAvailableCars.Margin = new Padding(4, 2, 4, 2);
            grdAvailableCars.Name = "grdAvailableCars";
            grdAvailableCars.RowHeadersWidth = 82;
            grdAvailableCars.RowTemplate.Height = 41;
            grdAvailableCars.Size = new Size(899, 260);
            grdAvailableCars.TabIndex = 18;
            grdAvailableCars.CellClick += grdAvailableCars_CellClick;
            // 
            // chkBoxEquip
            // 
            chkBoxEquip.AutoSize = true;
            chkBoxEquip.Location = new Point(132, 41);
            chkBoxEquip.Margin = new Padding(6);
            chkBoxEquip.Name = "chkBoxEquip";
            chkBoxEquip.Size = new Size(80, 36);
            chkBoxEquip.TabIndex = 51;
            chkBoxEquip.Text = "Yes";
            chkBoxEquip.UseVisualStyleBackColor = true;
            chkBoxEquip.CheckedChanged += chkBoxEquip_CheckedChanged;
            // 
            // grpEquip
            // 
            grpEquip.Controls.Add(grpEquipInfo);
            grpEquip.Controls.Add(btnSearchEquipment);
            grpEquip.Controls.Add(grdAvailableEquip);
            grpEquip.Location = new Point(224, 1051);
            grpEquip.Margin = new Padding(6);
            grpEquip.Name = "grpEquip";
            grpEquip.Padding = new Padding(6);
            grpEquip.Size = new Size(808, 563);
            grpEquip.TabIndex = 52;
            grpEquip.TabStop = false;
            grpEquip.Text = "Select Equipment";
            grpEquip.Visible = false;
            // 
            // grpEquipInfo
            // 
            grpEquipInfo.Controls.Add(txtEquipmentID);
            grpEquipInfo.Controls.Add(label1);
            grpEquipInfo.Controls.Add(txtFullCost);
            grpEquipInfo.Controls.Add(label4);
            grpEquipInfo.Location = new Point(30, 420);
            grpEquipInfo.Margin = new Padding(6);
            grpEquipInfo.Name = "grpEquipInfo";
            grpEquipInfo.Padding = new Padding(6);
            grpEquipInfo.Size = new Size(711, 119);
            grpEquipInfo.TabIndex = 52;
            grpEquipInfo.TabStop = false;
            grpEquipInfo.Text = "Equipment Info";
            grpEquipInfo.Visible = false;
            // 
            // txtEquipmentID
            // 
            txtEquipmentID.Enabled = false;
            txtEquipmentID.Location = new Point(155, 41);
            txtEquipmentID.Margin = new Padding(6);
            txtEquipmentID.MaxLength = 10;
            txtEquipmentID.Name = "txtEquipmentID";
            txtEquipmentID.ReadOnly = true;
            txtEquipmentID.Size = new Size(90, 39);
            txtEquipmentID.TabIndex = 54;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 44);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(104, 32);
            label1.TabIndex = 53;
            label1.Text = "Equip ID";
            // 
            // txtFullCost
            // 
            txtFullCost.Location = new Point(417, 44);
            txtFullCost.Margin = new Padding(6);
            txtFullCost.MaxLength = 7;
            txtFullCost.Name = "txtFullCost";
            txtFullCost.ReadOnly = true;
            txtFullCost.Size = new Size(153, 39);
            txtFullCost.TabIndex = 52;
            txtFullCost.Text = "0.00";
            txtFullCost.TextAlign = HorizontalAlignment.Right;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(332, 48);
            label4.Margin = new Padding(6, 0, 6, 0);
            label4.Name = "label4";
            label4.Size = new Size(61, 32);
            label4.TabIndex = 51;
            label4.Text = "Cost";
            // 
            // btnSearchEquipment
            // 
            btnSearchEquipment.ForeColor = SystemColors.Highlight;
            btnSearchEquipment.Location = new Point(0, 41);
            btnSearchEquipment.Margin = new Padding(6);
            btnSearchEquipment.Name = "btnSearchEquipment";
            btnSearchEquipment.Size = new Size(808, 109);
            btnSearchEquipment.TabIndex = 40;
            btnSearchEquipment.Text = "Search for equipments";
            btnSearchEquipment.UseVisualStyleBackColor = true;
            btnSearchEquipment.Click += btnSearchEquipment_Click;
            // 
            // grdAvailableEquip
            // 
            grdAvailableEquip.BackgroundColor = SystemColors.ButtonHighlight;
            grdAvailableEquip.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdAvailableEquip.Location = new Point(0, 158);
            grdAvailableEquip.Margin = new Padding(4, 2, 4, 2);
            grdAvailableEquip.Name = "grdAvailableEquip";
            grdAvailableEquip.RowHeadersWidth = 82;
            grdAvailableEquip.RowTemplate.Height = 41;
            grdAvailableEquip.Size = new Size(1007, 230);
            grdAvailableEquip.TabIndex = 39;
            grdAvailableEquip.CellClick += grdAvailableEquip_CellClick;
            // 
            // grpEquipCheck
            // 
            grpEquipCheck.Controls.Add(lblEquip);
            grpEquipCheck.Controls.Add(chkBoxEquip);
            grpEquipCheck.Location = new Point(0, 1051);
            grpEquipCheck.Margin = new Padding(6);
            grpEquipCheck.Name = "grpEquipCheck";
            grpEquipCheck.Padding = new Padding(6);
            grpEquipCheck.Size = new Size(220, 100);
            grpEquipCheck.TabIndex = 53;
            grpEquipCheck.TabStop = false;
            grpEquipCheck.Text = "Equipment";
            grpEquipCheck.Visible = false;
            // 
            // grpRentalPay
            // 
            grpRentalPay.Controls.Add(btnPay);
            grpRentalPay.Controls.Add(lblRentalNum);
            grpRentalPay.Controls.Add(txtRentNum);
            grpRentalPay.Controls.Add(lblCustID);
            grpRentalPay.Controls.Add(txtCustID);
            grpRentalPay.Controls.Add(txtStatus);
            grpRentalPay.Controls.Add(lblStatus);
            grpRentalPay.Location = new Point(1144, 1092);
            grpRentalPay.Margin = new Padding(6);
            grpRentalPay.Name = "grpRentalPay";
            grpRentalPay.Padding = new Padding(6);
            grpRentalPay.Size = new Size(1179, 288);
            grpRentalPay.TabIndex = 54;
            grpRentalPay.TabStop = false;
            grpRentalPay.Text = "Payment";
            grpRentalPay.Visible = false;
            // 
            // frmMakeRental
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(2338, 1644);
            Controls.Add(grpRentalPay);
            Controls.Add(grpEquipCheck);
            Controls.Add(grpEquip);
            Controls.Add(grpCars);
            Controls.Add(grpRental);
            Controls.Add(grpCustInfo);
            Margin = new Padding(6);
            Name = "frmMakeRental";
            Text = "Make Rental";
            Load += frmMakeRental_Load;
            grpCustInfo.ResumeLayout(false);
            grpCustInfo.PerformLayout();
            grpRental.ResumeLayout(false);
            grpRental.PerformLayout();
            grpCars.ResumeLayout(false);
            grpRentalCosts.ResumeLayout(false);
            grpRentalCosts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdAvailableCars).EndInit();
            grpEquip.ResumeLayout(false);
            grpEquipInfo.ResumeLayout(false);
            grpEquipInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdAvailableEquip).EndInit();
            grpEquipCheck.ResumeLayout(false);
            grpEquipCheck.PerformLayout();
            grpRentalPay.ResumeLayout(false);
            grpRentalPay.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Label CustIDSearch;
        private TextBox txtCarCost;
        private Label RentalNumber;
        private Label Cost;
        private TextBox txtCustIDSearch;
        private Button btnCustIdSearch;
        private Label lblEquip;
        private GroupBox grpCustInfo;
        private TextBox txtSurname;
        private Label Surname;
        private Button btnAddCust;
        private TextBox txtForename;
        private TextBox txtLicence;
        private TextBox txtEmail;
        private Label Forename;
        private TextBox txtPhoneNum;
        private Label LicenceNumber;
        private Label Email;
        private Label PhoneNumber;
        private Button btnPay;
        private Label lblRentalNum;
        private TextBox txtRentNum;
        private TextBox txtCustID;
        private Label lblCustID;
        private TextBox txtStatus;
        private Label lblStatus;
        private GroupBox grpRental;
        private Label lblRebtStartTime;
        private Label lblstartDate;
        private ComboBox cboCarTypes;
        private Label label2;
        private Label lblReturnTime;
        private Label lblReturnDate;
        private Button btnCarSearch;
        private GroupBox grpCars;
        private DataGridView grdAvailableCars;
        private GroupBox grpRentalCosts;
        private TextBox txtRegNum;
        private Label lblRegNum;
        private TextBox txtTotalCost;
        private Label label3;
        private CheckBox chkBoxEquip;
        private GroupBox grpEquip;
        private Button btnSearchEquipment;
        private DataGridView grdAvailableEquip;
        private DateTimePicker dateStart;
        private DateTimePicker dateReturn;
        private GroupBox grpEquipCheck;
        private GroupBox grpRentalPay;
        private ComboBox cboTimeFrom;
        private ComboBox cboTimeTo;
        private GroupBox grpEquipInfo;
        private TextBox txtEquipmentID;
        private Label label1;
        private TextBox txtFullCost;
        private Label label4;
    }
}