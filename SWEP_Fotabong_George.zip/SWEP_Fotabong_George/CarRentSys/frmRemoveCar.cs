﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmRemoveCar : Form
    {
        //creating a variable named cars of type Cars and initializes it with a new instance of the Cars class.
        Cars theCar = new Cars();

        public frmRemoveCar()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validate data enterd 
            if (cboRegNum.SelectedIndex == -1)
            {
                MessageBox.Show("please select a Registration number for a car to remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboRegNum.Focus();
                return;
            }


            // Finding matching Cars
            grdRemoveCar.DataSource = Cars.findCar(cboRegNum.Text).Tables["cars"];

            if (grdRemoveCar.Rows.Count == 0)
            {
                MessageBox.Show("no data found for the registration number: " + cboRegNum.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboRegNum.SelectedIndex = -1;
            }
            else
            {
                // If the code reaches here, it means the validation passed
                MessageBox.Show("Valid Registration number, car has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //make group box holding the grid box info visible 
                grdRemoveCar.Visible = true;
            }


        }


        private void btnRemove_Click(object sender, EventArgs e)
        {
            //yes or no message to confim removal
            DialogResult answer = MessageBox.Show("Are you sure you want to remove the car : " + cboRegNum.Text, "Confirm",
     MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //if statement if yes is clicked
            if (answer == DialogResult.Yes)
            {
                //remove the car from database based on the registration number
                theCar.removeCar(cboRegNum.Text);

                //comfirmation message 
                MessageBox.Show("The Car: " + cboRegNum.Text + " has been Removed from the Cars file", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //reset UI
                grpRemCar.Visible = false;
                grdRemoveCar.Visible = false;
                txtStat.Text = "R";
                cboRegNum.SelectedIndex = -1;
            }
            txtStat.Clear();

        }

        private void grdRemoveCar_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //extract the RegNum from column zero on the slected rrow in grid
            String RegNum = (grdRemoveCar.Rows[grdRemoveCar.CurrentCell.RowIndex].Cells[0].Value.ToString());


            //Instanciate theCar
            theCar.getCar(RegNum);


            //move the instance variable values to the form controls
            cboRegNum.Text = theCar.get_regNum();
            txtStat.Text = theCar.getStatus();
            grpRemCar.Visible = true;

            //if the status of the car is not A then send the error message and reset the UI
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this car may not be removed yet because it is currently in use please choose another car", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                cboRegNum.SelectedIndex = -1;
                txtStat.Clear();
                grpRemCar.Visible= false;
            }
        }

        private void frmRemoveCar_Load(object sender, EventArgs e)
        {
            cboRegNum = Utility.loadCombo(cboRegNum, "SELECT DISTINCT RegNum FROM CARS ORDER BY RegNum", 1);
        }
    }
}
