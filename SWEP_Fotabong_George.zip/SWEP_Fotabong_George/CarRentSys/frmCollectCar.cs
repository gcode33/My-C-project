﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmCollectCar : Form
    {
        Rental rent = new Rental();
        Cars cars = new Cars();

        public frmCollectCar()
        {
            InitializeComponent();
        }

        private void frmCollectCar_Load(object sender, EventArgs e)
        {
            cboCustID = Utility.loadCombo(cboCustID, "SELECT DISTINCT CustID FROM RENTALS WHERE Customer_Status = 'P' ORDER BY CustID", 1);



        }


        private void btnSearch_Click(object sender, EventArgs e)
        {

            //fill the grid box with the rental info based on the CustID and RegNum provided
            grdRentals.DataSource = Rental.findRental(Convert.ToInt32(cboRentNum.Text.ToString()), Convert.ToInt32(cboCustID.Text.ToString())).Tables["Rental"];

            // Check if the rental exists
            if (grdRentals.Rows.Count == 1)
            {
                MessageBox.Show("The rental does not exist .", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //if the rental exists send comfirmation message
            MessageBox.Show("The rental exists!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //make the group box with the grid box visible
            grpRentalInfo.Visible = true;



        }

        private void btnCollectCar_Click(object sender, EventArgs e)
        {
            //set the customers status to C for collected
            txtStatus.Text = "C";
            rent.setStatus(txtStatus.Text);
            rent.updateRental();
            MessageBox.Show("The Customer has collected their rental car", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grpCollectCar.Visible = false;
            grpRentalInfo.Visible = false;
            cboCustID.SelectedIndex = -1;
            cboRentNum.SelectedIndex = -1;
        }

        private void grdRentals_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //variable to hold the status of the customer based of the grid box
            string Status = grdRentals.Rows[grdRentals.CurrentCell.RowIndex].Cells[6].ToString();

            //variable to hold the regnum of the car based of the grid box
            String RegNum = grdRentals.Rows[grdRentals.CurrentCell.RowIndex].Cells[3].Value.ToString();

            //variable to set the new car status to U for unavailable 
            string Carstatus = "U";

            //invoke the update car status method to set the new status of the car based on the RegNum provided 
            cars.updateCarStatus(Carstatus, RegNum);

            //setting the varibale holding the current customer status to the text box for status
            Status = txtStatus.Text;

            //making the group box which has the collect car button visible 
            grpCollectCar.Visible = true;
        }

        private void cboCustID_SelectedIndexChanged(object sender, EventArgs e)
        {
            //load rental numbers for the selected customer ID based on which customer ID that was selected
            cboRentNum = Utility.loadCombo(cboRentNum, "SELECT Rental_Number FROM RENTALS WHERE CustID = '" + cboCustID.Text + "' ORDER BY Rental_Number", 1);

            //enable combo box
            cboRentNum.Enabled = true;
        }
    }
}
