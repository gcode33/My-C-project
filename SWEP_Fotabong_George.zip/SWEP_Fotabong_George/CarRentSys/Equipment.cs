﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace CarRentSys
{
    internal class Equipment
    {
        private int equipID;
        private String description;
        private String equipName;
        private decimal price;
        private String status;

        public Equipment()
        {
            this.equipID = 0;
            this.description = "";
            this.equipName = "";
            this.price = 0;
            this.status = "";
        }

        public Equipment(int equipID, string description, string equipName, decimal price, String status)
        {
            this.equipID = equipID;
            this.description = description;
            this.equipName = equipName;
            this.price = price;
            this.status = status;  
        }
        //getters 
        public int getEquipID() {  return this.equipID; }
        public String getDescription() { return this.description;}
        public String getEqiupName() { return this.equipName;}
        public decimal getPrice() { return this.price;}
        public String getStatus() { return this.status;}


        //setters
        public void setEquipID(int EquipID) { equipID = EquipID; }
        public void setDescription(String Description) { description = Description;}
        public void setEquipName(String EquipName) {  equipName = EquipName;}
        public void setPrice(decimal Price) { price = Price;}
        public void setStatus(String Status) {  status = Status;}




        public static DataSet getAllEquipment()
        {
            //open db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT EquipID, Equip_Description, Equip_Name, Price, Equip_Status " +
                             " FROM Equipment ORDER BY Equip_Name";


            //execute the sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "equipment");

            //close db connection
            conn.Close();
            return ds;
        }

        public void getEquipment(int EquipID)
        {
            //open db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT * FROM Equipment WHERE EquipID = " + EquipID + "";

            //execute the sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();

            //set the instance variables with values from data reader
            setEquipID(dr.GetInt32(0));
            setEquipName(dr.GetString(1));
            setDescription(dr.GetString(2));
            setPrice(dr.GetInt32(3));
            setStatus(dr.GetString(4));

            //close db
            conn.Close();

        }

        public void addEquipment()
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define sql query to be exexuted
            String sqlQuery = " INSERT INTO Equipment Values (" +
                this.equipID + ",'" +
                this.description + "','" +
                this.equipName + "'," +
                this.price + ",'"+
                this.status + "')";

            //execute the sql query (Oracle command)
            OracleCommand cmd  = new OracleCommand(sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close db connection
            conn.Close();
        }
        public void updateEquipment()
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "UPDATE Equipment SET " +
                                "Equip_Description = '" + this.description + "'," +
                                "Price = " + this.price + "," +
                                "Equip_status = '" + this.status + "'" +
                                " WHERE EquipID = " + this.equipID + "";



            //excute sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand (sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close connection
            conn.Close();

        }

        public void updateEquipmentStatus(string status, int equipID)
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed 
            String sqlQuery = "UPDATE EQUIPMENT SET Equip_Status = '" + status + "' WHERE EquipID = " + equipID + "";


            //execute the sql Query(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close db connection
            conn.Close();

        }
        public void removeEquipment(int EquipID)
        {
            //open a db connection
            OracleConnection conn = new OracleConnection (DBConnect.oraDB);

            //define sql query to be executed
            String sqlQuery = "DELETE FROM Equipment WHERE EquipID = " + EquipID + "";

            //execute sql query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery,conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close connection
            conn.Close ();
        }
        public static DataSet findEquipment(int equipID) 
        {
            //opnen db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define sql query to be executed
            String sqlQuery = "SELECT EquipID, Equip_Description, Equip_Name, Price, Equip_Status " +
                                "FROM Equipment " +
                                "WHERE EquipID = " + equipID + " " +
                                "ORDER BY Equip_Name";

            //execute sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "equipment");


            //close connection
            conn.Close();
            return ds;
        }

        public static int getNextEquipID()
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define sql query to be executed
            String sqlQuery = "SELECT MAX(EquipID) FROM Equipment";

            //execute the sql query (OracleCommand)
            OracleCommand cmd = new OracleCommand (sqlQuery,conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();

            //does dr contain a value or null
            int nextId;
            dr.Read();

            if(dr.IsDBNull(0) )
                nextId = 1;
            else
            {
                nextId = dr.GetInt32(0) + 1;
            }
            //close db connection
            conn.Close();
            return nextId;
        }

        public static String getEquipStatus(int equipID)
        {
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT Status FROM EQUIPMENT WHERE EquipID = " + equipID + "";


            //executr the sql query command(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();


            OracleDataReader dr = cmd.ExecuteReader();
            String status = "";

            //does dr contain a value or null?
            dr.Read();
            status = dr.GetString(0);
            //close db connection
            conn.Close();
            return status;
        }
     
    }
   
}
