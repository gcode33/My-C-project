﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentSys
{
    internal class Utility
    {
        //use this for where there are combo boxes 
            public static ComboBox loadCombo(ComboBox cboName, String sqlQuery, int numFields)
        {
            //connect to DB
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            

            // create Oracle command
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            //Execute Query using DataReader
            OracleDataReader dr = cmd.ExecuteReader();

            
            //Load info into combo box based on how much info you need from the colum for example for type code which is "BA - Basic" you only need the BA so the num feilds will be 2 and then you give the query and the name of the combo box 
            while (dr.Read())
            {
                String dataItem = "";
                dataItem += dr.GetString(0);

                 for (int i=1;i<numFields;i++)
                {
                    dataItem = dataItem + " - " + dr.GetString(i);
                }
                cboName.Items.Add(dataItem);

            }
            conn.Close();

            return cboName;
           
        }




    }
}
