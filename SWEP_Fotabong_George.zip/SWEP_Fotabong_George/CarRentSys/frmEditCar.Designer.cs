﻿namespace CarRentSys
{
    partial class frmEditCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            RegNum = new Label();
            grpEditCar = new GroupBox();
            txtStat = new TextBox();
            lblStat = new Label();
            txtFuelType = new TextBox();
            Status = new Label();
            FuelType = new Label();
            btnSubmit = new Button();
            txtDescription = new TextBox();
            Description = new Label();
            btnSearch = new Button();
            grdCars = new DataGridView();
            cboRegNum = new ComboBox();
            grpEditCar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdCars).BeginInit();
            SuspendLayout();
            // 
            // RegNum
            // 
            RegNum.AutoSize = true;
            RegNum.Location = new Point(11, 64);
            RegNum.Margin = new Padding(4, 0, 4, 0);
            RegNum.Name = "RegNum";
            RegNum.Size = new Size(235, 32);
            RegNum.TabIndex = 0;
            RegNum.Text = "Registration Number";
            // 
            // grpEditCar
            // 
            grpEditCar.Controls.Add(txtStat);
            grpEditCar.Controls.Add(lblStat);
            grpEditCar.Controls.Add(txtFuelType);
            grpEditCar.Controls.Add(Status);
            grpEditCar.Controls.Add(FuelType);
            grpEditCar.Controls.Add(btnSubmit);
            grpEditCar.Controls.Add(txtDescription);
            grpEditCar.Controls.Add(Description);
            grpEditCar.Location = new Point(11, 524);
            grpEditCar.Margin = new Padding(4, 2, 4, 2);
            grpEditCar.Name = "grpEditCar";
            grpEditCar.Padding = new Padding(4, 2, 4, 2);
            grpEditCar.Size = new Size(1153, 637);
            grpEditCar.TabIndex = 4;
            grpEditCar.TabStop = false;
            grpEditCar.Text = "Edit Car";
            grpEditCar.Visible = false;
            // 
            // txtStat
            // 
            txtStat.Enabled = false;
            txtStat.Location = new Point(113, 380);
            txtStat.Margin = new Padding(4, 2, 4, 2);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(52, 39);
            txtStat.TabIndex = 16;
            // 
            // lblStat
            // 
            lblStat.AutoSize = true;
            lblStat.Location = new Point(9, 387);
            lblStat.Margin = new Padding(4, 0, 4, 0);
            lblStat.Name = "lblStat";
            lblStat.Size = new Size(78, 32);
            lblStat.TabIndex = 15;
            lblStat.Text = "Status";
            // 
            // txtFuelType
            // 
            txtFuelType.Enabled = false;
            txtFuelType.Location = new Point(143, 241);
            txtFuelType.Margin = new Padding(4, 2, 4, 2);
            txtFuelType.MaxLength = 1;
            txtFuelType.Name = "txtFuelType";
            txtFuelType.ReadOnly = true;
            txtFuelType.Size = new Size(52, 39);
            txtFuelType.TabIndex = 14;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(6, 499);
            Status.Margin = new Padding(4, 0, 4, 0);
            Status.Name = "Status";
            Status.Size = new Size(0, 32);
            Status.TabIndex = 10;
            // 
            // FuelType
            // 
            FuelType.AutoSize = true;
            FuelType.Location = new Point(6, 244);
            FuelType.Margin = new Padding(4, 0, 4, 0);
            FuelType.Name = "FuelType";
            FuelType.Size = new Size(117, 32);
            FuelType.TabIndex = 9;
            FuelType.Text = "Fuel Type";
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(0, 523);
            btnSubmit.Margin = new Padding(4, 2, 4, 2);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(1145, 113);
            btnSubmit.TabIndex = 5;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(143, 106);
            txtDescription.Margin = new Padding(4, 2, 4, 2);
            txtDescription.MaxLength = 10;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(188, 39);
            txtDescription.TabIndex = 2;
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(0, 106);
            Description.Margin = new Padding(4, 0, 4, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 0;
            Description.Text = "Description";
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(520, 53);
            btnSearch.Margin = new Padding(4, 2, 4, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(139, 64);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // grdCars
            // 
            grdCars.AllowUserToAddRows = false;
            grdCars.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            grdCars.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            grdCars.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grdCars.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            grdCars.BackgroundColor = SystemColors.ButtonHighlight;
            grdCars.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Bahnschrift", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            grdCars.DefaultCellStyle = dataGridViewCellStyle2;
            grdCars.Location = new Point(11, 122);
            grdCars.Margin = new Padding(4, 2, 4, 2);
            grdCars.Name = "grdCars";
            grdCars.RowHeadersWidth = 82;
            grdCars.RowTemplate.Height = 41;
            grdCars.Size = new Size(1873, 381);
            grdCars.TabIndex = 6;
            grdCars.Visible = false;
            grdCars.CellContentClick += grdCars_CellClick;
            // 
            // cboRegNum
            // 
            cboRegNum.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRegNum.FormattingEnabled = true;
            cboRegNum.Location = new Point(254, 66);
            cboRegNum.Margin = new Padding(4, 2, 4, 2);
            cboRegNum.Name = "cboRegNum";
            cboRegNum.Size = new Size(242, 40);
            cboRegNum.TabIndex = 11;
            // 
            // frmEditCar
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1888, 1172);
            Controls.Add(cboRegNum);
            Controls.Add(grdCars);
            Controls.Add(btnSearch);
            Controls.Add(grpEditCar);
            Controls.Add(RegNum);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmEditCar";
            Text = "frmEditCar";
            Load += frmEditCar_Load;
            grpEditCar.ResumeLayout(false);
            grpEditCar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdCars).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label RegNum;
        private GroupBox grpEditCar;
        private TextBox txtDescription;
        private Label Description;
        private Button btnSearch;
        private Button btnSubmit;
        private TextBox txtFuelType;
        private Label Status;
        private Label FuelType;
        private DataGridView grdCars;
        private Label lblStat;
        private TextBox txtStat;
        private ComboBox cboRegNum;
    }
}