using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmMainMenu : Form
    {
        OracleConnection conn = new  OracleConnection(DBConnect.oraDB);
        public frmMainMenu()
        {
            
            InitializeComponent();
        }



        private void mnuExit_Click(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show("Are you sure you want to exit?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                Application.Exit();
            }
        }



        private void setCarTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmSetCarType();
            newForm.ShowDialog();
        }

        private void addCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmAddCar();
            newForm.ShowDialog();
        }

        private void editCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmEditCar();
            newForm.ShowDialog();
        }

        private void removeCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmRemoveCar();
            newForm.ShowDialog();
        }



        private void addEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmAddEquipment();
            newForm.ShowDialog();
        }

        private void editQuipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmEditEquipment();
            newForm.ShowDialog();
        }

        private void removeEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmRemoveEquipment();
            newForm.ShowDialog();
        }

        private void MakeRentalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmMakeRental();
            newForm.ShowDialog();
        }

        private void cancelRentalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmCancelRental();
            newForm.ShowDialog();
        }

        private void collectCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmCollectCar();
            newForm.ShowDialog();
        }

        private void returnCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmReturnCar();
            newForm.ShowDialog();
        }

        private void MonthlyRevenueAnalysisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmMonthlyRevenueAnalysis();
            newForm.ShowDialog();
        }

        private void CustomerAnalysisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newForm = new frmCustomerAnalysis();
            newForm.ShowDialog();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
                lblStatus.Text = "CLOSED";
                lblStatus.ForeColor = System.Drawing.Color.Black;
            }
            else
            {
              
                conn.Open();
                lblStatus.Text = "OPEN";
                lblStatus.ForeColor = System.Drawing.Color.Red;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

