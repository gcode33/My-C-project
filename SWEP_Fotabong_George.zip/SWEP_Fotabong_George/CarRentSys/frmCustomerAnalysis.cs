﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmCustomerAnalysis : Form
    {
        public frmCustomerAnalysis()
        {
            InitializeComponent();
            //call the load year function to load in the years for the combo box
            LoadYears();
        }

        private void LoadYears()
        {
            //for loop to load the years into the combo box by starting at the current year(2024) and going down all the way to 2000
            for (int year = DateTime.Now.Year; year >= 2022; year--)
            {
                //adding the values into the combo box 
                cboYears.Items.Add(year.ToString());
            }
        }
        private void btnSearchYear_Click(object sender, EventArgs e)
        {
            //when the search button is clicked then the group boxes holding the chart and the print button become visible
            grpChart.Visible = true;
            grpPrint.Visible = true;
            LoadChartData(); // Reload chart data based on the selected year
        }


        private void LoadChartData()
        {
            // Check if a year is selected
            if (cboYears.Text.Equals(""))
            {
                MessageBox.Show("Please select a year.");
                return;
            }

            string selectedYear = cboYears.Text;

            // Initialize arrays to store data for all months
            string[] months = new string[12];
            decimal[] customerCounts = new decimal[12];

            // Initialize counts for all months to zero
            for (int i = 0; i < 12; i++)
            {
                //fill the month array with the months
                months[i] = getMonth(i + 1);
                
                //fill the customer array with the amount of customers for that month 
                customerCounts[i] = 0;
            }

            // Connect to the database and retrieve data using sql query
            string strSQL = $"SELECT TO_CHAR(RentStart, 'MM') AS Month, COUNT(DISTINCT CustID) AS CustomerCount " +
                            $"FROM RENTALS " +
                            $"WHERE TO_CHAR(RentStart, 'YYYY') = '{selectedYear}' " +
                            $"GROUP BY TO_CHAR(RentStart, 'MM') " +
                            $"ORDER BY TO_CHAR(RentStart, 'MM')";

            DataTable dt = new DataTable();
            OracleConnection myConn = new OracleConnection(DBConnect.oraDB);
            OracleCommand cmd = new OracleCommand(strSQL, myConn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            da.Fill(dt);
            myConn.Close();

            // Populate counts for available months using a  for loop
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow row = dt.Rows[i];
                int monthIndex = Convert.ToInt32(row["Month"]) - 1; 
                customerCounts[monthIndex] = Convert.ToDecimal(row["CustomerCount"]);
            }

            // Bind data to chart series
            ChrtCust.Series[0].Points.DataBindXY(months, customerCounts);

            // Set axis labels
            ChrtCust.ChartAreas[0].AxisX.Title = "Months";
            ChrtCust.ChartAreas[0].AxisY.Title = "Number of Customers";

            // Set chart title
            ChrtCust.Titles.Clear();
            ChrtCust.Titles.Add("Monthly Customer Rental Activity for the year " + selectedYear);
        }


        public string getMonth(int month)
        {
            switch (month)
            {
                case 1:
                    return "JAN";
                case 2:
                    return "FEB";
                case 3:
                    return "MAR";
                case 4:
                    return "APR";
                case 5:
                    return "MAY";
                case 6:
                    return "JUN";
                case 7:
                    return "JUL";
                case 8:
                    return "AUG";
                case 9:
                    return "SEP";
                case 10:
                    return "OCT";
                case 11:
                    return "NOV";
                case 12:
                    return "DEC";
                default:
                    return "OTH";
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            //yes or no message if the manager wants to print the chart
            DialogResult answer = MessageBox.Show("Are you sure you want to print the analysis", "Confirm",
MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                //if yes then the comfirmation message is sent and the UI is reset
                MessageBox.Show("The customer analysis Has been printed", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboYears.SelectedIndex = -1;
                cboYears.SelectedIndex = -1;
                grpChart.Visible = false;
                grpPrint.Visible = false;

            }
            //if no then the UI is reset
            cboYears.SelectedIndex = -1;
            grpChart.Visible = false;
            grpPrint.Visible = false;
        }



    }
}
