﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmAddCar : Form
    {
        public frmAddCar()
        {
            InitializeComponent();
        }


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //validate data entered
            if (txtRegNum.Text.Equals("") || !txtRegNum.Text.Any(char.IsDigit) || !txtRegNum.Text.Any(char.IsLetter) || txtRegNum.Text.Count(char.IsDigit) < 3 || txtRegNum.Text.Length < 9 || txtRegNum.Text.Length > 9)
            {
                MessageBox.Show("Invalid Registration number must include at least 3 digits, must not be more than 9 characters and no negative numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRegNum.Focus();
                return;
            }
            if (txtDescription.Text.Equals("") || txtDescription.Text.Any(char.IsDigit) || txtDescription.Text.Length > 10)
            {
                MessageBox.Show("Desccription must be entered and must not include digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return;
            }
            if (cboModel.SelectedIndex == -1)
            {
                MessageBox.Show("please select a model", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboModel.Focus();
                return;
            }

            if (cboMake.SelectedIndex == -1)
            {
                MessageBox.Show("please select a make", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboMake.Focus();
                return;
            }

            if (cboNumSeats.SelectedIndex == -1)
            {
                MessageBox.Show("please select a number of seats", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboMake.Focus();
                return;
            }

            if (cboTypes.SelectedIndex == -1)
            {
                MessageBox.Show("please select a car type", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboMake.Focus();
                return;
            }

            if (cboFuel.SelectedIndex == -1)
            {
                MessageBox.Show("please select a fuel type", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboMake.Focus();
                return;
            }


            int num_seats = Convert.ToInt32(cboNumSeats.Text.Substring(0));
            //Create an instance of Car and instantiate with values from form controls
            Cars aCar = new Cars(txtRegNum.Text, cboTypes.Text.Substring(0, 2), txtDescription.Text, num_seats, cboModel.Text.Substring(0),
                cboMake.Text.Substring(0), cboFuel.Text.Substring(0), txtStat.Text);

            //invoke the method to add the data to the Cars table
            aCar.addCar();

            //display confirmation message 
            MessageBox.Show("New Car added and saved to the Cars file", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset ui
            txtRegNum.Clear();
            txtDescription.Clear();
            cboNumSeats.SelectedIndex = -1;
            cboFuel.SelectedIndex = -1;
            cboMake.SelectedIndex = -1;
            cboModel.SelectedIndex = -1;
            cboTypes.SelectedIndex = -1;
        }

        private void frmAddCar_Load(object sender, EventArgs e)
        {
            //load info in the combo box
            cboTypes = Utility.loadCombo(cboTypes, "SELECT * FROM CarTypes ORDER BY TypeCode", 2);
            cboMake = Utility.loadCombo(cboMake, "SELECT DISTINCT Make FROM MakeModels ORDER BY Make", 1);
            cboFuel = Utility.loadCombo(cboFuel, "SELECT * FROM FuelTypes ORDER BY FuelType", 1);


            //set the car status to A for available
            txtStat.Text = "A";
        }

        private void cboMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            //load models for the selected make based on which model was selected
            cboModel = Utility.loadCombo(cboModel, "SELECT Model FROM MakeModels WHERE Make = '" + cboMake.Text + "' ORDER BY Model", 1);

            //enable combo box
            cboModel.Enabled = true;

        }

  
    }
}
