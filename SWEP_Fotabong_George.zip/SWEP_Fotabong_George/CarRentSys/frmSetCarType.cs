﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmSetCarType : Form
    {
        public frmSetCarType()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            txtDailyRate.Text = string.Format("{0:F2}", decimal.Parse(txtDailyRate.Text));//allowing two decimal places 
            //validate the data
            if (txtType.Text.Equals("") || txtType.Text.Length < 2 || txtType.Text.Length > 2 || txtType.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Car type must be entered and must be only two characters and not numeric", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtType.Focus();
                return;
            }
            if (txtDescription.Text.Equals("") || txtDescription.Text.Length > 10 || txtDescription.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Description must be entered and no greater than ten characters and not numeric", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return;
            }
            if (txtDailyRate.Text.Equals("") || !txtDailyRate.Text.Any(char.IsDigit) || txtDailyRate.Text.StartsWith("-"))
            {
                MessageBox.Show(" the daily rate must be entered and can not enter a negative number also can not include letters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDailyRate.Focus();
                return;
            }

            //instanciate the cartype with the variables
            CarTypes aCarType= new CarTypes(txtType.Text, txtDescription.Text, Convert.ToDecimal(txtDailyRate.Text));

            //invoke the add car type method to add a new car type
            aCarType.addCarType();

            //Confirmatiomn message

            MessageBox.Show("Car type added to the Car Type file", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Reset UI
            txtType.Clear();
            txtDescription.Clear();
            txtDailyRate.Text = "0.00";


        }


    }
}
