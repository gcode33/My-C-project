﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentSys
{
    internal class Cars
    {
        
        private String regNum;
        private String typeCode;
        private String description;
        private int num_seats;
        private String model;
        private String make;
        private String fuelType;
        private String status;

        public Cars()
        {
            this.regNum = "";
            this.typeCode =
            this.description = "";
            this.num_seats = 0;
            this.model = "";
            this.make = "";
            this.fuelType = "";
            this.status = "";

        }
        public Cars(String regNum, string typeCode, string description, int num_seats, string model, string make, string fuelType, string status)
        {
            this.num_seats = num_seats;
            this.regNum = regNum;
            this.typeCode = typeCode;
            this.make = make;
            this.model = model;
            this.description = description;
            this.fuelType = fuelType;
            this.status = status;
        }

        //getters 
        public int getnum_seats() {return this.num_seats;}
        public String get_regNum() { return this.regNum;}
        public String getTypeCode() { return this.typeCode;}
        public String getMake() { return this.make;}
        public String getModel() { return this.model;}
        public String getDescription() { return this.description;}  
        public String getFuelType() {  return this.fuelType;}
        public String getStatus() { return this.status;}    


        //setters
        public void setnum_seats(int Num_Seats) { num_seats = Num_Seats; }
        public void setregNum(String RegNum) {  regNum = RegNum; }
        public void setTypeCode(String TypeCode) {typeCode = TypeCode;}
        public void setmake(String Make) {  make = Make;}
        public void setmodel(String Model) {  model = Model;}
        public void setdescription(String Description) {  description = Description;}
        public void setfeulType(String FuelType) { fuelType = FuelType;}
        public void setstatus(String Status) { status = Status;}


        public static DataSet getAllCars()
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the SQL query to be executed
            String sqlQuery = "SELECT RegNum, Car_Make, Car_Model, TypeCode, Car_Description, FuelType, Num_Seats, Car_Status" + "FROM CARS ORDER BY RegNum";

            //execute the sql query(Oracle command)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet(); 
            da.Fill(ds,"cars");

            //close connection
            conn.Close();
            return ds;
        }
        public static DataSet getAllCars(String TypeCode) 
        {
            //open db connection
            OracleConnection conn = new OracleConnection( DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT RegNum, Car_Make, Car_Model, TypeCode, Car_Description, FuelType, Num_Seats, Car_Status"
                + "FROM CARS Where TypeCode = '" + TypeCode + "' ORDER BY RegNum";
            
            //excute the sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand( sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "cars");

            //close conncection
            conn.Close ();

            return ds;
            }
        public void getCar(String RegNum)
        {
            //open db connection
            OracleConnection conn = new OracleConnection (DBConnect.oraDB);

            //define the sqlQuery to be excuted
            String sqlQuery = "SELECT * FROM CARS WHERE RegNum = '" + RegNum + "'";


            //execute the sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand (sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();

            //set the instance variables with values from data reader
            setregNum(dr.GetString(0));
            setdescription(dr.GetString(2));
            setTypeCode(dr.GetString(1));
            setnum_seats(dr.GetInt32(3));
            setmake(dr.GetString (4));
            setmodel(dr.GetString(5));  
            setfeulType(dr.GetString(6));  
            setstatus(dr.GetString(7));

            //close DB
            conn.Close();

        }
        public void addCar()
        {
            //open db connection
            OracleConnection conn  = new OracleConnection(DBConnect.oraDB);

            //define sql Query to be executed
            String sqlQuery = "INSERT INTO CARS Values ('" +
                            this.regNum + "','" +
                            this.typeCode + "','" +
                            this.description + "'," +
                            this.num_seats + ",'" +
                            this.model + "','" +
                            this.make + "','" +
                            this.fuelType + "','" +
                            this.status + "')";


            //execute the sql query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close the db connection
            conn.Close();

        }
        public void updateCar() 
        {
            //open a db connection
            OracleConnection conn = new OracleConnection (DBConnect.oraDB);

            //define the sql query to be executed 
            String sqlQuery = "UPDATE CARS SET " +
                            "RegNum = '" + this.regNum + "'," +
                            "TypeCode = '" + this.typeCode + "'," +
                            "Car_Description = '" + this.description + "'," +
                            "Num_Seats = " + this.num_seats + "," +
                            "Car_Model = '" + this.make + "'," +
                            "Car_Make = '" + this.model + "'," +
                            "Fuel_Type = '" + this.fuelType + "'," + 
                            "Car_Status = '" + this.status + "' " + 
                            "WHERE RegNum = '" + this.regNum + "'";

            //execute the sql Query(OracleCommand)
            OracleCommand cmd = new OracleCommand (sqlQuery, conn);
            conn.Open(); 
            
            cmd.ExecuteNonQuery();

            //close db connection
            conn.Close ();

        }
        public void updateCarStatus(string status, string regNum)
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed 
            String sqlQuery = "UPDATE CARS SET Car_Status = '" + status + "' WHERE RegNum = '" + regNum + "'";


            //execute the sql Query(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close db connection
            conn.Close();

        }
        public void removeCar(String RegNum)
        {
            //open db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed 
            String sqlQuery = "DELETE FROM Cars WHERE RegNum = '" + RegNum + "' ";

            //execute the sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

           cmd.ExecuteNonQuery ();

            //close db
            conn.Close();
        }
        public static DataSet findCar(String RegNum)
        {
            //open db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT RegNum, Car_Make, Car_Model, TypeCode, Car_Description, Fuel_Type, Num_Seats, Car_Status FROM CARS " +
                             "WHERE RegNum = '" + RegNum + "' " +  // Enclose RegNum value in single quotes
                              "ORDER BY RegNum";


            //execute the sql query (OracleCommand)
            OracleCommand cmd  = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "cars");

            //close db connection
            conn.Close();
            return ds;
        }
        public static String getNextRegNum(String regNum)
        {
            //open a db connection
            OracleConnection conn = new OracleConnection (DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT MAX(RegNum) FROM Cars";


            //executr the sql query command(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open ();


            OracleDataReader dr = cmd.ExecuteReader();

            //does dr contain a value or null?
            dr.Read();

            if (dr.IsDBNull(0))
                regNum = "";
            else
            {
                regNum = dr.GetString(0) + 1;
            }
            //close db connection
            conn.Close();
            return regNum;
        }
        public static String getCarStatus(String regNum)
        {
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "SELECT Status FROM Cars WHERE RegNum = '"+ regNum + "'";


            //executr the sql query command(OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();


            OracleDataReader dr = cmd.ExecuteReader();
            String status = "";

            //does dr contain a value or null?
            dr.Read();
            status = dr.GetString(0);
            //close db connection
            conn.Close();
            return status;

        }

    }
}
