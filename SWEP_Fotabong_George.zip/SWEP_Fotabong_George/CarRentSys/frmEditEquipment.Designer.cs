﻿namespace CarRentSys
{
    partial class frmEditEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            EquipmentID = new Label();
            grpEditEquip = new GroupBox();
            btnSubmit = new Button();
            txtStat = new TextBox();
            txtPrice = new TextBox();
            txtDescription = new TextBox();
            Status = new Label();
            Price = new Label();
            Description = new Label();
            grdEditEquip = new DataGridView();
            btnSearchEquip = new Button();
            cboEquipID = new ComboBox();
            grpEditEquip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdEditEquip).BeginInit();
            SuspendLayout();
            // 
            // EquipmentID
            // 
            EquipmentID.AutoSize = true;
            EquipmentID.Location = new Point(-4, 41);
            EquipmentID.Margin = new Padding(4, 0, 4, 0);
            EquipmentID.Name = "EquipmentID";
            EquipmentID.Size = new Size(160, 32);
            EquipmentID.TabIndex = 2;
            EquipmentID.Text = "Equipment ID";
            // 
            // grpEditEquip
            // 
            grpEditEquip.Controls.Add(btnSubmit);
            grpEditEquip.Controls.Add(txtStat);
            grpEditEquip.Controls.Add(txtPrice);
            grpEditEquip.Controls.Add(txtDescription);
            grpEditEquip.Controls.Add(Status);
            grpEditEquip.Controls.Add(Price);
            grpEditEquip.Controls.Add(Description);
            grpEditEquip.Location = new Point(13, 348);
            grpEditEquip.Margin = new Padding(4, 2, 4, 2);
            grpEditEquip.Name = "grpEditEquip";
            grpEditEquip.Padding = new Padding(4, 2, 4, 2);
            grpEditEquip.Size = new Size(1113, 791);
            grpEditEquip.TabIndex = 4;
            grpEditEquip.TabStop = false;
            grpEditEquip.Text = "Edit Equipment";
            grpEditEquip.Visible = false;
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(0, 644);
            btnSubmit.Margin = new Padding(4, 2, 4, 2);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(1113, 143);
            btnSubmit.TabIndex = 7;
            btnSubmit.Text = "Edit Equipment";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(112, 462);
            txtStat.Margin = new Padding(4, 2, 4, 2);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(45, 39);
            txtStat.TabIndex = 6;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(90, 295);
            txtPrice.Margin = new Padding(4, 2, 4, 2);
            txtPrice.MaxLength = 7;
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(119, 39);
            txtPrice.TabIndex = 5;
            txtPrice.Text = "0.00";
            txtPrice.TextAlign = HorizontalAlignment.Right;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(151, 137);
            txtDescription.Margin = new Padding(4, 2, 4, 2);
            txtDescription.MaxLength = 15;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(190, 39);
            txtDescription.TabIndex = 4;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(8, 466);
            Status.Margin = new Padding(4, 0, 4, 0);
            Status.Name = "Status";
            Status.Size = new Size(78, 32);
            Status.TabIndex = 2;
            Status.Text = "Status";
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Location = new Point(8, 304);
            Price.Margin = new Padding(4, 0, 4, 0);
            Price.Name = "Price";
            Price.Size = new Size(65, 32);
            Price.TabIndex = 1;
            Price.Text = "Price";
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(8, 137);
            Description.Margin = new Padding(4, 0, 4, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 0;
            Description.Text = "Description";
            // 
            // grdEditEquip
            // 
            grdEditEquip.AllowUserToAddRows = false;
            grdEditEquip.AllowUserToDeleteRows = false;
            grdEditEquip.BackgroundColor = SystemColors.ButtonHighlight;
            grdEditEquip.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdEditEquip.Location = new Point(-4, 117);
            grdEditEquip.Margin = new Padding(4, 2, 4, 2);
            grdEditEquip.Name = "grdEditEquip";
            grdEditEquip.RowHeadersWidth = 82;
            grdEditEquip.RowTemplate.Height = 41;
            grdEditEquip.Size = new Size(1130, 227);
            grdEditEquip.TabIndex = 5;
            grdEditEquip.Visible = false;
            grdEditEquip.CellClick += grdEditEquip_CellClick_1;
            // 
            // btnSearchEquip
            // 
            btnSearchEquip.ForeColor = SystemColors.Highlight;
            btnSearchEquip.Location = new Point(436, 26);
            btnSearchEquip.Margin = new Padding(4, 2, 4, 2);
            btnSearchEquip.Name = "btnSearchEquip";
            btnSearchEquip.Size = new Size(690, 73);
            btnSearchEquip.TabIndex = 8;
            btnSearchEquip.Text = "Search Equipment";
            btnSearchEquip.UseVisualStyleBackColor = true;
            btnSearchEquip.Click += btnSearchEquip_Click;
            // 
            // cboEquipID
            // 
            cboEquipID.DropDownStyle = ComboBoxStyle.DropDownList;
            cboEquipID.FormattingEnabled = true;
            cboEquipID.Location = new Point(164, 43);
            cboEquipID.Margin = new Padding(4, 2, 4, 2);
            cboEquipID.Name = "cboEquipID";
            cboEquipID.Size = new Size(242, 40);
            cboEquipID.TabIndex = 12;
            // 
            // frmEditEquipment
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1899, 1190);
            Controls.Add(cboEquipID);
            Controls.Add(btnSearchEquip);
            Controls.Add(grdEditEquip);
            Controls.Add(grpEditEquip);
            Controls.Add(EquipmentID);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmEditEquipment";
            Text = "frmEditEquipment";
            Load += frmEditEquipment_Load;
            grpEditEquip.ResumeLayout(false);
            grpEditEquip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdEditEquip).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label EquipmentID;
        private GroupBox grpEditEquip;
        private Button btnSubmit;
        private TextBox txtStat;
        private TextBox txtPrice;
        private TextBox txtDescription;
        private Label Status;
        private Label Price;
        private Label Description;
        private DataGridView grdEditEquip;
        private Button btnSearchEquip;
        private ComboBox cboEquipID;
    }
}