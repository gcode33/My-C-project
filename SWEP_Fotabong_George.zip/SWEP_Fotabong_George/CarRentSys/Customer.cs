﻿using Microsoft.VisualBasic.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentSys
{
    internal class Customer
    {
        private int custID;
        private String forename;
        private String surname;
        private String email;
        private long phoneNum;
        private string licenceNum;




        public Customer()
        {
            this.custID = 0;
            this.forename = "";
            this.surname = "";
            this.email = "";
            this.phoneNum = 0;
            this.licenceNum = "";
         

        }
        public Customer(int custID, string forename, string surname, string email, long phoneNum, string licenceNum)
        {
            this.custID = custID;
            this.forename = forename;
            this.surname = surname;
            this.email = email;
            this.phoneNum = phoneNum;
            this.licenceNum = licenceNum;
          
        }

        //getters
        public int getCustID() {  return custID; }
        public string getForname() { return forename; }
        public string getSurname() { return surname; }
        public String getEmail() { return email; }
        public long getPhoneNum() {  return phoneNum; }
        public string getLicenceNum() {  return licenceNum; }
    




        //setters

        public void setCustID(int CustID) { custID = CustID; }
        public void setForeName(String Forename) { forename = Forename; }
        public void setSurname(String Surname) { surname = Surname; }
        public void setEmail(String Email) {  email = Email; }
        public void setPhoneNum(long PhoneNum) {  phoneNum = PhoneNum; }
        public void setLicenceNum(string LicenceNum) {  licenceNum = LicenceNum;}
  


        public static DataSet getAllCustomer()
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "SELECT Cust_ID, Forename, Surname, Email,Phone_Num, Licence_Num, RentStart, ReturnDate " +
                "FROM Customer ORDER BY Surname";

            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "customer");

            //Close db connection
            conn.Close();

            return ds;
        }

        public void getCustomer(int CustID)
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "SELECT * FROM Customer WHERE Cust_ID = " + CustID;

            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();

            //set the instance variables with values from data reader
            setCustID(dr.GetInt32(0));
            setForeName(dr.GetString(1));
            setSurname(dr.GetString(2));
            setEmail(dr.GetString(3));
            setPhoneNum(dr.GetInt64(4));
            setLicenceNum(dr.GetString(5));
          

            //close DB
            conn.Close();
        }
        public void addCustomer()
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "INSERT INTO Customers (CustID, Forename, Surname, Email, Phone_Num, Licence_Num) VALUES (" +
                            this.custID + ",'" +
                            this.forename + "','" +
                            this.surname + "','" +
                            this.email + "'," +
                            this.phoneNum + ",'" +
                            this.licenceNum + "')";


            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //Close db connection
            conn.Close();
        }
        public static DataSet findCustomer(int CustID)
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "SELECT Cust_ID, Forename, Surname, Email,Phone_Num, Licence_Num, RentStart, ReturnDate " +
                "WHERE Cust_ID =  " + CustID + " ORDER BY Full_Name";

            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "customer");

            //Close db connection
            conn.Close();

            return ds;
        }

        public void RemoveCustomer(int CustID)
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define sql query to be executed
            String sqlQuery = "DELETE FROM Customers WHERE CustID = " + CustID;

            //execute sql query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            cmd.ExecuteNonQuery();

            //close connection
            conn.Close();
        }

        public static int getNextCustID()
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "SELECT MAX(CustID) FROM Customers";

            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();

            //Does dr contain a value or NULL?
            int nextId;
            dr.Read();

            if (dr.IsDBNull(0))
                nextId = 1;
            else
            {
                nextId = dr.GetInt32(0) + 1;
            }

            //Close db connection
            conn.Close();

            return nextId;
        }
        
    }
   
}
