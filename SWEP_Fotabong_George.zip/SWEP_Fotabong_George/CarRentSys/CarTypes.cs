﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CarRentSys
{
    internal class CarTypes
    {
        private String typeCode;
        private String description;
        private Decimal rate;

        public CarTypes()
        {
            this.typeCode = String.Empty;
            this.description = String.Empty;
            this.rate = 0;
        }
        public CarTypes(String typeCode, String description, Decimal rate)
        {
            this.typeCode = typeCode;
            this.description = description;
            this.rate = rate;
        }



        // getters
        public String getTypeCode() { return this.typeCode; }
        public String getDescription() { return this.description;}
        public Decimal getRate() { return this.rate;}



        // setters
        public CarTypes SetRate(Decimal rate) 
        {             
            this.rate = rate; 
            return this;
        }
        public CarTypes SetDescription(String description) {  
            this.description = description; 
            return this;
        }
        public CarTypes SettypeCode(String typeCode) 
        { 
                this.typeCode = typeCode; 
                return this;
        }




        //get all the car types with rates and descriptions
        public static DataSet getAllCarTypes()
        {
            // open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);
            
            //define the sql query to be executed
            String sqlQuery = "SELECT TypeCode, Type_Description, Rate " + "FROM CarTypes ORDER BY TypeCode";
            
            //execute the sql query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "CarType");

            //close the db connection
            conn.Close();
            return ds;
        }
        public static DataSet getAllCarTypes(String typeCode)
        {

            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);


            //define the sql query to be executed
            String sqlQuery = "SELECT TypeCode, Type_Description, Rate" + "FROM CarTypes WHERE TypeCode = '" + typeCode + "' ORDER BY TypeCode";

            //execute the sql query (OracleCommand)
            OracleCommand cmd=  new OracleCommand(sqlQuery, conn);

            OracleDataAdapter da = new OracleDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds, "CarType");

            //close connection
            conn.Close ();

            return ds;
        }


        public void addCarType()
        {
            //open db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //define the sql query to be executed
            String sqlQuery = "INSERT INTO CarTypes Values ('"+
                this.typeCode + "','"+
                this.description + "',"+
                this.rate + ")";

            //execute the sql query(Oracle command)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();   

            cmd.ExecuteNonQuery();

            //close a db connection
            conn.Close();
        }
        public static DataSet FindCarType(String typeCode)
        {

            //open a db connection
            OracleConnection conn = new OracleConnection (DBConnect.oraDB);


            //Define the sql query to be executed
            String sqlQuery = "SELECT TypeCode, Type_Description, Rate FROM CarType" + "WHERE TypeCode LIKE '%" + typeCode + "%'ORDER BY TypeCode";
            


            //execute the sql Query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            
            
            OracleDataAdapter  da = new OracleDataAdapter(cmd);


            DataSet ds = new DataSet ();
            da.Fill(ds, "CarType");

            //close connection
            conn.Close () ;

            return ds;

        }
        public void getCarType(String typeCode)
        {
            //open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB) ;

            //define sql query to be executed
            String sqlQuery = "SELECT * FROM CarType WHERE TypeCode = " + typeCode;


            //execute the sql query(OracleCommand)
            OracleCommand cmd = new OracleCommand (sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader ();
            dr.Read ();


            //set the instance variables with values from data reader(do this with the combo box stuff)
            SettypeCode(dr.GetString (0));
            SetDescription(dr.GetString (1));
            SetRate(dr.GetDecimal (2));

            //close db
            conn.Close ();

        }

    }
}
