﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmEditCar : Form
    {
        Cars theCar = new Cars();

        public frmEditCar()
        {
            InitializeComponent();
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validation
            if (cboRegNum.SelectedIndex == -1)
            {
                MessageBox.Show("please select a Registration number for a car to edit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboRegNum.Focus();
                return;
            }



            // Finding matching Cars based on regnum entered 
            grdCars.DataSource = Cars.findCar(cboRegNum.Text).Tables["cars"];

            //if there is no car with that regnum the display this message 
            if (grdCars.Rows.Count == 0)
            {
                MessageBox.Show("no data found for the registration number: " + cboRegNum.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboRegNum.Focus();
                cboRegNum.SelectedIndex=-1;
            }
            else
            {
                // If the code reaches here, it means the validation passed
                MessageBox.Show("Valid Registration number, car has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //make group box holding the grid box info visible 
                grdCars.Visible = true;
            }




        }

        private void grdCars_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //extract the RegNum from column zero on the slected rrow in grid
            String RegNum = grdCars.Rows[grdCars.CurrentCell.RowIndex].Cells[0].Value.ToString();


            //Instanciate theCar
            theCar.getCar(RegNum);


            //move the instance variable values to the form controls
            cboRegNum.Text = theCar.get_regNum();
            txtDescription.Text = theCar.getDescription();
            txtFuelType.Text = theCar.getFuelType();
            txtStat.Text = theCar.getStatus();

            //if the status of the Car is No A for available then send a message saying that the car cant be edited 
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this car may not be edited yet because it is currently in use please choose another car", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                cboRegNum.SelectedIndex = -1;
                txtStat.Clear();
                grpEditCar.Visible = false;
                grdCars.Visible = true;
            }
            else
            {
                //make the car data available for updating
                grpEditCar.Visible = true;
            }




            

        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //validating the new entered data
            if (txtDescription.Text.Equals("") || txtDescription.Text.Any(char.IsDigit) || txtDescription.Text.Length > 10)
            {
                MessageBox.Show("Desccription must be entered and must not include digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return;
            }
            if (txtFuelType.Text.Equals("") || txtFuelType.Text.Any(char.IsDigit) || txtFuelType.Text.Length > 1)
            {
                MessageBox.Show("Fuel type must be entered", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFuelType.Focus();
                return;
            }
            else if (!txtFuelType.Text.Equals("H", StringComparison.OrdinalIgnoreCase) &&
                     !txtFuelType.Text.Equals("G", StringComparison.OrdinalIgnoreCase) &&
                     !txtFuelType.Text.Equals("D", StringComparison.OrdinalIgnoreCase) &&
                     !txtFuelType.Text.Equals("E", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Invalid fuel type entered. Fuel type must be 'H', 'G', 'D', or 'E'.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFuelType.Focus();
                return;
            }

            //setting the status to A for available
            txtStat.Text = "A";

            //instanciate the object variables 
            theCar.setregNum(cboRegNum.Text.Substring(0));
            theCar.setdescription(txtDescription.Text);
            theCar.setfeulType(txtFuelType.Text);
            theCar.setstatus(txtStat.Text);


            //invoke the update car method to update the data in the database
            theCar.updateCar();


            //display confirmation message
            MessageBox.Show("Car Updated", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);


            //reset UI
            grpEditCar.Visible = false;
            grdCars.Visible = false;
            cboRegNum.SelectedIndex = -1;
            txtDescription.Clear();
        }

        private void frmEditCar_Load(object sender, EventArgs e)
        {
            cboRegNum = Utility.loadCombo(cboRegNum, "SELECT DISTINCT RegNum FROM CARS ORDER BY RegNum", 1);

        }
    }
}
