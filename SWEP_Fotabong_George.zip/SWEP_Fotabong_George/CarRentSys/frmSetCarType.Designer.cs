﻿namespace CarRentSys
{
    partial class frmSetCarType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSubmit = new Button();
            FuelType = new Label();
            grpRemCar = new GroupBox();
            txtDailyRate = new TextBox();
            txtDescription = new TextBox();
            txtType = new TextBox();
            DailyRate = new Label();
            Description = new Label();
            Type = new Label();
            grpRemCar.SuspendLayout();
            SuspendLayout();
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(0, 665);
            btnSubmit.Margin = new Padding(6);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(1215, 308);
            btnSubmit.TabIndex = 3;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // FuelType
            // 
            FuelType.AutoSize = true;
            FuelType.Location = new Point(-7, 503);
            FuelType.Margin = new Padding(6, 0, 6, 0);
            FuelType.Name = "FuelType";
            FuelType.Size = new Size(0, 32);
            FuelType.TabIndex = 9;
            // 
            // grpRemCar
            // 
            grpRemCar.Controls.Add(txtDailyRate);
            grpRemCar.Controls.Add(txtDescription);
            grpRemCar.Controls.Add(txtType);
            grpRemCar.Controls.Add(DailyRate);
            grpRemCar.Controls.Add(Description);
            grpRemCar.Controls.Add(Type);
            grpRemCar.Controls.Add(btnSubmit);
            grpRemCar.Location = new Point(13, 11);
            grpRemCar.Margin = new Padding(4, 2, 4, 2);
            grpRemCar.Name = "grpRemCar";
            grpRemCar.Padding = new Padding(4, 2, 4, 2);
            grpRemCar.Size = new Size(1215, 973);
            grpRemCar.TabIndex = 10;
            grpRemCar.TabStop = false;
            grpRemCar.Text = "Set Car Type";
            // 
            // txtDailyRate
            // 
            txtDailyRate.Location = new Point(153, 316);
            txtDailyRate.Margin = new Padding(6);
            txtDailyRate.MaxLength = 7;
            txtDailyRate.Name = "txtDailyRate";
            txtDailyRate.Size = new Size(95, 39);
            txtDailyRate.TabIndex = 12;
            txtDailyRate.Text = "0.00";
            txtDailyRate.TextAlign = HorizontalAlignment.Right;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(160, 211);
            txtDescription.Margin = new Padding(6);
            txtDescription.MaxLength = 10;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(171, 39);
            txtDescription.TabIndex = 11;
            // 
            // txtType
            // 
            txtType.Location = new Point(79, 124);
            txtType.Margin = new Padding(6);
            txtType.MaxLength = 4;
            txtType.Name = "txtType";
            txtType.Size = new Size(99, 39);
            txtType.TabIndex = 9;
            // 
            // DailyRate
            // 
            DailyRate.AutoSize = true;
            DailyRate.Location = new Point(10, 316);
            DailyRate.Margin = new Padding(6, 0, 6, 0);
            DailyRate.Name = "DailyRate";
            DailyRate.Size = new Size(121, 32);
            DailyRate.TabIndex = 10;
            DailyRate.Text = "Daily Rate";
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(10, 211);
            Description.Margin = new Padding(6, 0, 6, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 8;
            Description.Text = "Description";
            // 
            // Type
            // 
            Type.AutoSize = true;
            Type.Location = new Point(10, 124);
            Type.Margin = new Padding(6, 0, 6, 0);
            Type.Name = "Type";
            Type.Size = new Size(65, 32);
            Type.TabIndex = 7;
            Type.Text = "Type";
            // 
            // frmSetCarType
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1871, 1136);
            Controls.Add(grpRemCar);
            Controls.Add(FuelType);
            Margin = new Padding(6);
            Name = "frmSetCarType";
            Text = "Car Rentals - [Set Car Type]";
            grpRemCar.ResumeLayout(false);
            grpRemCar.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnSubmit;
        private Label FuelType;
        private GroupBox grpRemCar;
        private TextBox txtDailyRate;
        private TextBox txtDescription;
        private TextBox txtType;
        private Label DailyRate;
        private Label Description;
        private Label Type;
    }
}