﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmRemoveEquipment : Form
    {
        //creating a variable named equip of type Equipment and initializes it with a new instance of the Equipment class.
        Equipment equip = new Equipment();
        public frmRemoveEquipment()
        {
            InitializeComponent();
        }



        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validate data enterd 
            if (cboEquipID.SelectedIndex == -1)
            {
                MessageBox.Show("please select a equipment ID number for an equipment to edit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboEquipID.Focus();
                return;
            }


            // filling the grid box with the equipment info based on the EquipID
            grdRemoveEquip.DataSource = Equipment.findEquipment(int.Parse(cboEquipID.Text)).Tables["Equipment"];

            if (grdRemoveEquip.Rows.Count == 0)
            {
                MessageBox.Show("no data found for the Equip ID: " + cboEquipID.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboEquipID.Focus();
                cboEquipID.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Valid Equipment ID, Equipment has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //make grid box holding the info visible
                grdRemoveEquip.Visible = true;
            }
        }


        private void btnRemove_Click(object sender, EventArgs e)
        {
            //yes or no message to confirm removal
            DialogResult answer = MessageBox.Show("Are you sure you want to remove the Equipment : " + cboEquipID.Text, "Confirm",
  MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                equip.removeEquipment(int.Parse(cboEquipID.Text));

                //confirmation message of removal 
                MessageBox.Show("The Equipment: " + cboEquipID.Text + " has been Removed from the Equipment file and status has been set to R for removed", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //reset UI
                grpRemEquip.Visible = false;
                grdRemoveEquip.Visible = false;
                cboEquipID.SelectedIndex = -1;
            }
            //if no reset the UI
            grpRemEquip.Visible = false;
            grdRemoveEquip.Visible = false;
            cboEquipID.SelectedIndex = -1;
        }

        private void grdRemoveEquip_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //extract the equipId from column zero on the selected row in grid
            int EquipID = Convert.ToInt32(grdRemoveEquip.Rows[grdRemoveEquip.CurrentCell.RowIndex].Cells[0].Value.ToString());


            //Instanciate equip
            equip.getEquipment(EquipID);


            //move the instance variable values to the form controls
            cboEquipID.Text = equip.getEquipID().ToString("000000000");
            txtStat.Text = equip.getStatus().ToString();

            //if the status is not Avalaibale("A") then send error message 
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this car may not be removed yet because it is currently in use please choose another car", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                cboEquipID.SelectedIndex = -1;
                txtStat.Clear();


            }
            else
            {
                grpRemEquip.Visible = true;

            }
            //make the group box with the remove button visible 
        }

        private void frmRemoveEquipment_Load(object sender, EventArgs e)
        {
            cboEquipID = Utility.loadCombo(cboEquipID, "SELECT DISTINCT EquipID FROM EQUIPMENT ORDER BY EquipID", 1);

        }
    }
}
