﻿
namespace CarRentSys
{
    partial class frmAddCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Description = new Label();
            Type = new Label();
            NumSeats = new Label();
            RegNum = new Label();
            txtDescription = new TextBox();
            txtRegNum = new TextBox();
            btnSubmit = new Button();
            cboTypes = new ComboBox();
            grpAddCar = new GroupBox();
            cboFuel = new ComboBox();
            cboNumSeats = new ComboBox();
            cboModel = new ComboBox();
            cboMake = new ComboBox();
            txtStat = new TextBox();
            lblStat = new Label();
            FuelType = new Label();
            Model = new Label();
            Make = new Label();
            TypeCode = new Label();
            grpAddCar.SuspendLayout();
            SuspendLayout();
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(0, 239);
            Description.Margin = new Padding(4, 0, 4, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 0;
            Description.Text = "Description";
            // 
            // Type
            // 
            Type.AutoSize = true;
            Type.Location = new Point(0, 154);
            Type.Margin = new Padding(4, 0, 4, 0);
            Type.Name = "Type";
            Type.Size = new Size(178, 32);
            Type.TabIndex = 1;
            Type.Text = "Select Car Type";
            // 
            // NumSeats
            // 
            NumSeats.AutoSize = true;
            NumSeats.Location = new Point(0, 314);
            NumSeats.Margin = new Padding(4, 0, 4, 0);
            NumSeats.Name = "NumSeats";
            NumSeats.Size = new Size(191, 32);
            NumSeats.TabIndex = 2;
            NumSeats.Text = "Number of seats";
            // 
            // RegNum
            // 
            RegNum.AutoSize = true;
            RegNum.Location = new Point(-6, 66);
            RegNum.Margin = new Padding(4, 0, 4, 0);
            RegNum.Name = "RegNum";
            RegNum.Size = new Size(235, 32);
            RegNum.TabIndex = 3;
            RegNum.Text = "Registration Number";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(134, 232);
            txtDescription.Margin = new Padding(6);
            txtDescription.MaxLength = 20;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(218, 39);
            txtDescription.TabIndex = 5;
            // 
            // txtRegNum
            // 
            txtRegNum.Location = new Point(240, 64);
            txtRegNum.Margin = new Padding(6);
            txtRegNum.MaxLength = 10;
            txtRegNum.Name = "txtRegNum";
            txtRegNum.Size = new Size(141, 39);
            txtRegNum.TabIndex = 8;
            txtRegNum.TextAlign = HorizontalAlignment.Right;
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(0, 715);
            btnSubmit.Margin = new Padding(6);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(1737, 287);
            btnSubmit.TabIndex = 9;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // cboTypes
            // 
            cboTypes.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTypes.FormattingEnabled = true;
            cboTypes.Location = new Point(186, 151);
            cboTypes.Margin = new Padding(4, 2, 4, 2);
            cboTypes.Name = "cboTypes";
            cboTypes.Size = new Size(242, 40);
            cboTypes.TabIndex = 10;
            // 
            // grpAddCar
            // 
            grpAddCar.Controls.Add(cboFuel);
            grpAddCar.Controls.Add(cboNumSeats);
            grpAddCar.Controls.Add(cboModel);
            grpAddCar.Controls.Add(cboMake);
            grpAddCar.Controls.Add(txtStat);
            grpAddCar.Controls.Add(lblStat);
            grpAddCar.Controls.Add(txtRegNum);
            grpAddCar.Controls.Add(RegNum);
            grpAddCar.Controls.Add(Type);
            grpAddCar.Controls.Add(cboTypes);
            grpAddCar.Controls.Add(FuelType);
            grpAddCar.Controls.Add(Model);
            grpAddCar.Controls.Add(Make);
            grpAddCar.Controls.Add(TypeCode);
            grpAddCar.Controls.Add(NumSeats);
            grpAddCar.Controls.Add(btnSubmit);
            grpAddCar.Controls.Add(Description);
            grpAddCar.Controls.Add(txtDescription);
            grpAddCar.Location = new Point(-1, 2);
            grpAddCar.Margin = new Padding(4, 2, 4, 2);
            grpAddCar.Name = "grpAddCar";
            grpAddCar.Padding = new Padding(4, 2, 4, 2);
            grpAddCar.Size = new Size(1737, 1001);
            grpAddCar.TabIndex = 11;
            grpAddCar.TabStop = false;
            grpAddCar.Text = "Add Car details ";
            // 
            // cboFuel
            // 
            cboFuel.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFuel.FormattingEnabled = true;
            cboFuel.Location = new Point(121, 544);
            cboFuel.Margin = new Padding(4, 2, 4, 2);
            cboFuel.Name = "cboFuel";
            cboFuel.Size = new Size(70, 40);
            cboFuel.TabIndex = 26;
            // 
            // cboNumSeats
            // 
            cboNumSeats.DropDownStyle = ComboBoxStyle.DropDownList;
            cboNumSeats.FormattingEnabled = true;
            cboNumSeats.Items.AddRange(new object[] { "2", "4", "5", "6", "7", "8" });
            cboNumSeats.Location = new Point(186, 311);
            cboNumSeats.Margin = new Padding(4, 2, 4, 2);
            cboNumSeats.Name = "cboNumSeats";
            cboNumSeats.Size = new Size(145, 40);
            cboNumSeats.TabIndex = 25;
            // 
            // cboModel
            // 
            cboModel.DropDownStyle = ComboBoxStyle.DropDownList;
            cboModel.Enabled = false;
            cboModel.FormattingEnabled = true;
            cboModel.Location = new Point(84, 471);
            cboModel.Margin = new Padding(4, 2, 4, 2);
            cboModel.Name = "cboModel";
            cboModel.Size = new Size(145, 40);
            cboModel.TabIndex = 24;
            // 
            // cboMake
            // 
            cboMake.DropDownStyle = ComboBoxStyle.DropDownList;
            cboMake.FormattingEnabled = true;
            cboMake.Location = new Point(75, 390);
            cboMake.Margin = new Padding(4, 2, 4, 2);
            cboMake.Name = "cboMake";
            cboMake.Size = new Size(154, 40);
            cboMake.TabIndex = 23;
            cboMake.SelectedIndexChanged += cboMake_SelectedIndexChanged;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(121, 638);
            txtStat.Margin = new Padding(6);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(50, 39);
            txtStat.TabIndex = 22;
            // 
            // lblStat
            // 
            lblStat.AutoSize = true;
            lblStat.Location = new Point(-6, 638);
            lblStat.Margin = new Padding(6, 0, 6, 0);
            lblStat.Name = "lblStat";
            lblStat.Size = new Size(78, 32);
            lblStat.TabIndex = 21;
            lblStat.Text = "Status";
            // 
            // FuelType
            // 
            FuelType.AutoSize = true;
            FuelType.Location = new Point(-6, 544);
            FuelType.Margin = new Padding(6, 0, 6, 0);
            FuelType.Name = "FuelType";
            FuelType.Size = new Size(117, 32);
            FuelType.TabIndex = 17;
            FuelType.Text = "Fuel Type";
            // 
            // Model
            // 
            Model.AutoSize = true;
            Model.Location = new Point(0, 474);
            Model.Margin = new Padding(6, 0, 6, 0);
            Model.Name = "Model";
            Model.Size = new Size(83, 32);
            Model.TabIndex = 16;
            Model.Text = "Model";
            // 
            // Make
            // 
            Make.AutoSize = true;
            Make.Location = new Point(0, 390);
            Make.Margin = new Padding(6, 0, 6, 0);
            Make.Name = "Make";
            Make.Size = new Size(73, 32);
            Make.TabIndex = 15;
            Make.Text = "Make";
            // 
            // TypeCode
            // 
            TypeCode.AutoSize = true;
            TypeCode.Location = new Point(0, 70);
            TypeCode.Margin = new Padding(4, 0, 4, 0);
            TypeCode.Name = "TypeCode";
            TypeCode.Size = new Size(0, 32);
            TypeCode.TabIndex = 11;
            // 
            // frmAddCar
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(2292, 1264);
            Controls.Add(grpAddCar);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmAddCar";
            Text = "Car Rentals - [Add Car]";
            Load += frmAddCar_Load;
            grpAddCar.ResumeLayout(false);
            grpAddCar.PerformLayout();
            ResumeLayout(false);
        }



        #endregion

        private Label Description;
        private Label Type;
        private Label NumSeats;
        private Label RegNum;
        private TextBox txtDescription;
        private TextBox txtRegNum;
        private Button btnSubmit;
        private ComboBox cboTypes;
        private GroupBox grpAddCar;
        private Label TypeCode;
        private Label FuelType;
        private Label Model;
        private Label Make;
        private TextBox txtStat;
        private Label lblStat;
        private ComboBox cboModel;
        private ComboBox cboMake;
        private ComboBox cboNumSeats;
        private ComboBox cboFuel;
    }
}