﻿namespace CarRentSys
{
    partial class frmCollectCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CustID = new Label();
            Rentalnumber = new Label();
            btnSearch = new Button();
            btnCollectCar = new Button();
            lblStatus = new Label();
            txtStatus = new TextBox();
            grpSearchRental = new GroupBox();
            cboRentNum = new ComboBox();
            cboCustID = new ComboBox();
            grpCollectCar = new GroupBox();
            grdRentals = new DataGridView();
            grpRentalInfo = new GroupBox();
            grpSearchRental.SuspendLayout();
            grpCollectCar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRentals).BeginInit();
            grpRentalInfo.SuspendLayout();
            SuspendLayout();
            // 
            // CustID
            // 
            CustID.AutoSize = true;
            CustID.Location = new Point(0, 62);
            CustID.Margin = new Padding(6, 0, 6, 0);
            CustID.Name = "CustID";
            CustID.Size = new Size(147, 32);
            CustID.TabIndex = 0;
            CustID.Text = "Customer ID";
            // 
            // Rentalnumber
            // 
            Rentalnumber.AutoSize = true;
            Rentalnumber.Location = new Point(529, 64);
            Rentalnumber.Margin = new Padding(6, 0, 6, 0);
            Rentalnumber.Name = "Rentalnumber";
            Rentalnumber.Size = new Size(175, 32);
            Rentalnumber.TabIndex = 1;
            Rentalnumber.Text = "Rental Number";
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(0, 162);
            btnSearch.Margin = new Padding(6);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(1073, 77);
            btnSearch.TabIndex = 4;
            btnSearch.Text = "Search Customer";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnCollectCar
            // 
            btnCollectCar.ForeColor = SystemColors.Highlight;
            btnCollectCar.Location = new Point(0, 31);
            btnCollectCar.Margin = new Padding(6);
            btnCollectCar.Name = "btnCollectCar";
            btnCollectCar.Size = new Size(1044, 157);
            btnCollectCar.TabIndex = 5;
            btnCollectCar.Text = "Collect Car";
            btnCollectCar.UseVisualStyleBackColor = true;
            btnCollectCar.Click += btnCollectCar_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(0, 230);
            lblStatus.Margin = new Padding(6, 0, 6, 0);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(78, 32);
            lblStatus.TabIndex = 10;
            lblStatus.Text = "Status";
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(86, 223);
            txtStatus.Margin = new Padding(6);
            txtStatus.MaxLength = 1;
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(50, 39);
            txtStatus.TabIndex = 11;
            // 
            // grpSearchRental
            // 
            grpSearchRental.Controls.Add(cboRentNum);
            grpSearchRental.Controls.Add(cboCustID);
            grpSearchRental.Controls.Add(btnSearch);
            grpSearchRental.Controls.Add(CustID);
            grpSearchRental.Controls.Add(Rentalnumber);
            grpSearchRental.Location = new Point(4, 26);
            grpSearchRental.Margin = new Padding(6);
            grpSearchRental.Name = "grpSearchRental";
            grpSearchRental.Padding = new Padding(6);
            grpSearchRental.Size = new Size(1073, 250);
            grpSearchRental.TabIndex = 12;
            grpSearchRental.TabStop = false;
            grpSearchRental.Text = "Search Rental";
            // 
            // cboRentNum
            // 
            cboRentNum.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRentNum.Enabled = false;
            cboRentNum.FormattingEnabled = true;
            cboRentNum.Location = new Point(699, 61);
            cboRentNum.Margin = new Padding(4, 2, 4, 2);
            cboRentNum.Name = "cboRentNum";
            cboRentNum.Size = new Size(145, 40);
            cboRentNum.TabIndex = 27;
            // 
            // cboCustID
            // 
            cboCustID.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCustID.FormattingEnabled = true;
            cboCustID.Location = new Point(157, 56);
            cboCustID.Margin = new Padding(4, 2, 4, 2);
            cboCustID.Name = "cboCustID";
            cboCustID.Size = new Size(145, 40);
            cboCustID.TabIndex = 26;
            cboCustID.SelectedIndexChanged += cboCustID_SelectedIndexChanged;
            // 
            // grpCollectCar
            // 
            grpCollectCar.Controls.Add(btnCollectCar);
            grpCollectCar.Controls.Add(lblStatus);
            grpCollectCar.Controls.Add(txtStatus);
            grpCollectCar.Location = new Point(15, 851);
            grpCollectCar.Margin = new Padding(6);
            grpCollectCar.Name = "grpCollectCar";
            grpCollectCar.Padding = new Padding(6);
            grpCollectCar.Size = new Size(1044, 269);
            grpCollectCar.TabIndex = 13;
            grpCollectCar.TabStop = false;
            grpCollectCar.Text = "Collect Car";
            grpCollectCar.Visible = false;
            // 
            // grdRentals
            // 
            grdRentals.BackgroundColor = SystemColors.ButtonHighlight;
            grdRentals.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRentals.Location = new Point(11, 47);
            grdRentals.Margin = new Padding(6);
            grdRentals.Name = "grdRentals";
            grdRentals.RowHeadersWidth = 82;
            grdRentals.RowTemplate.Height = 25;
            grdRentals.Size = new Size(1062, 371);
            grdRentals.TabIndex = 14;
            grdRentals.CellClick += grdRentals_CellClick;
            // 
            // grpRentalInfo
            // 
            grpRentalInfo.Controls.Add(grdRentals);
            grpRentalInfo.Location = new Point(4, 346);
            grpRentalInfo.Margin = new Padding(6);
            grpRentalInfo.Name = "grpRentalInfo";
            grpRentalInfo.Padding = new Padding(6);
            grpRentalInfo.Size = new Size(1073, 425);
            grpRentalInfo.TabIndex = 15;
            grpRentalInfo.TabStop = false;
            grpRentalInfo.Text = "Rental Information";
            grpRentalInfo.Visible = false;
            // 
            // frmCollectCar
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1920, 1248);
            Controls.Add(grpRentalInfo);
            Controls.Add(grpCollectCar);
            Controls.Add(grpSearchRental);
            Margin = new Padding(6);
            Name = "frmCollectCar";
            Text = "frmCollectCar";
            Load += frmCollectCar_Load;
            grpSearchRental.ResumeLayout(false);
            grpSearchRental.PerformLayout();
            grpCollectCar.ResumeLayout(false);
            grpCollectCar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdRentals).EndInit();
            grpRentalInfo.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label CustID;
        private Label Rentalnumber;
        private Button btnSearch;
        private Button btnCollectCar;
        private Label lblStatus;
        private TextBox txtStatus;
        private GroupBox grpSearchRental;
        private GroupBox grpCollectCar;
        private DataGridView grdRentals;
        private GroupBox grpRentalInfo;
        private ComboBox cboRentNum;
        private ComboBox cboCustID;
    }
}