﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmEditEquipment : Form
    {
        Equipment equip = new Equipment();
        public frmEditEquipment()
        {
            InitializeComponent();
        }

        private void btnSearchEquip_Click(object sender, EventArgs e)
        {
            //validation
            if (cboEquipID.SelectedIndex == -1)
            {
                MessageBox.Show("please select a equipment ID number for an equipment to edit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboEquipID.Focus();
                return;
            }


            // Finding matching products based on the info provided (EquipID) using the find equipment method
            grdEditEquip.DataSource = Equipment.findEquipment(int.Parse(cboEquipID.Text)).Tables["equipment"];

            //if no data is found then display this message 
            if (grdEditEquip.Rows.Count == 0)
            {
                MessageBox.Show("no data found for the Equip ID: " + cboEquipID.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboEquipID.Focus();
                cboEquipID.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Valid Equipment ID, Equipment has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //make grid box holding the info visible
                grdEditEquip.Visible = true;
            }





        }



        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //validate data enterd 
            if (txtDescription.Text.Equals("") || txtDescription.Text.Any(char.IsDigit) || txtDescription.Text.Length > 10)
            {
                MessageBox.Show("Description must be entered and must not include digits and no more than ten characters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return;
            }
            if (txtPrice.Text.Equals("") || txtPrice.Text.All(char.IsLetter) || txtPrice.Text.StartsWith("-") || txtPrice.Text.Length > 6)
            {
                MessageBox.Show("Cannot enter a negative number and must be a digit and no more than 6 numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPrice.Focus();
                return;
            }







            //instanciate the object variables 
            equip.setDescription(txtDescription.Text);
            equip.setPrice(decimal.Parse(txtPrice.Text));
            equip.setStatus(txtStat.Text);




            //invoke the update equipment method to update the data in the database
            equip.updateEquipment();


            //display confirmation message
            MessageBox.Show("Equipment Updated", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);


            //reset UI
            grpEditEquip.Visible = false;
            grdEditEquip.Visible = false;
            cboEquipID.SelectedIndex = -1;
            txtStat.Clear();
        }

        private void grdEditEquip_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //extract the equipId from column zero on the selected row in grid
            int EquipID = Convert.ToInt32(grdEditEquip.Rows[grdEditEquip.CurrentCell.RowIndex].Cells[0].Value.ToString());

            grpEditEquip.Visible = true;
            //Instanciate equip
            equip.getEquipment(EquipID);


            //move the instance variable values to the form controls
            txtDescription.Text = equip.getDescription();
            txtPrice.Text = equip.getPrice().ToString("0.00");
            txtStat.Text = equip.getStatus().ToString();

            //if the status is not Avalaibale("A") then send erroe message 
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this Equipment may not be edited yet because it is currently in use please choose another Equipment", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                cboEquipID.SelectedIndex = -1;
                txtStat.Clear();
                grpEditEquip.Visible = false;
                grdEditEquip.Visible = false;

            }




        }

        private void frmEditEquipment_Load(object sender, EventArgs e)
        {
            cboEquipID = Utility.loadCombo(cboEquipID, "SELECT DISTINCT EquipID FROM EQUIPMENT ORDER BY EquipID", 1);

        }
    }
}
