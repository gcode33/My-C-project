﻿namespace CarRentSys
{
    partial class frmCustomerAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            grpSearch = new GroupBox();
            cboYears = new ComboBox();
            btnSearchYear = new Button();
            YEAR = new Label();
            grpPrint = new GroupBox();
            btnPrint = new Button();
            ChrtCust = new System.Windows.Forms.DataVisualization.Charting.Chart();
            grpChart = new GroupBox();
            grpSearch.SuspendLayout();
            grpPrint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ChrtCust).BeginInit();
            grpChart.SuspendLayout();
            SuspendLayout();
            // 
            // grpSearch
            // 
            grpSearch.Controls.Add(cboYears);
            grpSearch.Controls.Add(btnSearchYear);
            grpSearch.Controls.Add(YEAR);
            grpSearch.Location = new Point(11, 38);
            grpSearch.Margin = new Padding(4, 2, 4, 2);
            grpSearch.Name = "grpSearch";
            grpSearch.Padding = new Padding(4, 2, 4, 2);
            grpSearch.Size = new Size(594, 141);
            grpSearch.TabIndex = 13;
            grpSearch.TabStop = false;
            grpSearch.Text = "Find Cars";
            // 
            // cboYears
            // 
            cboYears.DropDownStyle = ComboBoxStyle.DropDownList;
            cboYears.FormattingEnabled = true;
            cboYears.Location = new Point(72, 51);
            cboYears.Margin = new Padding(4, 2, 4, 2);
            cboYears.Name = "cboYears";
            cboYears.Size = new Size(123, 40);
            cboYears.TabIndex = 16;
            // 
            // btnSearchYear
            // 
            btnSearchYear.ForeColor = SystemColors.Highlight;
            btnSearchYear.Location = new Point(232, 20);
            btnSearchYear.Margin = new Padding(6, 6, 6, 6);
            btnSearchYear.Name = "btnSearchYear";
            btnSearchYear.Size = new Size(362, 121);
            btnSearchYear.TabIndex = 15;
            btnSearchYear.Text = "Search";
            btnSearchYear.UseVisualStyleBackColor = true;
            btnSearchYear.Click += btnSearchYear_Click;
            // 
            // YEAR
            // 
            YEAR.AutoSize = true;
            YEAR.Location = new Point(9, 58);
            YEAR.Margin = new Padding(6, 0, 6, 0);
            YEAR.Name = "YEAR";
            YEAR.Size = new Size(58, 32);
            YEAR.TabIndex = 11;
            YEAR.Text = "Year";
            // 
            // grpPrint
            // 
            grpPrint.Controls.Add(btnPrint);
            grpPrint.Location = new Point(11, 410);
            grpPrint.Margin = new Padding(4, 2, 4, 2);
            grpPrint.Name = "grpPrint";
            grpPrint.Padding = new Padding(4, 2, 4, 2);
            grpPrint.Size = new Size(594, 173);
            grpPrint.TabIndex = 14;
            grpPrint.TabStop = false;
            grpPrint.Text = "Print";
            grpPrint.Visible = false;
            // 
            // btnPrint
            // 
            btnPrint.ForeColor = SystemColors.Highlight;
            btnPrint.Location = new Point(-6, 36);
            btnPrint.Margin = new Padding(6, 6, 6, 6);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(600, 137);
            btnPrint.TabIndex = 13;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            // 
            // ChrtCust
            // 
            chartArea1.Name = "ChartArea1";
            ChrtCust.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            ChrtCust.Legends.Add(legend1);
            ChrtCust.Location = new Point(24, 38);
            ChrtCust.Margin = new Padding(4, 2, 4, 2);
            ChrtCust.Name = "ChrtCust";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            ChrtCust.Series.Add(series1);
            ChrtCust.Size = new Size(1307, 879);
            ChrtCust.TabIndex = 11;
            ChrtCust.Text = "Customer Analysis";
            // 
            // grpChart
            // 
            grpChart.Controls.Add(ChrtCust);
            grpChart.Location = new Point(791, 58);
            grpChart.Margin = new Padding(4, 2, 4, 2);
            grpChart.Name = "grpChart";
            grpChart.Padding = new Padding(4, 2, 4, 2);
            grpChart.Size = new Size(1339, 943);
            grpChart.TabIndex = 15;
            grpChart.TabStop = false;
            grpChart.Text = "Chart";
            grpChart.Visible = false;
            // 
            // frmCustomerAnalysis
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(2151, 1052);
            Controls.Add(grpChart);
            Controls.Add(grpPrint);
            Controls.Add(grpSearch);
            Margin = new Padding(6, 6, 6, 6);
            Name = "frmCustomerAnalysis";
            Text = "frmCustomerAnalysis";
            grpSearch.ResumeLayout(false);
            grpSearch.PerformLayout();
            grpPrint.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ChrtCust).EndInit();
            grpChart.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private GroupBox grpSearch;
        private Button btnSearchYear;
        private Label YEAR;
        private GroupBox grpPrint;
        private Button btnPrint;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChrtCust;
        private GroupBox grpChart;
        private ComboBox cboYears;
    }
}