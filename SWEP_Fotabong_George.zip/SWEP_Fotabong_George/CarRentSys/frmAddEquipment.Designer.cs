﻿namespace CarRentSys
{
    partial class frmAddEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            EquipName = new Label();
            EquipDesc = new Label();
            Price = new Label();
            EquipID = new Label();
            txtEquipName = new TextBox();
            txtEquipDesc = new TextBox();
            txtPrc = new TextBox();
            txtEquipId = new TextBox();
            btnAddEquip = new Button();
            label1 = new Label();
            txtStat = new TextBox();
            SuspendLayout();
            // 
            // EquipName
            // 
            EquipName.AutoSize = true;
            EquipName.Location = new Point(4, 64);
            EquipName.Margin = new Padding(6, 0, 6, 0);
            EquipName.Name = "EquipName";
            EquipName.Size = new Size(197, 32);
            EquipName.TabIndex = 0;
            EquipName.Text = "Equipment name";
            // 
            // EquipDesc
            // 
            EquipDesc.AutoSize = true;
            EquipDesc.Location = new Point(4, 158);
            EquipDesc.Margin = new Padding(6, 0, 6, 0);
            EquipDesc.Name = "EquipDesc";
            EquipDesc.Size = new Size(258, 32);
            EquipDesc.TabIndex = 1;
            EquipDesc.Text = "Equipment Description";
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Location = new Point(4, 247);
            Price.Margin = new Padding(6, 0, 6, 0);
            Price.Name = "Price";
            Price.Size = new Size(65, 32);
            Price.TabIndex = 2;
            Price.Text = "Price";
            // 
            // EquipID
            // 
            EquipID.AutoSize = true;
            EquipID.Location = new Point(4, 337);
            EquipID.Margin = new Padding(6, 0, 6, 0);
            EquipID.Name = "EquipID";
            EquipID.Size = new Size(160, 32);
            EquipID.TabIndex = 3;
            EquipID.Text = "Equipment ID";
            // 
            // txtEquipName
            // 
            txtEquipName.Location = new Point(197, 58);
            txtEquipName.Margin = new Padding(6);
            txtEquipName.MaxLength = 15;
            txtEquipName.Name = "txtEquipName";
            txtEquipName.Size = new Size(210, 39);
            txtEquipName.TabIndex = 4;
            // 
            // txtEquipDesc
            // 
            txtEquipDesc.Location = new Point(260, 155);
            txtEquipDesc.Margin = new Padding(6);
            txtEquipDesc.MaxLength = 15;
            txtEquipDesc.Name = "txtEquipDesc";
            txtEquipDesc.Size = new Size(218, 39);
            txtEquipDesc.TabIndex = 5;
            // 
            // txtPrc
            // 
            txtPrc.Location = new Point(76, 241);
            txtPrc.Margin = new Padding(6);
            txtPrc.MaxLength = 7;
            txtPrc.Name = "txtPrc";
            txtPrc.Size = new Size(106, 39);
            txtPrc.TabIndex = 6;
            txtPrc.Text = "0.00";
            txtPrc.TextAlign = HorizontalAlignment.Right;
            // 
            // txtEquipId
            // 
            txtEquipId.Location = new Point(171, 331);
            txtEquipId.Margin = new Padding(6);
            txtEquipId.MaxLength = 10;
            txtEquipId.Name = "txtEquipId";
            txtEquipId.ReadOnly = true;
            txtEquipId.Size = new Size(214, 39);
            txtEquipId.TabIndex = 7;
            // 
            // btnAddEquip
            // 
            btnAddEquip.ForeColor = SystemColors.Highlight;
            btnAddEquip.Location = new Point(1, 585);
            btnAddEquip.Margin = new Padding(6);
            btnAddEquip.Name = "btnAddEquip";
            btnAddEquip.Size = new Size(894, 360);
            btnAddEquip.TabIndex = 8;
            btnAddEquip.Text = "Add Equipment";
            btnAddEquip.UseVisualStyleBackColor = true;
            btnAddEquip.Click += btnAddEquip_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(4, 431);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(78, 32);
            label1.TabIndex = 9;
            label1.Text = "Status";
            // 
            // txtStat
            // 
            txtStat.Location = new Point(95, 427);
            txtStat.Margin = new Padding(6);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(52, 39);
            txtStat.TabIndex = 10;
            // 
            // frmAddEquipment
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1899, 1193);
            Controls.Add(txtStat);
            Controls.Add(label1);
            Controls.Add(btnAddEquip);
            Controls.Add(txtEquipId);
            Controls.Add(txtPrc);
            Controls.Add(txtEquipDesc);
            Controls.Add(txtEquipName);
            Controls.Add(EquipID);
            Controls.Add(Price);
            Controls.Add(EquipDesc);
            Controls.Add(EquipName);
            Margin = new Padding(6);
            Name = "frmAddEquipment";
            Text = "frmAddEquipment";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label EquipName;
        private Label EquipDesc;
        private Label Price;
        private Label EquipID;
        private TextBox txtEquipName;
        private TextBox txtEquipDesc;
        private TextBox txtPrc;
        private TextBox txtEquipId;
        private Button btnAddEquip;
        private Label label1;
        private TextBox txtStat;
    }
}