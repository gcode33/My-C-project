﻿namespace CarRentSys
{
    partial class frmMonthlyRevenueAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            YEAR = new Label();
            btnPrint = new Button();
            ChrtRev = new System.Windows.Forms.DataVisualization.Charting.Chart();
            cboYears = new ComboBox();
            grpChart = new GroupBox();
            grpPrint = new GroupBox();
            btnSearch = new Button();
            ((System.ComponentModel.ISupportInitialize)ChrtRev).BeginInit();
            grpChart.SuspendLayout();
            grpPrint.SuspendLayout();
            SuspendLayout();
            // 
            // YEAR
            // 
            YEAR.AutoSize = true;
            YEAR.Location = new Point(0, 73);
            YEAR.Margin = new Padding(6, 0, 6, 0);
            YEAR.Name = "YEAR";
            YEAR.Size = new Size(58, 32);
            YEAR.TabIndex = 2;
            YEAR.Text = "Year";
            // 
            // btnPrint
            // 
            btnPrint.ForeColor = SystemColors.Highlight;
            btnPrint.Location = new Point(10, 29);
            btnPrint.Margin = new Padding(6);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(841, 186);
            btnPrint.TabIndex = 10;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            btnPrint.Click += btnPrint_Click;
            // 
            // ChrtRev
            // 
            chartArea1.Name = "ChartArea1";
            ChrtRev.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            ChrtRev.Legends.Add(legend1);
            ChrtRev.Location = new Point(0, 39);
            ChrtRev.Margin = new Padding(4, 2, 4, 2);
            ChrtRev.Name = "ChrtRev";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            ChrtRev.Series.Add(series1);
            ChrtRev.Size = new Size(969, 963);
            ChrtRev.TabIndex = 11;
            ChrtRev.Text = "Monthly Revenue";
            // 
            // cboYears
            // 
            cboYears.DropDownStyle = ComboBoxStyle.DropDownList;
            cboYears.FormattingEnabled = true;
            cboYears.Location = new Point(67, 73);
            cboYears.Margin = new Padding(4, 2, 4, 2);
            cboYears.Name = "cboYears";
            cboYears.Size = new Size(157, 40);
            cboYears.TabIndex = 12;
            // 
            // grpChart
            // 
            grpChart.Controls.Add(ChrtRev);
            grpChart.Location = new Point(11, 141);
            grpChart.Margin = new Padding(4, 2, 4, 2);
            grpChart.Name = "grpChart";
            grpChart.Padding = new Padding(4, 2, 4, 2);
            grpChart.Size = new Size(969, 1002);
            grpChart.TabIndex = 13;
            grpChart.TabStop = false;
            grpChart.Text = "Chart";
            grpChart.Visible = false;
            // 
            // grpPrint
            // 
            grpPrint.Controls.Add(btnPrint);
            grpPrint.Location = new Point(1001, 920);
            grpPrint.Margin = new Padding(4, 2, 4, 2);
            grpPrint.Name = "grpPrint";
            grpPrint.Padding = new Padding(4, 2, 4, 2);
            grpPrint.Size = new Size(851, 223);
            grpPrint.TabIndex = 14;
            grpPrint.TabStop = false;
            grpPrint.Text = "Print";
            grpPrint.Visible = false;
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(234, 60);
            btnSearch.Margin = new Padding(6);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(746, 73);
            btnSearch.TabIndex = 15;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // frmMonthlyRevenueAnalysis
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1875, 1216);
            Controls.Add(btnSearch);
            Controls.Add(grpPrint);
            Controls.Add(grpChart);
            Controls.Add(cboYears);
            Controls.Add(YEAR);
            Margin = new Padding(6);
            Name = "frmMonthlyRevenueAnalysis";
            Text = "frmYearlyRevenueAnalysis";
            ((System.ComponentModel.ISupportInitialize)ChrtRev).EndInit();
            grpChart.ResumeLayout(false);
            grpPrint.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label YEAR;
        private Button btnSearch;
        private Button btnPrint;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChrtRev;
        private ComboBox cboYears;
        private GroupBox grpChart;
        private GroupBox grpPrint;
    }
}