﻿namespace CarRentSys
{
    partial class frmCancelRental
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CustID = new Label();
            Rentalnumber = new Label();
            btnSearch = new Button();
            btnCancelRental = new Button();
            grpSearchRental = new GroupBox();
            cboRentNum = new ComboBox();
            cboCustID = new ComboBox();
            grpRentalInfo = new GroupBox();
            grdRentals = new DataGridView();
            grpCancelRental = new GroupBox();
            grpRental = new GroupBox();
            grdRental = new DataGridView();
            grpSearchRental.SuspendLayout();
            grpRentalInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRentals).BeginInit();
            grpCancelRental.SuspendLayout();
            grpRental.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRental).BeginInit();
            SuspendLayout();
            // 
            // CustID
            // 
            CustID.AutoSize = true;
            CustID.Location = new Point(0, 74);
            CustID.Margin = new Padding(6, 0, 6, 0);
            CustID.Name = "CustID";
            CustID.Size = new Size(147, 32);
            CustID.TabIndex = 1;
            CustID.Text = "Customer ID";
            // 
            // Rentalnumber
            // 
            Rentalnumber.AutoSize = true;
            Rentalnumber.Location = new Point(477, 74);
            Rentalnumber.Margin = new Padding(6, 0, 6, 0);
            Rentalnumber.Name = "Rentalnumber";
            Rentalnumber.Size = new Size(175, 32);
            Rentalnumber.TabIndex = 2;
            Rentalnumber.Text = "Rental Number";
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(0, 175);
            btnSearch.Margin = new Padding(6);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(1062, 96);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnCancelRental
            // 
            btnCancelRental.ForeColor = SystemColors.Highlight;
            btnCancelRental.Location = new Point(9, 41);
            btnCancelRental.Margin = new Padding(6);
            btnCancelRental.Name = "btnCancelRental";
            btnCancelRental.Size = new Size(1051, 216);
            btnCancelRental.TabIndex = 4;
            btnCancelRental.Text = "Cancel Rental";
            btnCancelRental.UseVisualStyleBackColor = true;
            btnCancelRental.Click += btnCancelRental_Click;
            // 
            // grpSearchRental
            // 
            grpSearchRental.Controls.Add(cboRentNum);
            grpSearchRental.Controls.Add(cboCustID);
            grpSearchRental.Controls.Add(grpRentalInfo);
            grpSearchRental.Controls.Add(btnSearch);
            grpSearchRental.Controls.Add(CustID);
            grpSearchRental.Controls.Add(Rentalnumber);
            grpSearchRental.Location = new Point(2, 15);
            grpSearchRental.Margin = new Padding(6);
            grpSearchRental.Name = "grpSearchRental";
            grpSearchRental.Padding = new Padding(6);
            grpSearchRental.Size = new Size(1073, 271);
            grpSearchRental.TabIndex = 14;
            grpSearchRental.TabStop = false;
            grpSearchRental.Text = "Search For Rental";
            // 
            // cboRentNum
            // 
            cboRentNum.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRentNum.Enabled = false;
            cboRentNum.FormattingEnabled = true;
            cboRentNum.Location = new Point(662, 66);
            cboRentNum.Margin = new Padding(4, 2, 4, 2);
            cboRentNum.Name = "cboRentNum";
            cboRentNum.Size = new Size(145, 40);
            cboRentNum.TabIndex = 28;
            // 
            // cboCustID
            // 
            cboCustID.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCustID.FormattingEnabled = true;
            cboCustID.Location = new Point(157, 74);
            cboCustID.Margin = new Padding(4, 2, 4, 2);
            cboCustID.Name = "cboCustID";
            cboCustID.Size = new Size(145, 40);
            cboCustID.TabIndex = 27;
            cboCustID.SelectedIndexChanged += cboCustID_SelectedIndexChanged;
            // 
            // grpRentalInfo
            // 
            grpRentalInfo.Controls.Add(grdRentals);
            grpRentalInfo.Location = new Point(7, 284);
            grpRentalInfo.Margin = new Padding(6);
            grpRentalInfo.Name = "grpRentalInfo";
            grpRentalInfo.Padding = new Padding(6);
            grpRentalInfo.Size = new Size(1055, 346);
            grpRentalInfo.TabIndex = 16;
            grpRentalInfo.TabStop = false;
            grpRentalInfo.Text = "Rental Information";
            grpRentalInfo.Visible = false;
            // 
            // grdRentals
            // 
            grdRentals.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRentals.Location = new Point(0, 47);
            grdRentals.Margin = new Padding(6);
            grdRentals.Name = "grdRentals";
            grdRentals.RowHeadersWidth = 82;
            grdRentals.RowTemplate.Height = 25;
            grdRentals.Size = new Size(1027, 371);
            grdRentals.TabIndex = 14;
            // 
            // grpCancelRental
            // 
            grpCancelRental.Controls.Add(btnCancelRental);
            grpCancelRental.Location = new Point(9, 879);
            grpCancelRental.Name = "grpCancelRental";
            grpCancelRental.Size = new Size(1066, 260);
            grpCancelRental.TabIndex = 15;
            grpCancelRental.TabStop = false;
            grpCancelRental.Text = "Cancel Rental";
            grpCancelRental.Visible = false;
            // 
            // grpRental
            // 
            grpRental.Controls.Add(grdRental);
            grpRental.Location = new Point(20, 333);
            grpRental.Name = "grpRental";
            grpRental.Size = new Size(1055, 334);
            grpRental.TabIndex = 16;
            grpRental.TabStop = false;
            grpRental.Text = "Rental ";
            grpRental.Visible = false;
            // 
            // grdRental
            // 
            grdRental.BackgroundColor = SystemColors.ButtonHighlight;
            grdRental.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRental.Location = new Point(6, 37);
            grdRental.Name = "grdRental";
            grdRental.RowHeadersWidth = 82;
            grdRental.RowTemplate.Height = 41;
            grdRental.Size = new Size(1043, 291);
            grdRental.TabIndex = 0;
            grdRental.CellClick += grdRental_CellClick;
            // 
            // frmCancelRental
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1903, 1180);
            Controls.Add(grpRental);
            Controls.Add(grpCancelRental);
            Controls.Add(grpSearchRental);
            Margin = new Padding(6);
            Name = "frmCancelRental";
            Text = "frmCancelRental";
            Load += frmCancelRental_Load;
            grpSearchRental.ResumeLayout(false);
            grpSearchRental.PerformLayout();
            grpRentalInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)grdRentals).EndInit();
            grpCancelRental.ResumeLayout(false);
            grpRental.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)grdRental).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label CustID;
        private Label Rentalnumber;
        private Button btnSearch;
        private Button btnCancelRental;
        private GroupBox grpSearchRental;
        private GroupBox grpRentalInfo;
        private DataGridView grdRentals;
        private GroupBox grpCancelRental;
        private GroupBox grpRental;
        private DataGridView grdRental;
        private ComboBox cboCustID;
        private ComboBox cboRentNum;
    }
}