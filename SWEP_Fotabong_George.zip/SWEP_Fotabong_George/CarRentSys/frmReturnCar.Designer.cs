﻿namespace CarRentSys
{
    partial class frmReturnCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CustID = new Label();
            Rentalnumber = new Label();
            btnSearch = new Button();
            btnReturn = new Button();
            grpSearchRental = new GroupBox();
            cboRentNum = new ComboBox();
            cboCustID = new ComboBox();
            grpRentalInfo = new GroupBox();
            grdRentals = new DataGridView();
            grpReturn = new GroupBox();
            grpRental = new GroupBox();
            grdRental = new DataGridView();
            grpSearchRental.SuspendLayout();
            grpRentalInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRentals).BeginInit();
            grpReturn.SuspendLayout();
            grpRental.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRental).BeginInit();
            SuspendLayout();
            // 
            // CustID
            // 
            CustID.AutoSize = true;
            CustID.Location = new Point(0, 94);
            CustID.Margin = new Padding(6, 0, 6, 0);
            CustID.Name = "CustID";
            CustID.Size = new Size(147, 32);
            CustID.TabIndex = 0;
            CustID.Text = "Customer ID";
            // 
            // Rentalnumber
            // 
            Rentalnumber.AutoSize = true;
            Rentalnumber.Location = new Point(520, 94);
            Rentalnumber.Margin = new Padding(6, 0, 6, 0);
            Rentalnumber.Name = "Rentalnumber";
            Rentalnumber.Size = new Size(175, 32);
            Rentalnumber.TabIndex = 1;
            Rentalnumber.Text = "Rental Number";
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(0, 175);
            btnSearch.Margin = new Padding(6);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(1073, 96);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnReturn
            // 
            btnReturn.ForeColor = SystemColors.Highlight;
            btnReturn.Location = new Point(0, 30);
            btnReturn.Margin = new Padding(6);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(1073, 190);
            btnReturn.TabIndex = 3;
            btnReturn.Text = "Return Car";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click;
            // 
            // grpSearchRental
            // 
            grpSearchRental.Controls.Add(cboRentNum);
            grpSearchRental.Controls.Add(cboCustID);
            grpSearchRental.Controls.Add(grpRentalInfo);
            grpSearchRental.Controls.Add(CustID);
            grpSearchRental.Controls.Add(btnSearch);
            grpSearchRental.Controls.Add(Rentalnumber);
            grpSearchRental.Location = new Point(9, 26);
            grpSearchRental.Margin = new Padding(6);
            grpSearchRental.Name = "grpSearchRental";
            grpSearchRental.Padding = new Padding(6);
            grpSearchRental.Size = new Size(1073, 271);
            grpSearchRental.TabIndex = 13;
            grpSearchRental.TabStop = false;
            grpSearchRental.Text = "Search For Rental";
            // 
            // cboRentNum
            // 
            cboRentNum.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRentNum.Enabled = false;
            cboRentNum.FormattingEnabled = true;
            cboRentNum.Location = new Point(705, 91);
            cboRentNum.Margin = new Padding(4, 2, 4, 2);
            cboRentNum.Name = "cboRentNum";
            cboRentNum.Size = new Size(145, 40);
            cboRentNum.TabIndex = 28;
            // 
            // cboCustID
            // 
            cboCustID.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCustID.FormattingEnabled = true;
            cboCustID.Location = new Point(157, 86);
            cboCustID.Margin = new Padding(4, 2, 4, 2);
            cboCustID.Name = "cboCustID";
            cboCustID.Size = new Size(145, 40);
            cboCustID.TabIndex = 27;
            cboCustID.SelectedIndexChanged += cboCustID_SelectedIndexChanged;
            // 
            // grpRentalInfo
            // 
            grpRentalInfo.Controls.Add(grdRentals);
            grpRentalInfo.Location = new Point(7, 284);
            grpRentalInfo.Margin = new Padding(6);
            grpRentalInfo.Name = "grpRentalInfo";
            grpRentalInfo.Padding = new Padding(6);
            grpRentalInfo.Size = new Size(1055, 346);
            grpRentalInfo.TabIndex = 16;
            grpRentalInfo.TabStop = false;
            grpRentalInfo.Text = "Rental Information";
            grpRentalInfo.Visible = false;
            // 
            // grdRentals
            // 
            grdRentals.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRentals.Location = new Point(0, 47);
            grdRentals.Margin = new Padding(6);
            grdRentals.Name = "grdRentals";
            grdRentals.RowHeadersWidth = 82;
            grdRentals.RowTemplate.Height = 25;
            grdRentals.Size = new Size(1027, 371);
            grdRentals.TabIndex = 14;
            // 
            // grpReturn
            // 
            grpReturn.Controls.Add(btnReturn);
            grpReturn.Location = new Point(9, 740);
            grpReturn.Margin = new Padding(6);
            grpReturn.Name = "grpReturn";
            grpReturn.Padding = new Padding(6);
            grpReturn.Size = new Size(1073, 224);
            grpReturn.TabIndex = 13;
            grpReturn.TabStop = false;
            grpReturn.Text = "Return Rental Car";
            grpReturn.Visible = false;
            // 
            // grpRental
            // 
            grpRental.Controls.Add(grdRental);
            grpRental.Location = new Point(17, 309);
            grpRental.Margin = new Padding(6);
            grpRental.Name = "grpRental";
            grpRental.Padding = new Padding(6);
            grpRental.Size = new Size(1065, 365);
            grpRental.TabIndex = 16;
            grpRental.TabStop = false;
            grpRental.Text = "Rental Information";
            grpRental.Visible = false;
            // 
            // grdRental
            // 
            grdRental.BackgroundColor = SystemColors.ButtonHighlight;
            grdRental.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRental.Location = new Point(11, 30);
            grdRental.Margin = new Padding(6);
            grdRental.Name = "grdRental";
            grdRental.RowHeadersWidth = 82;
            grdRental.RowTemplate.Height = 25;
            grdRental.Size = new Size(1054, 328);
            grdRental.TabIndex = 14;
            grdRental.CellClick += grdRental_CellClick;
            // 
            // frmReturnCar
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1950, 1090);
            Controls.Add(grpRental);
            Controls.Add(grpReturn);
            Controls.Add(grpSearchRental);
            Margin = new Padding(6);
            Name = "frmReturnCar";
            Text = "frmReturnCar";
            Load += frmReturnCar_Load;
            grpSearchRental.ResumeLayout(false);
            grpSearchRental.PerformLayout();
            grpRentalInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)grdRentals).EndInit();
            grpReturn.ResumeLayout(false);
            grpRental.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)grdRental).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label CustID;
        private Label Rentalnumber;
        private Button btnSearch;
        private Button btnReturn;
        private GroupBox grpSearchRental;
        private GroupBox grpReturn;
        private GroupBox grpRentalInfo;
        private DataGridView grdRentals;
        private GroupBox grpRental;
        private DataGridView grdRental;
        private ComboBox cboCustID;
        private ComboBox cboRentNum;
    }
}