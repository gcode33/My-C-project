﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmReturnCar : Form
    {
        //creating a variable named rent of type Rental and initializes it with a new instance of the Rental class.
        Rental rent = new Rental();

        //creating a variable named cust of type Customer and initializes it with a new instance of the customer class.
        Customer cust = new Customer();

        //creating a variable named cars of type Cars and initializes it with a new instance of the Cars class.
        Cars cars = new Cars();
        public frmReturnCar()
        {
            InitializeComponent();
        }
        private void frmReturnCar_Load(object sender, EventArgs e)
        {
            cboCustID = Utility.loadCombo(cboCustID, "SELECT DISTINCT CustID FROM RENTALS WHERE Customer_Status = 'C' ORDER BY CustID", 1);

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {


            //filling the grid box with the info of the rental based 
            grdRental.DataSource = Rental.findRental(Convert.ToInt32(cboRentNum.Text.ToString()), Convert.ToInt32(cboCustID.Text.ToString())).Tables["Rental"];
            // Check if the rental exists
            if (grdRental.Rows.Count == 0)
            {
                MessageBox.Show("The rental does not exist .", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("The rental exists!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grpRental.Visible = true;

        }
        private void grdRental_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //make group box for button visible 
            grpReturn.Visible = true;

            //variable to hold the regnum
            String RegNum = grdRental.Rows[grdRental.CurrentCell.RowIndex].Cells[3].Value.ToString();

            //status to hold new car status
            string status = "A";

            //invoke the update car status method to update the cars status based on the regnum
            cars.updateCarStatus(status, RegNum);

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            //when button returned is clicked send comfirmation message and reset the UI
            rent.RemoveRental(Convert.ToInt32(cboRentNum.Text));
            cust.RemoveCustomer(Convert.ToInt32(cboCustID.Text));
            MessageBox.Show("Customer " + cboCustID.Text + "has Sucessfully returned thier rental car and their rental info has been deleted.The cars status has also been set to available again ", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            cboCustID.SelectedIndex = -1;
            cboRentNum.SelectedIndex = -1;
            grpRental.Visible = false;
            grpReturn.Visible = false;
        }

        private void cboCustID_SelectedIndexChanged(object sender, EventArgs e)
        {
            //load rental numbers for the selected customer ID based on which customer ID that was selected
            cboRentNum = Utility.loadCombo(cboRentNum, "SELECT Rental_Number FROM RENTALS WHERE CustID = '" + cboCustID.Text + "' ORDER BY Rental_Number", 1);

            //enable combo box
            cboRentNum.Enabled = true;
        }
    }
}
