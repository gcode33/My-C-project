﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentSys
{
    internal class MakeModel
    {
        private String make;
        private String model;


        public MakeModel()
        {
            this.make = "";
            this.model = "";
        }



        public MakeModel(String make, String model)
        {
            this.make = make;
            this.model = model;
        }


        //getters
        public String getMake() { return this.make; }
        public String getModel() { return this.model;}


        //setters
        public void setMake(String Make) { make = Make;}
        public void setModel(String Mode) {  model = Mode;}



        public void getAllMakes(String Make)
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "SELECT DISTINCT Make FROM MakeModels WHERE Make = " + Make;

            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();

            //set the instance variables with values from data reader
            setMake(dr.GetString(0));
           


            //close DB
            conn.Close();
        }
        public void getAllModels(String Model)
        {
            //Open a db connection
            OracleConnection conn = new OracleConnection(DBConnect.oraDB);

            //Define the SQL query to be executed
            String sqlQuery = "SELECT DISTINCT Model FROM MakeModels WHERE Model = " + Model;

            //Execute the SQL query (OracleCommand)
            OracleCommand cmd = new OracleCommand(sqlQuery, conn);
            conn.Open();

            OracleDataReader dr = cmd.ExecuteReader();
            dr.Read();

            //set the instance variables with values from data reader
            setModel(dr.GetString(0));



            //close DB
            conn.Close();
        }
    }
}
