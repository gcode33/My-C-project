﻿namespace CarRentSys
{
    partial class frmEditCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            RegNum = new Label();
            txtRegNum = new TextBox();
            grpEditCar = new GroupBox();
            txtStat = new TextBox();
            lblStat = new Label();
            txtFuelType = new TextBox();
            Status = new Label();
            FuelType = new Label();
            btnSubmit = new Button();
            txtDescription = new TextBox();
            Description = new Label();
            btnSearch = new Button();
            grdCars = new DataGridView();
            grpEditCar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdCars).BeginInit();
            SuspendLayout();
            // 
            // RegNum
            // 
            RegNum.AutoSize = true;
            RegNum.Location = new Point(11, 64);
            RegNum.Margin = new Padding(4, 0, 4, 0);
            RegNum.Name = "RegNum";
            RegNum.Size = new Size(235, 32);
            RegNum.TabIndex = 0;
            RegNum.Text = "Registration Number";
            // 
            // txtRegNum
            // 
            txtRegNum.Location = new Point(253, 64);
            txtRegNum.Margin = new Padding(4, 2, 4, 2);
            txtRegNum.MaxLength = 10;
            txtRegNum.Name = "txtRegNum";
            txtRegNum.Size = new Size(203, 39);
            txtRegNum.TabIndex = 1;
            // 
            // grpEditCar
            // 
            grpEditCar.Controls.Add(txtStat);
            grpEditCar.Controls.Add(lblStat);
            grpEditCar.Controls.Add(txtFuelType);
            grpEditCar.Controls.Add(Status);
            grpEditCar.Controls.Add(FuelType);
            grpEditCar.Controls.Add(btnSubmit);
            grpEditCar.Controls.Add(txtDescription);
            grpEditCar.Controls.Add(Description);
            grpEditCar.Location = new Point(11, 308);
            grpEditCar.Margin = new Padding(4, 2, 4, 2);
            grpEditCar.Name = "grpEditCar";
            grpEditCar.Padding = new Padding(4, 2, 4, 2);
            grpEditCar.Size = new Size(580, 451);
            grpEditCar.TabIndex = 4;
            grpEditCar.TabStop = false;
            grpEditCar.Text = "Edit Car";
            grpEditCar.Visible = false;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(114, 235);
            txtStat.Margin = new Padding(4, 2, 4, 2);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(52, 39);
            txtStat.TabIndex = 16;
            // 
            // lblStat
            // 
            lblStat.AutoSize = true;
            lblStat.Location = new Point(-2, 242);
            lblStat.Margin = new Padding(4, 0, 4, 0);
            lblStat.Name = "lblStat";
            lblStat.Size = new Size(78, 32);
            lblStat.TabIndex = 15;
            lblStat.Text = "Status";
            // 
            // txtFuelType
            // 
            txtFuelType.Location = new Point(143, 143);
            txtFuelType.Margin = new Padding(4, 2, 4, 2);
            txtFuelType.MaxLength = 1;
            txtFuelType.Name = "txtFuelType";
            txtFuelType.Size = new Size(52, 39);
            txtFuelType.TabIndex = 14;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(6, 499);
            Status.Margin = new Padding(4, 0, 4, 0);
            Status.Name = "Status";
            Status.Size = new Size(0, 32);
            Status.TabIndex = 10;
            // 
            // FuelType
            // 
            FuelType.AutoSize = true;
            FuelType.Location = new Point(0, 143);
            FuelType.Margin = new Padding(4, 0, 4, 0);
            FuelType.Name = "FuelType";
            FuelType.Size = new Size(117, 32);
            FuelType.TabIndex = 9;
            FuelType.Text = "Fuel Type";
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(0, 325);
            btnSubmit.Margin = new Padding(4, 2, 4, 2);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(215, 113);
            btnSubmit.TabIndex = 5;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(143, 66);
            txtDescription.Margin = new Padding(4, 2, 4, 2);
            txtDescription.MaxLength = 10;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(188, 39);
            txtDescription.TabIndex = 2;
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(0, 66);
            Description.Margin = new Padding(4, 0, 4, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 0;
            Description.Text = "Description";
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(520, 53);
            btnSearch.Margin = new Padding(4, 2, 4, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(139, 64);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // grdCars
            // 
            grdCars.BackgroundColor = SystemColors.ButtonHighlight;
            grdCars.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdCars.Location = new Point(20, 122);
            grdCars.Margin = new Padding(4, 2, 4, 2);
            grdCars.Name = "grdCars";
            grdCars.RowHeadersWidth = 82;
            grdCars.RowTemplate.Height = 41;
            grdCars.Size = new Size(893, 162);
            grdCars.TabIndex = 6;
            grdCars.Visible = false;
            grdCars.CellContentClick += grdCars_CellClick;
            // 
            // frmEditCar
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1166, 983);
            Controls.Add(grdCars);
            Controls.Add(btnSearch);
            Controls.Add(grpEditCar);
            Controls.Add(txtRegNum);
            Controls.Add(RegNum);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmEditCar";
            Text = "frmEditCar";
            grpEditCar.ResumeLayout(false);
            grpEditCar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdCars).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label RegNum;
        private TextBox txtRegNum;
        private GroupBox grpEditCar;
        private TextBox txtDescription;
        private Label Description;
        private Button btnSearch;
        private Button btnSubmit;
        private TextBox txtFuelType;
        private Label Status;
        private Label FuelType;
        private DataGridView grdCars;
        private Label lblStat;
        private TextBox txtStat;
    }
}