﻿namespace CarRentSys
{
    partial class frmRemoveEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpRemEquip = new GroupBox();
            txtStat = new TextBox();
            Status = new Label();
            btnRemove = new Button();
            grdRemoveEquip = new DataGridView();
            btnSearch = new Button();
            txtEquipID = new TextBox();
            RegNum = new Label();
            grpRemEquip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRemoveEquip).BeginInit();
            SuspendLayout();
            // 
            // grpRemEquip
            // 
            grpRemEquip.Controls.Add(txtStat);
            grpRemEquip.Controls.Add(Status);
            grpRemEquip.Controls.Add(btnRemove);
            grpRemEquip.Location = new Point(9, 335);
            grpRemEquip.Margin = new Padding(4, 2, 4, 2);
            grpRemEquip.Name = "grpRemEquip";
            grpRemEquip.Padding = new Padding(4, 2, 4, 2);
            grpRemEquip.Size = new Size(780, 271);
            grpRemEquip.TabIndex = 1;
            grpRemEquip.TabStop = false;
            grpRemEquip.Text = "Remove Equipment";
            grpRemEquip.Visible = false;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(100, 64);
            txtStat.Margin = new Padding(4, 2, 4, 2);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(60, 39);
            txtStat.TabIndex = 9;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(7, 64);
            Status.Margin = new Padding(4, 0, 4, 0);
            Status.Name = "Status";
            Status.Size = new Size(78, 32);
            Status.TabIndex = 8;
            Status.Text = "Status";
            // 
            // btnRemove
            // 
            btnRemove.ForeColor = SystemColors.Highlight;
            btnRemove.Location = new Point(7, 154);
            btnRemove.Margin = new Padding(4, 2, 4, 2);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(215, 113);
            btnRemove.TabIndex = 7;
            btnRemove.Text = "REMOVE EQUIPMENT";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // grdRemoveEquip
            // 
            grdRemoveEquip.BackgroundColor = SystemColors.ButtonHighlight;
            grdRemoveEquip.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRemoveEquip.Location = new Point(9, 81);
            grdRemoveEquip.Margin = new Padding(4, 2, 4, 2);
            grdRemoveEquip.Name = "grdRemoveEquip";
            grdRemoveEquip.RowHeadersWidth = 82;
            grdRemoveEquip.RowTemplate.Height = 41;
            grdRemoveEquip.Size = new Size(527, 250);
            grdRemoveEquip.TabIndex = 10;
            grdRemoveEquip.Visible = false;
            grdRemoveEquip.CellClick += grdRemoveEquip_CellClick_1;
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(368, 17);
            btnSearch.Margin = new Padding(4, 2, 4, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(139, 49);
            btnSearch.TabIndex = 6;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtEquipID
            // 
            txtEquipID.Location = new Point(176, 28);
            txtEquipID.Margin = new Padding(4, 2, 4, 2);
            txtEquipID.MaxLength = 10;
            txtEquipID.Name = "txtEquipID";
            txtEquipID.Size = new Size(182, 39);
            txtEquipID.TabIndex = 1;
            // 
            // RegNum
            // 
            RegNum.AutoSize = true;
            RegNum.Location = new Point(9, 26);
            RegNum.Margin = new Padding(4, 0, 4, 0);
            RegNum.Name = "RegNum";
            RegNum.Size = new Size(160, 32);
            RegNum.TabIndex = 0;
            RegNum.Text = "Equipment ID";
            // 
            // frmRemoveEquipment
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 909);
            Controls.Add(grdRemoveEquip);
            Controls.Add(grpRemEquip);
            Controls.Add(RegNum);
            Controls.Add(txtEquipID);
            Controls.Add(btnSearch);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmRemoveEquipment";
            Text = "frmRemoveEquipment";
            grpRemEquip.ResumeLayout(false);
            grpRemEquip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdRemoveEquip).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpRemEquip;
        private TextBox txtStat;
        private Label Status;
        private Button btnRemove;
        private Button btnSearch;
        private TextBox txtEquipID;
        private Label RegNum;
        private DataGridView grdRemoveEquip;
    }
}