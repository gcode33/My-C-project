﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmMonthlyRevenueAnalysis : Form
    {
        public frmMonthlyRevenueAnalysis()
        {
            InitializeComponent();

            //loading the function for the combo boxes
            LoadYears();
        }

        // Load years into the combo box
        private void LoadYears()
        {
            //loading values for years into the combo box using a for loop and starting at 2024 and going down one until 2000
            for (int year = DateTime.Now.Year; year >= 2000; year--)
            {
                //filling the combo box with the values 
                cboYears.Items.Add(year.ToString());
            }
        }



        private void btnPrint_Click(object sender, EventArgs e)
        {
            //yes or no message to check if the manager wants to print 
            DialogResult answer = MessageBox.Show("Are you sure you want to print : ", "Confirm",
MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                //if yes send message of comfirmation 
                MessageBox.Show("The Monthly revenue analysis has been printed view please ", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //reset the UI
                cboYears.SelectedIndex = -1;
                grpPrint.Visible = false;
                grpChart.Visible = false;
            }
            //if no then reset the UI
            cboYears.SelectedIndex = -1;
            grpPrint.Visible = false;
            grpChart.Visible = false;   
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //when the search button is clicked make the group boxes holding the chart and the print button visible 
            grpChart.Visible = true;
            grpPrint.Visible = true;
            LoadChartData(); // Reload chart data based on the selected year
        }

        // Method to load chart data
        private void LoadChartData()
        {
            // Check if a year is selected
            if (cboYears.Text == null)
            {
                MessageBox.Show("Please select a year.");
                return;
            }

            //creating a variable to hold the year selected from the combo box 
            string selectedYear = cboYears.Text.ToString();

            //sql query to get the info needed for the chart
            string strSQL = $"SELECT SUM(Amount), to_Char(rentStart,'MM') FROM Rentals WHERE to_Char(rentStart,'YYYY') = '{selectedYear}' GROUP BY to_Char(rentStart,'MM') ORDER BY to_Char(rentStart,'MM')";

            DataTable dt = new DataTable();
            OracleConnection myConn = new OracleConnection(DBConnect.oraDB);
            OracleCommand cmd = new OracleCommand(strSQL, myConn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            da.Fill(dt);
            myConn.Close();

            string[] Months = new string[12];
            decimal[] Amounts = new decimal[12];

            //for loop to get the months and the amounts and hold them in  an array 
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Months[i] = getMonth(Convert.ToInt32(dt.Rows[i][1]));
                Amounts[i] = Convert.ToDecimal(dt.Rows[i][0]);
            }


            //bind the values to points on the charts 
            ChrtRev.Series[0].Points.DataBindXY(Months, Amounts);

            // Set axis labels
            ChrtRev.ChartAreas[0].AxisX.Title = "Months";
            ChrtRev.ChartAreas[0].AxisY.Title = "Amount";

            // Set chart title
            ChrtRev.Titles.Clear();
            ChrtRev.Titles.Add("Monthly Revenue for the year " + selectedYear);
        }
        public String getMonth(int month)
        {
            switch (month)
            {
                case 1:
                    return "JAN";
                case 2:
                    return "FEB";
                case 3:
                    return "MAR";
                case 4:
                    return "APR";
                case 5:
                    return "MAY";
                case 6:
                    return "JUN";
                case 7:
                    return "JUL";
                case 8:
                    return "AUG";
                case 9:
                    return "SEP";
                case 10:
                    return "OCT";
                case 11:
                    return "NOV";
                case 12:
                    return "DEC";
                default:
                    return "OTH";
            }
        }


    }
}

