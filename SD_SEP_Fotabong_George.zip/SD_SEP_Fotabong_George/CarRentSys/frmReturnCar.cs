﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmReturnCar : Form
    {
        //creating a variable named rent of type Rental and initializes it with a new instance of the Rental class.
        Rental rent = new Rental();

        //creating a variable named cust of type Customer and initializes it with a new instance of the customer class.
        Customer cust = new Customer();

        //creating a variable named cars of type Cars and initializes it with a new instance of the Cars class.
        Cars cars = new Cars(); 
        public frmReturnCar()
        {
            InitializeComponent();
        }
        private void frmReturnCar_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validation for info entered 
            if (txtCustID.Text.Equals("") || txtCustID.Text.Length > 9 || !txtCustID.Text.All(char.IsDigit))
            {
                MessageBox.Show("Invalid Customer ID must 9 digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCustID.Focus();
                return;
            }

            if (txtRentNum.Text.Equals("") || txtRentNum.Text.Length > 9 || !txtRentNum.Text.All(char.IsDigit))
            {
                MessageBox.Show("Invalid Rental Number must be entered and must be at least 9 digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRentNum.Focus();
                return;
            }

            //filling the grid box with the info of the rental based 
            grdRental.DataSource = Rental.findRental(Convert.ToInt32(txtRentNum.Text.ToString()), Convert.ToInt32(txtCustID.Text.ToString())).Tables["Rental"];
            // Check if the rental exists
            if (grdRental.Rows.Count == 1)
            {
                MessageBox.Show("The rental does not exist .", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("The rental exists!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grpRental.Visible = true;

        }
        private void grdRental_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //make group box for button visible 
            grpReturn.Visible = true;

            //variable to hold the regnum
            String RegNum = grdRental.Rows[grdRental.CurrentCell.RowIndex].Cells[3].Value.ToString();

            //status to hold new car status
            string status = "A";

            //invoke the update car status method to update the cars status based on the regnum
            cars.updateCarStatus(status, RegNum);

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            //when button returned is clicked send comfirmation message and reset the UI
            rent.RemoveRental(Convert.ToInt32(txtRentNum.Text));
            cust.RemoveCustomer(Convert.ToInt32(txtCustID.Text));
            MessageBox.Show("Customer " + txtCustID.Text + "has Sucessfully returned thier rental car and their rental info has been deleted.The cars status has also been set to available again ", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtCustID.Clear();
            txtRentNum.Clear();
            grpRental.Visible = false;
            grpReturn.Visible = false;
        }


    }
}
