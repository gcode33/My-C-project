﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmCollectCar : Form
    {
        Rental rent = new Rental();
        Cars cars = new Cars();

        public frmCollectCar()
        {
            InitializeComponent();
        }

        private void frmCollectCar_Load(object sender, EventArgs e)
        {
          
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validation for the info entered 
            if (txtCustID.Text.Equals("")||txtCustID.Text.Length > 9 || !txtCustID.Text.All(char.IsDigit))
            {
                MessageBox.Show("Invalid Customer ID must 9 digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCustID.Focus();
                return;
            }

            if (txtRentNum.Text.Equals("") || txtRentNum.Text.Length > 9 || !txtRentNum.Text.All(char.IsDigit))
            {
                MessageBox.Show("Invalid Rental Number must 9 digits and must not include letters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRentNum.Focus();
                return;
            }
            //fill the grid box with the rental info based on the CustID and RegNum provided
            grdRentals.DataSource = Rental.findRental(Convert.ToInt32(txtRentNum.Text.ToString()), Convert.ToInt32(txtCustID.Text.ToString())).Tables["Rental"];

            // Check if the rental exists
            if (grdRentals.Rows.Count == 1)
            {
                MessageBox.Show("The rental does not exist .", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //if the rental exists send comfirmation message
            MessageBox.Show("The rental exists!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //make the group box with the grid box visible
            grpRentalInfo.Visible = true;

           

        }

        private void btnCollectCar_Click(object sender, EventArgs e)
        {
            //set the customers status to C for collected
            txtStatus.Text = "C";
            rent.setStatus(txtStatus.Text);
            rent.updateRental();
            MessageBox.Show("The Customer has collected their rental car", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grpCollectCar.Visible = false;
            grpRentalInfo.Visible= false;
        }

        private void grdRentals_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //variable to hold the status of the customer based of the grid box
            string Status = grdRentals.Rows[grdRentals.CurrentCell.RowIndex].Cells[6].ToString();

            //variable to hold the regnum of the car based of the grid box
            String RegNum = grdRentals.Rows[grdRentals.CurrentCell.RowIndex].Cells[3].Value.ToString();

            //variable to set the new car status to U for unavailable 
            string Carstatus = "U";

            //invoke the update car status method to set the new status of the car based on the RegNum provided 
            cars.updateCarStatus(Carstatus, RegNum);

            //setting the varibale holding the current customer status to the text box for status
            Status = txtStatus.Text;

            //making the group box which has the collect car button visible 
            grpCollectCar.Visible = true; 
        }
    }
}
