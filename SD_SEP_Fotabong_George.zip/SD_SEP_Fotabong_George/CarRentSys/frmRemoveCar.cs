﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmRemoveCar : Form
    {
        //creating a variable named cars of type Cars and initializes it with a new instance of the Cars class.
        Cars theCar = new Cars();

        public frmRemoveCar()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validate data enterd 
            if (txtRegNum.Text.Equals("") || !txtRegNum.Text.Any(char.IsDigit) || txtRegNum.Text.Count(char.IsDigit) < 3 || txtRegNum.Text.Length > 9 || txtRegNum.Text.StartsWith("-"))
            {
                MessageBox.Show("Invalid Registration number must include at least 3 digits, must not be more than 9 characters and no negative numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRegNum.Focus();
                return;
            }

            // If the code reaches here, it means the validation passed
            MessageBox.Show("Valid Registration number car has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Finding matching Cars
            grdRemoveCar.DataSource = Cars.findCar(txtRegNum.Text).Tables["cars"];

            if (grdRemoveCar.Rows.Count == 1)
            {
                MessageBox.Show("no data found");
                txtRegNum.Focus();
            }
            //make the grid box with data visible
            grdRemoveCar.Visible = true;




        }


        private void btnRemove_Click(object sender, EventArgs e)
        {
            //yes or no message to confim removal
            DialogResult answer = MessageBox.Show("Are you sure you want to remove the car : " + txtRegNum.Text, "Confirm",
     MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //if statement if yes is clicked
            if (answer == DialogResult.Yes)
            {
                //remove the car from database based on the registration number
                theCar.removeCar(txtRegNum.Text);

                //comfirmation message 
                MessageBox.Show("The Car: " + txtRegNum.Text + " has been Removed from the Cars file", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //reset UI
                grpRemCar.Visible = false;
                grdRemoveCar.Visible = false;
                txtStat.Text = "R";
                txtRegNum.Clear();
            }

        }

        private void grdRemoveCar_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //extract the RegNum from column zero on the slected rrow in grid
            String RegNum = (grdRemoveCar.Rows[grdRemoveCar.CurrentCell.RowIndex].Cells[0].Value.ToString());


            //Instanciate theCar
            theCar.getCar(RegNum);


            //move the instance variable values to the form controls
            txtRegNum.Text = theCar.get_regNum();
            txtStat.Text = theCar.getStatus();
            grpRemCar.Visible = true;

            //if the status of the car is not A then send the error message and reset the UI
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this car may not be removed yet because it is currently in use please choose another car", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                txtRegNum.Clear();
                txtStat.Clear();
            }
        }
    }
}
