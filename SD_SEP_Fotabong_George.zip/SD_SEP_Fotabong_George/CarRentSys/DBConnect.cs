﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CarRentSys
{
    class DBConnect
    {

        //public const String oraDB = "Data Source = localhost/orcl; User ID = C##User1; Password = 123456;"; //When using laptop
        public const String oraDB = "Data Source = studentoracle:1521/orcl; User ID = t00244535; Password = Werhe_pk6a4g;"; //When in MTU Lab

    }
}
