﻿namespace CarRentSys
{
    partial class frmMonthlyRevenueAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            YEAR = new Label();
            btnPrint = new Button();
            ChrtRev = new System.Windows.Forms.DataVisualization.Charting.Chart();
            cboYears = new ComboBox();
            grpChart = new GroupBox();
            grpPrint = new GroupBox();
            btnSearch = new Button();
            ((System.ComponentModel.ISupportInitialize)ChrtRev).BeginInit();
            grpChart.SuspendLayout();
            grpPrint.SuspendLayout();
            SuspendLayout();
            // 
            // YEAR
            // 
            YEAR.AutoSize = true;
            YEAR.Location = new Point(0, 34);
            YEAR.Name = "YEAR";
            YEAR.Size = new Size(29, 15);
            YEAR.TabIndex = 2;
            YEAR.Text = "Year";
            // 
            // btnPrint
            // 
            btnPrint.ForeColor = SystemColors.Highlight;
            btnPrint.Location = new Point(5, 19);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(195, 80);
            btnPrint.TabIndex = 10;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            btnPrint.Click += btnPrint_Click;
            // 
            // ChrtRev
            // 
            chartArea2.Name = "ChartArea1";
            ChrtRev.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            ChrtRev.Legends.Add(legend2);
            ChrtRev.Location = new Point(13, 18);
            ChrtRev.Margin = new Padding(2, 1, 2, 1);
            ChrtRev.Name = "ChrtRev";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            ChrtRev.Series.Add(series2);
            ChrtRev.Size = new Size(323, 247);
            ChrtRev.TabIndex = 11;
            ChrtRev.Text = "Monthly Revenue";
            // 
            // cboYears
            // 
            cboYears.DropDownStyle = ComboBoxStyle.DropDownList;
            cboYears.FormattingEnabled = true;
            cboYears.Location = new Point(36, 34);
            cboYears.Margin = new Padding(2, 1, 2, 1);
            cboYears.Name = "cboYears";
            cboYears.Size = new Size(68, 23);
            cboYears.TabIndex = 12;
            // 
            // grpChart
            // 
            grpChart.Controls.Add(ChrtRev);
            grpChart.Location = new Point(6, 66);
            grpChart.Margin = new Padding(2, 1, 2, 1);
            grpChart.Name = "grpChart";
            grpChart.Padding = new Padding(2, 1, 2, 1);
            grpChart.Size = new Size(347, 268);
            grpChart.TabIndex = 13;
            grpChart.TabStop = false;
            grpChart.Text = "Chart";
            grpChart.Visible = false;
            // 
            // grpPrint
            // 
            grpPrint.Controls.Add(btnPrint);
            grpPrint.Location = new Point(375, 230);
            grpPrint.Margin = new Padding(2, 1, 2, 1);
            grpPrint.Name = "grpPrint";
            grpPrint.Padding = new Padding(2, 1, 2, 1);
            grpPrint.Size = new Size(205, 103);
            grpPrint.TabIndex = 14;
            grpPrint.TabStop = false;
            grpPrint.Text = "Print";
            grpPrint.Visible = false;
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(126, 28);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(92, 34);
            btnSearch.TabIndex = 15;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // frmMonthlyRevenueAnalysis
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(687, 366);
            Controls.Add(btnSearch);
            Controls.Add(grpPrint);
            Controls.Add(grpChart);
            Controls.Add(cboYears);
            Controls.Add(YEAR);
            Name = "frmMonthlyRevenueAnalysis";
            Text = "frmYearlyRevenueAnalysis";
            ((System.ComponentModel.ISupportInitialize)ChrtRev).EndInit();
            grpChart.ResumeLayout(false);
            grpPrint.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label YEAR;
        private Button btnSearch;
        private Button btnPrint;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChrtRev;
        private ComboBox cboYears;
        private GroupBox grpChart;
        private GroupBox grpPrint;
    }
}