﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmCancelRental : Form
    {
        Rental rent = new Rental();
        Customer cust = new Customer();
        Cars cars = new Cars();
        public frmCancelRental()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validation for the info entered 
            if (txtCustID.Text.Equals("") ||  !txtCustID.Text.Any(char.IsDigit)||txtCustID.Text.Length > 9)
            {
                MessageBox.Show("Invalid Customer ID must 9 digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCustID.Focus();
                return;
            }

            if (txtRentNum.Text.Equals("") || txtRentNum.Text.Length > 9 || !txtRentNum.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Invalid Rental Number must 9 digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRentNum.Focus();
                return;
            }
            //fill the grid box with the rental info based on the custID and the RegNum provided 
            grdRental.DataSource = Rental.findRental(Convert.ToInt32(txtRentNum.Text.ToString()), Convert.ToInt32(txtCustID.Text.ToString())).Tables["Rental"];
            // Check if the rental exists
            if (grdRental.Rows.Count == 1)
            {
                MessageBox.Show("The rental does not exist .", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //once rental is found send comfirmation message and make group box with grid box in it visible
            MessageBox.Show("The rental exists!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grpRental.Visible = true;
        }
        private void grdRental_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //make the group box for the button visible upon selection
            grpCancelRental.Visible = true;
            
            //fill a variable called regnum with the value from the regnum coloumn on the gridbox
            String RegNum = grdRental.Rows[grdRental.CurrentCell.RowIndex].Cells[1].Value.ToString();

            //variable to hold the status of the car
            string status = "A";

            //invoke the update car variable to set the cars status back to available based on the regnum
            cars.updateCarStatus(status, RegNum);
        }

        private void btnCancelRental_Click(object sender, EventArgs e)
        {

            //yes or no for cancelation of the rental
            DialogResult answer = MessageBox.Show("Are you sure you want to cancel the rental for customer: " + txtCustID.Text, "Confirm",
MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                //if answer is yes send comfirmation message and reset the UI
                MessageBox.Show("The customer: " + txtCustID.Text + " rental has been canceld and they have been removed from the rental file", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                rent.RemoveRental(Convert.ToInt32(txtRentNum.Text));
                cust.RemoveCustomer(Convert.ToInt32(txtCustID.Text));
                txtCustID.Clear();
                txtRentNum.Clear();
                grpCancelRental.Visible=false;
                grpRental.Visible = false;
            }

        }


    }
}
