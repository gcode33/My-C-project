﻿
namespace CarRentSys
{
    partial class frmAddCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Description = new Label();
            Type = new Label();
            NumSeats = new Label();
            RegNum = new Label();
            txtDescription = new TextBox();
            txtRegNum = new TextBox();
            btnSubmit = new Button();
            cboTypes = new ComboBox();
            grpAddCar = new GroupBox();
            cboNumSeats = new ComboBox();
            cboModel = new ComboBox();
            cboMake = new ComboBox();
            txtStat = new TextBox();
            lblStat = new Label();
            txtFuelType = new TextBox();
            FuelType = new Label();
            Model = new Label();
            Make = new Label();
            TypeCode = new Label();
            grpAddCar.SuspendLayout();
            SuspendLayout();
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(0, 112);
            Description.Margin = new Padding(2, 0, 2, 0);
            Description.Name = "Description";
            Description.Size = new Size(67, 15);
            Description.TabIndex = 0;
            Description.Text = "Description";
            // 
            // Type
            // 
            Type.AutoSize = true;
            Type.Location = new Point(0, 72);
            Type.Margin = new Padding(2, 0, 2, 0);
            Type.Name = "Type";
            Type.Size = new Size(86, 15);
            Type.TabIndex = 1;
            Type.Text = "Select Car Type";
            // 
            // NumSeats
            // 
            NumSeats.AutoSize = true;
            NumSeats.Location = new Point(0, 147);
            NumSeats.Margin = new Padding(2, 0, 2, 0);
            NumSeats.Name = "NumSeats";
            NumSeats.Size = new Size(94, 15);
            NumSeats.TabIndex = 2;
            NumSeats.Text = "Number of seats";
            // 
            // RegNum
            // 
            RegNum.AutoSize = true;
            RegNum.Location = new Point(-3, 31);
            RegNum.Margin = new Padding(2, 0, 2, 0);
            RegNum.Name = "RegNum";
            RegNum.Size = new Size(117, 15);
            RegNum.TabIndex = 3;
            RegNum.Text = "Registration Number";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(72, 104);
            txtDescription.MaxLength = 10;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(119, 23);
            txtDescription.TabIndex = 5;
            // 
            // txtRegNum
            // 
            txtRegNum.Location = new Point(129, 30);
            txtRegNum.MaxLength = 10;
            txtRegNum.Name = "txtRegNum";
            txtRegNum.Size = new Size(78, 23);
            txtRegNum.TabIndex = 8;
            txtRegNum.TextAlign = HorizontalAlignment.Right;
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(177, 290);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(155, 74);
            btnSubmit.TabIndex = 9;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // cboTypes
            // 
            cboTypes.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTypes.FormattingEnabled = true;
            cboTypes.Location = new Point(100, 71);
            cboTypes.Margin = new Padding(2, 1, 2, 1);
            cboTypes.Name = "cboTypes";
            cboTypes.Size = new Size(132, 23);
            cboTypes.TabIndex = 10;
            // 
            // grpAddCar
            // 
            grpAddCar.Controls.Add(cboNumSeats);
            grpAddCar.Controls.Add(cboModel);
            grpAddCar.Controls.Add(cboMake);
            grpAddCar.Controls.Add(txtStat);
            grpAddCar.Controls.Add(lblStat);
            grpAddCar.Controls.Add(txtFuelType);
            grpAddCar.Controls.Add(txtRegNum);
            grpAddCar.Controls.Add(RegNum);
            grpAddCar.Controls.Add(Type);
            grpAddCar.Controls.Add(cboTypes);
            grpAddCar.Controls.Add(FuelType);
            grpAddCar.Controls.Add(Model);
            grpAddCar.Controls.Add(Make);
            grpAddCar.Controls.Add(TypeCode);
            grpAddCar.Controls.Add(NumSeats);
            grpAddCar.Controls.Add(btnSubmit);
            grpAddCar.Controls.Add(Description);
            grpAddCar.Controls.Add(txtDescription);
            grpAddCar.Location = new Point(102, 58);
            grpAddCar.Margin = new Padding(2, 1, 2, 1);
            grpAddCar.Name = "grpAddCar";
            grpAddCar.Padding = new Padding(2, 1, 2, 1);
            grpAddCar.Size = new Size(474, 364);
            grpAddCar.TabIndex = 11;
            grpAddCar.TabStop = false;
            grpAddCar.Text = "Add Car details ";
            // 
            // cboNumSeats
            // 
            cboNumSeats.DropDownStyle = ComboBoxStyle.DropDownList;
            cboNumSeats.FormattingEnabled = true;
            cboNumSeats.Items.AddRange(new object[] { "2", "4", "5", "6", "7", "8" });
            cboNumSeats.Location = new Point(100, 146);
            cboNumSeats.Margin = new Padding(2, 1, 2, 1);
            cboNumSeats.Name = "cboNumSeats";
            cboNumSeats.Size = new Size(80, 23);
            cboNumSeats.TabIndex = 25;
            // 
            // cboModel
            // 
            cboModel.DropDownStyle = ComboBoxStyle.DropDownList;
            cboModel.Enabled = false;
            cboModel.FormattingEnabled = true;
            cboModel.Location = new Point(46, 219);
            cboModel.Margin = new Padding(2, 1, 2, 1);
            cboModel.Name = "cboModel";
            cboModel.Size = new Size(80, 23);
            cboModel.TabIndex = 24;
            // 
            // cboMake
            // 
            cboMake.DropDownStyle = ComboBoxStyle.DropDownList;
            cboMake.FormattingEnabled = true;
            cboMake.Location = new Point(41, 180);
            cboMake.Margin = new Padding(2, 1, 2, 1);
            cboMake.Name = "cboMake";
            cboMake.Size = new Size(85, 23);
            cboMake.TabIndex = 23;
            cboMake.SelectedIndexChanged += cboMake_SelectedIndexChanged;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(65, 299);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(29, 23);
            txtStat.TabIndex = 22;
            // 
            // lblStat
            // 
            lblStat.AutoSize = true;
            lblStat.Location = new Point(-3, 299);
            lblStat.Name = "lblStat";
            lblStat.Size = new Size(39, 15);
            lblStat.TabIndex = 21;
            lblStat.Text = "Status";
            // 
            // txtFuelType
            // 
            txtFuelType.Location = new Point(65, 252);
            txtFuelType.MaxLength = 1;
            txtFuelType.Name = "txtFuelType";
            txtFuelType.Size = new Size(29, 23);
            txtFuelType.TabIndex = 20;
            // 
            // FuelType
            // 
            FuelType.AutoSize = true;
            FuelType.Location = new Point(-3, 255);
            FuelType.Name = "FuelType";
            FuelType.Size = new Size(56, 15);
            FuelType.TabIndex = 17;
            FuelType.Text = "Fuel Type";
            // 
            // Model
            // 
            Model.AutoSize = true;
            Model.Location = new Point(0, 222);
            Model.Name = "Model";
            Model.Size = new Size(41, 15);
            Model.TabIndex = 16;
            Model.Text = "Model";
            // 
            // Make
            // 
            Make.AutoSize = true;
            Make.Location = new Point(0, 183);
            Make.Name = "Make";
            Make.Size = new Size(36, 15);
            Make.TabIndex = 15;
            Make.Text = "Make";
            // 
            // TypeCode
            // 
            TypeCode.AutoSize = true;
            TypeCode.Location = new Point(0, 33);
            TypeCode.Margin = new Padding(2, 0, 2, 0);
            TypeCode.Name = "TypeCode";
            TypeCode.Size = new Size(0, 15);
            TypeCode.TabIndex = 11;
            // 
            // frmAddCar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(649, 428);
            Controls.Add(grpAddCar);
            Margin = new Padding(2, 1, 2, 1);
            Name = "frmAddCar";
            Text = "Car Rentals - [Add Car]";
            Load += frmAddCar_Load;
            grpAddCar.ResumeLayout(false);
            grpAddCar.PerformLayout();
            ResumeLayout(false);
        }



        #endregion

        private Label Description;
        private Label Type;
        private Label NumSeats;
        private Label RegNum;
        private TextBox txtDescription;
        private TextBox txtRegNum;
        private Button btnSubmit;
        private ComboBox cboTypes;
        private GroupBox grpAddCar;
        private Label TypeCode;
        private TextBox txtFuelType;
        private Label FuelType;
        private Label Model;
        private Label Make;
        private TextBox txtStat;
        private Label lblStat;
        private ComboBox cboModel;
        private ComboBox cboMake;
        private ComboBox cboNumSeats;
    }
}