﻿namespace CarRentSys
{
    partial class frmCollectCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CustID = new Label();
            Rentalnumber = new Label();
            btnSearch = new Button();
            btnCollectCar = new Button();
            txtCustID = new TextBox();
            txtRentNum = new TextBox();
            lblStatus = new Label();
            txtStatus = new TextBox();
            grpSearchRental = new GroupBox();
            grpCollectCar = new GroupBox();
            grdRentals = new DataGridView();
            grpRentalInfo = new GroupBox();
            grpSearchRental.SuspendLayout();
            grpCollectCar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRentals).BeginInit();
            grpRentalInfo.SuspendLayout();
            SuspendLayout();
            // 
            // CustID
            // 
            CustID.AutoSize = true;
            CustID.Location = new Point(0, 29);
            CustID.Name = "CustID";
            CustID.Size = new Size(73, 15);
            CustID.TabIndex = 0;
            CustID.Text = "Customer ID";
            // 
            // Rentalnumber
            // 
            Rentalnumber.AutoSize = true;
            Rentalnumber.Location = new Point(285, 30);
            Rentalnumber.Name = "Rentalnumber";
            Rentalnumber.Size = new Size(87, 15);
            Rentalnumber.TabIndex = 1;
            Rentalnumber.Text = "Rental Number";
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(0, 76);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(578, 36);
            btnSearch.TabIndex = 4;
            btnSearch.Text = "Search Customer";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnCollectCar
            // 
            btnCollectCar.ForeColor = SystemColors.Highlight;
            btnCollectCar.Location = new Point(0, 22);
            btnCollectCar.Name = "btnCollectCar";
            btnCollectCar.Size = new Size(204, 66);
            btnCollectCar.TabIndex = 5;
            btnCollectCar.Text = "Collect Car";
            btnCollectCar.UseVisualStyleBackColor = true;
            btnCollectCar.Click += btnCollectCar_Click;
            // 
            // txtCustID
            // 
            txtCustID.Location = new Point(86, 27);
            txtCustID.MaxLength = 9;
            txtCustID.Name = "txtCustID";
            txtCustID.Size = new Size(117, 23);
            txtCustID.TabIndex = 6;
            // 
            // txtRentNum
            // 
            txtRentNum.Location = new Point(378, 26);
            txtRentNum.MaxLength = 9;
            txtRentNum.Name = "txtRentNum";
            txtRentNum.Size = new Size(87, 23);
            txtRentNum.TabIndex = 7;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(0, 108);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(39, 15);
            lblStatus.TabIndex = 10;
            lblStatus.Text = "Status";
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(45, 100);
            txtStatus.MaxLength = 1;
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(29, 23);
            txtStatus.TabIndex = 11;
            // 
            // grpSearchRental
            // 
            grpSearchRental.Controls.Add(btnSearch);
            grpSearchRental.Controls.Add(CustID);
            grpSearchRental.Controls.Add(txtCustID);
            grpSearchRental.Controls.Add(Rentalnumber);
            grpSearchRental.Controls.Add(txtRentNum);
            grpSearchRental.Location = new Point(2, 12);
            grpSearchRental.Name = "grpSearchRental";
            grpSearchRental.Size = new Size(578, 117);
            grpSearchRental.TabIndex = 12;
            grpSearchRental.TabStop = false;
            grpSearchRental.Text = "Search Rental";
            // 
            // grpCollectCar
            // 
            grpCollectCar.Controls.Add(btnCollectCar);
            grpCollectCar.Controls.Add(lblStatus);
            grpCollectCar.Controls.Add(txtStatus);
            grpCollectCar.Location = new Point(8, 399);
            grpCollectCar.Name = "grpCollectCar";
            grpCollectCar.Size = new Size(315, 126);
            grpCollectCar.TabIndex = 13;
            grpCollectCar.TabStop = false;
            grpCollectCar.Text = "Collect Car";
            grpCollectCar.Visible = false;
            // 
            // grdRentals
            // 
            grdRentals.BackgroundColor = SystemColors.ButtonHighlight;
            grdRentals.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRentals.Location = new Point(6, 22);
            grdRentals.Name = "grdRentals";
            grdRentals.RowHeadersWidth = 82;
            grdRentals.RowTemplate.Height = 25;
            grdRentals.Size = new Size(553, 174);
            grdRentals.TabIndex = 14;
            grdRentals.CellClick += grdRentals_CellClick;
            // 
            // grpRentalInfo
            // 
            grpRentalInfo.Controls.Add(grdRentals);
            grpRentalInfo.Location = new Point(2, 162);
            grpRentalInfo.Name = "grpRentalInfo";
            grpRentalInfo.Size = new Size(568, 199);
            grpRentalInfo.TabIndex = 15;
            grpRentalInfo.TabStop = false;
            grpRentalInfo.Text = "Rental Information";
            grpRentalInfo.Visible = false;
            // 
            // frmCollectCar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(614, 585);
            Controls.Add(grpRentalInfo);
            Controls.Add(grpCollectCar);
            Controls.Add(grpSearchRental);
            Name = "frmCollectCar";
            Text = "frmCollectCar";
            Load += frmCollectCar_Load;
            grpSearchRental.ResumeLayout(false);
            grpSearchRental.PerformLayout();
            grpCollectCar.ResumeLayout(false);
            grpCollectCar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdRentals).EndInit();
            grpRentalInfo.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label CustID;
        private Label Rentalnumber;
        private Button btnSearch;
        private Button btnCollectCar;
        private TextBox txtCustID;
        private TextBox txtRentNum;
        private Label lblStatus;
        private TextBox txtStatus;
        private GroupBox grpSearchRental;
        private GroupBox grpCollectCar;
        private DataGridView grdRentals;
        private GroupBox grpRentalInfo;
    }
}