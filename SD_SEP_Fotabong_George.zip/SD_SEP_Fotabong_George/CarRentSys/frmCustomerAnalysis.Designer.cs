﻿namespace CarRentSys
{
    partial class frmCustomerAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            grpSearch = new GroupBox();
            cboYears = new ComboBox();
            btnSearchYear = new Button();
            YEAR = new Label();
            grpPrint = new GroupBox();
            btnPrint = new Button();
            ChrtCust = new System.Windows.Forms.DataVisualization.Charting.Chart();
            grpChart = new GroupBox();
            grpSearch.SuspendLayout();
            grpPrint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ChrtCust).BeginInit();
            grpChart.SuspendLayout();
            SuspendLayout();
            // 
            // grpSearch
            // 
            grpSearch.Controls.Add(cboYears);
            grpSearch.Controls.Add(btnSearchYear);
            grpSearch.Controls.Add(YEAR);
            grpSearch.Location = new Point(6, 18);
            grpSearch.Margin = new Padding(2, 1, 2, 1);
            grpSearch.Name = "grpSearch";
            grpSearch.Padding = new Padding(2, 1, 2, 1);
            grpSearch.Size = new Size(320, 66);
            grpSearch.TabIndex = 13;
            grpSearch.TabStop = false;
            grpSearch.Text = "Find Cars";
            // 
            // cboYears
            // 
            cboYears.DropDownStyle = ComboBoxStyle.DropDownList;
            cboYears.FormattingEnabled = true;
            cboYears.Location = new Point(39, 24);
            cboYears.Margin = new Padding(2, 1, 2, 1);
            cboYears.Name = "cboYears";
            cboYears.Size = new Size(68, 23);
            cboYears.TabIndex = 16;
            // 
            // btnSearchYear
            // 
            btnSearchYear.ForeColor = SystemColors.Highlight;
            btnSearchYear.Location = new Point(125, 21);
            btnSearchYear.Name = "btnSearchYear";
            btnSearchYear.Size = new Size(129, 27);
            btnSearchYear.TabIndex = 15;
            btnSearchYear.Text = "Search";
            btnSearchYear.UseVisualStyleBackColor = true;
            btnSearchYear.Click += btnSearchYear_Click;
            // 
            // YEAR
            // 
            YEAR.AutoSize = true;
            YEAR.Location = new Point(5, 27);
            YEAR.Name = "YEAR";
            YEAR.Size = new Size(29, 15);
            YEAR.TabIndex = 11;
            YEAR.Text = "Year";
            // 
            // grpPrint
            // 
            grpPrint.Controls.Add(btnPrint);
            grpPrint.Location = new Point(6, 192);
            grpPrint.Margin = new Padding(2, 1, 2, 1);
            grpPrint.Name = "grpPrint";
            grpPrint.Padding = new Padding(2, 1, 2, 1);
            grpPrint.Size = new Size(258, 81);
            grpPrint.TabIndex = 14;
            grpPrint.TabStop = false;
            grpPrint.Text = "Print";
            grpPrint.Visible = false;
            // 
            // btnPrint
            // 
            btnPrint.ForeColor = SystemColors.Highlight;
            btnPrint.Location = new Point(-3, 17);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(262, 64);
            btnPrint.TabIndex = 13;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            // 
            // ChrtCust
            // 
            chartArea1.Name = "ChartArea1";
            ChrtCust.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            ChrtCust.Legends.Add(legend1);
            ChrtCust.Location = new Point(13, 18);
            ChrtCust.Margin = new Padding(2, 1, 2, 1);
            ChrtCust.Name = "ChrtCust";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            ChrtCust.Series.Add(series1);
            ChrtCust.Size = new Size(704, 412);
            ChrtCust.TabIndex = 11;
            ChrtCust.Text = "Customer Analysis";
            // 
            // grpChart
            // 
            grpChart.Controls.Add(ChrtCust);
            grpChart.Location = new Point(426, 27);
            grpChart.Margin = new Padding(2, 1, 2, 1);
            grpChart.Name = "grpChart";
            grpChart.Padding = new Padding(2, 1, 2, 1);
            grpChart.Size = new Size(721, 442);
            grpChart.TabIndex = 15;
            grpChart.TabStop = false;
            grpChart.Text = "Chart";
            grpChart.Visible = false;
            // 
            // frmCustomerAnalysis
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1158, 493);
            Controls.Add(grpChart);
            Controls.Add(grpPrint);
            Controls.Add(grpSearch);
            Name = "frmCustomerAnalysis";
            Text = "frmCustomerAnalysis";
            grpSearch.ResumeLayout(false);
            grpSearch.PerformLayout();
            grpPrint.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ChrtCust).EndInit();
            grpChart.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private GroupBox grpSearch;
        private Button btnSearchYear;
        private Label YEAR;
        private GroupBox grpPrint;
        private Button btnPrint;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChrtCust;
        private GroupBox grpChart;
        private ComboBox cboYears;
    }
}