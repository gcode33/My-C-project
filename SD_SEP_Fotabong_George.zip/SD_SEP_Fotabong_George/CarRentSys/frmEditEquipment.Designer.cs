﻿namespace CarRentSys
{
    partial class frmEditEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            EquipmentID = new Label();
            txtEquipID = new TextBox();
            grpEditEquip = new GroupBox();
            btnSubmit = new Button();
            txtStat = new TextBox();
            txtPrice = new TextBox();
            txtDescription = new TextBox();
            Status = new Label();
            Price = new Label();
            Description = new Label();
            grdEditEquip = new DataGridView();
            btnSearchEquip = new Button();
            grpEditEquip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdEditEquip).BeginInit();
            SuspendLayout();
            // 
            // EquipmentID
            // 
            EquipmentID.AutoSize = true;
            EquipmentID.Location = new Point(-4, 41);
            EquipmentID.Margin = new Padding(4, 0, 4, 0);
            EquipmentID.Name = "EquipmentID";
            EquipmentID.Size = new Size(160, 32);
            EquipmentID.TabIndex = 2;
            EquipmentID.Text = "Equipment ID";
            // 
            // txtEquipID
            // 
            txtEquipID.Location = new Point(212, 41);
            txtEquipID.Margin = new Padding(4, 2, 4, 2);
            txtEquipID.MaxLength = 10;
            txtEquipID.Name = "txtEquipID";
            txtEquipID.Size = new Size(240, 39);
            txtEquipID.TabIndex = 3;
            // 
            // grpEditEquip
            // 
            grpEditEquip.Controls.Add(btnSubmit);
            grpEditEquip.Controls.Add(txtStat);
            grpEditEquip.Controls.Add(txtPrice);
            grpEditEquip.Controls.Add(txtDescription);
            grpEditEquip.Controls.Add(Status);
            grpEditEquip.Controls.Add(Price);
            grpEditEquip.Controls.Add(Description);
            grpEditEquip.Location = new Point(13, 337);
            grpEditEquip.Margin = new Padding(4, 2, 4, 2);
            grpEditEquip.Name = "grpEditEquip";
            grpEditEquip.Padding = new Padding(4, 2, 4, 2);
            grpEditEquip.Size = new Size(808, 399);
            grpEditEquip.TabIndex = 4;
            grpEditEquip.TabStop = false;
            grpEditEquip.Text = "Edit Equipment";
            grpEditEquip.Visible = false;
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(215, 252);
            btnSubmit.Margin = new Padding(4, 2, 4, 2);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(305, 143);
            btnSubmit.TabIndex = 7;
            btnSubmit.Text = "Edit Equipment";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(104, 226);
            txtStat.Margin = new Padding(4, 2, 4, 2);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(45, 39);
            txtStat.TabIndex = 6;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(89, 145);
            txtPrice.Margin = new Padding(4, 2, 4, 2);
            txtPrice.MaxLength = 7;
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(119, 39);
            txtPrice.TabIndex = 5;
            txtPrice.Text = "0.00";
            txtPrice.TextAlign = HorizontalAlignment.Right;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(150, 64);
            txtDescription.Margin = new Padding(4, 2, 4, 2);
            txtDescription.MaxLength = 15;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(190, 39);
            txtDescription.TabIndex = 4;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(0, 230);
            Status.Margin = new Padding(4, 0, 4, 0);
            Status.Name = "Status";
            Status.Size = new Size(78, 32);
            Status.TabIndex = 2;
            Status.Text = "Status";
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Location = new Point(7, 154);
            Price.Margin = new Padding(4, 0, 4, 0);
            Price.Name = "Price";
            Price.Size = new Size(65, 32);
            Price.TabIndex = 1;
            Price.Text = "Price";
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(7, 64);
            Description.Margin = new Padding(4, 0, 4, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 0;
            Description.Text = "Description";
            // 
            // grdEditEquip
            // 
            grdEditEquip.BackgroundColor = SystemColors.ButtonHighlight;
            grdEditEquip.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdEditEquip.Location = new Point(4, 115);
            grdEditEquip.Margin = new Padding(4, 2, 4, 2);
            grdEditEquip.Name = "grdEditEquip";
            grdEditEquip.RowHeadersWidth = 82;
            grdEditEquip.RowTemplate.Height = 41;
            grdEditEquip.Size = new Size(817, 201);
            grdEditEquip.TabIndex = 5;
            grdEditEquip.Visible = false;
            grdEditEquip.CellClick += grdEditEquip_CellClick_1;
            // 
            // btnSearchEquip
            // 
            btnSearchEquip.ForeColor = SystemColors.Highlight;
            btnSearchEquip.Location = new Point(474, 26);
            btnSearchEquip.Margin = new Padding(4, 2, 4, 2);
            btnSearchEquip.Name = "btnSearchEquip";
            btnSearchEquip.Size = new Size(305, 62);
            btnSearchEquip.TabIndex = 8;
            btnSearchEquip.Text = "Search Equipment";
            btnSearchEquip.UseVisualStyleBackColor = true;
            btnSearchEquip.Click += btnSearchEquip_Click;
            // 
            // frmEditEquipment
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1103, 734);
            Controls.Add(btnSearchEquip);
            Controls.Add(grdEditEquip);
            Controls.Add(grpEditEquip);
            Controls.Add(txtEquipID);
            Controls.Add(EquipmentID);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmEditEquipment";
            Text = "frmEditEquipment";
            grpEditEquip.ResumeLayout(false);
            grpEditEquip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdEditEquip).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label EquipmentID;
        private TextBox txtEquipID;
        private GroupBox grpEditEquip;
        private Button btnSubmit;
        private TextBox txtStat;
        private TextBox txtPrice;
        private TextBox txtDescription;
        private Label Status;
        private Label Price;
        private Label Description;
        private DataGridView grdEditEquip;
        private Button btnSearchEquip;
    }
}