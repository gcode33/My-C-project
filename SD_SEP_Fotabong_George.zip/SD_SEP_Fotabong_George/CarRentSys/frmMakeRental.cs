﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CarRentSys
{
    public partial class frmMakeRental : Form
    {
        //creating a variable named cars of type Cars and initializes it with a new instance of the Cars class. 
        Cars cars = new Cars();

        //creating a variable named equip of type Equipment and initializes it with a new instance of the Equipment class.
        Equipment equip = new Equipment();


        private decimal initialCarCost = 0;
        public frmMakeRental()
        {
            InitializeComponent();
        }
        private void frmMakeRental_Load(object sender, EventArgs e)
        {
            // load car types
            cboCarTypes = Utility.loadCombo(cboCarTypes, "SELECT * FROM CarTypes ORDER BY TypeCode", 2);

            //load Times
            cboTimeFrom = Utility.loadCombo(cboTimeFrom, "SELECT * FROM RentTimes", 1);
            cboTimeTo = Utility.loadCombo(cboTimeTo, "SELECT * FROM RentTimes", 1);

            //setting the format of the calendar to a custom format ot YYY-DD-MM
            dateStart.CustomFormat = "";
            dateStart.Format = DateTimePickerFormat.Custom;

            dateReturn.CustomFormat = "";
            dateReturn.Format = DateTimePickerFormat.Custom;


        }




        private void dateStart_ValueChanged(object sender, EventArgs e)
        {
            //setting the custom format of the calendar 
            dateStart.CustomFormat = "yyy-MM-dd";
            dateReturn.Value = dateStart.Value.AddDays(1);
        }
        private void dateReturn_ValueChanged(object sender, EventArgs e)
        {
            dateReturn.CustomFormat = "yyy-MM-dd";
        }

        private void btnCarSearch_Click(object sender, EventArgs e)
        {
            //validation for the searching of the cars
            if (cboCarTypes.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a car type", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboCarTypes.Focus();
                return;
            }
            if (cboTimeFrom.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboTimeFrom.Focus();
                return;
            }

            if (cboTimeTo.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboTimeFrom.Focus();
                return;
            }

            if (dateStart.CustomFormat == null)
            {
                MessageBox.Show("the Start date must be entered", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dateStart.Focus();
                return;
            }

            if (dateReturn.CustomFormat == null)
            {
                MessageBox.Show("the return date must be entered", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dateReturn.Focus();
                return;
            }

            grdAvailableCars.DataSource = Rental.GetAvailableCarsForDates(cboCarTypes.Text.Substring(0, 2), dateStart.Value.ToShortDateString(), dateReturn.Value.ToShortDateString()).Tables["AvailableCars"];

            // Check if there are no cars available if no the send error message
            if (grdAvailableCars.Rows.Count == 1)
            {
                MessageBox.Show("There are no cars available.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //if yes then send comfirmation message and make the group box with the customer form visible 
            MessageBox.Show("There are cars available add your customer information.", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
            grpCustInfo.Visible = true;


        }

        private void grdAvailableCars_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //fill variables with teh values needed from the grid box 
            decimal rate = Convert.ToDecimal(grdAvailableCars.Rows[grdAvailableCars.CurrentCell.RowIndex].Cells[4].Value);
            string RegNum = grdAvailableCars.Rows[grdAvailableCars.CurrentCell.RowIndex].Cells[0].Value.ToString();
            
            //setting a variable to hold the new status of the car
            string Carstatus = "U";

            //invoking the update car status method to update the status of the car based on the RegNum
            cars.updateCarStatus(Carstatus, RegNum);

            // Parse the rent start date and return date
            DateTime rentStartDate = dateStart.Value;
            DateTime returnDate = dateReturn.Value;

            // Calculate the difference between the rent start date and return date
            TimeSpan difference = returnDate - rentStartDate;
            int daysDifference = difference.Days;



            // Populate the text box with the calculated total cost
            //if the difference in days is only one the the cost is just the daily rate of the car else do the math 
            if (daysDifference == 0)
            {
                txtTotalCost.Text = rate.ToString();
            }
            else
            {
                txtTotalCost.Text = (rate * daysDifference).ToString();
            }
            txtRegNum.Text = RegNum;


            // Store the initial car cost
            initialCarCost = Convert.ToDecimal(txtTotalCost.Text);

            //make the group box showing the cost of the rental and the payment visible 
            grpRentalCosts.Visible = true;
            grpRentalPay.Visible = true;
            
            //set the rental number for the rental using the get next rental number method
            txtRentNum.Text = Rental.getNextRentalNumber().ToString("00000000");

            //set the customer status to P for paid 
            txtStatus.Text = "P";

        }
        private void btnAddCust_Click(object sender, EventArgs e)
        {
            //validate info entered by customer 
            if (txtForename.Text.Equals("") || txtForename.Text.Any(char.IsDigit))
            {
                MessageBox.Show("The forename must be entered and cannot contain numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtForename.Focus();
                return;
            }

            if (txtSurname.Text.Equals("") || txtSurname.Text.Any(char.IsDigit))
            {
                MessageBox.Show("The surname must be entered and cannot contain numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSurname.Focus();
                return;
            }

            if (txtPhoneNum.Text.Equals("") || !txtPhoneNum.Text.All(char.IsDigit) || txtPhoneNum.Text.Length > 12)
            {
                MessageBox.Show("The phone number must be entered and can only contain numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPhoneNum.Focus();
                return;
            }

            if (txtLicence.Text.Equals("")  || txtLicence.Text.Count(char.IsDigit) < 3 || txtLicence.Text.Length > 9 || txtLicence.Text.Length < 9)
            {
                MessageBox.Show("The driver's licence number must be entered and contain at least three digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLicence.Focus();
                return;
            }

            if (txtEmail.Text.Equals("") || !txtEmail.Text.Contains("@") || !(txtEmail.Text.EndsWith(".com") || txtEmail.Text.EndsWith(".org") || txtEmail.Text.EndsWith(".ie")) || txtEmail.Text.Length > 30)
            {
                MessageBox.Show("The email must be entered in a valid format (e.g., example@example.com, example@example.org, example@example.ie) and must not be more than 30 characters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return;
            }

            //invoke the method to get the next customer ID 
            txtCustID.Text = Customer.getNextCustID().ToString("");


            //instanciate the customer with the variables
            Customer cust = new Customer(Convert.ToInt32(txtCustID.Text), txtForename.Text, txtSurname.Text, txtEmail.Text, Int64.Parse(txtPhoneNum.Text), txtLicence.Text);

            //invoke the add customer method to add a new customer to the database 
            cust.addCustomer();

            //comfirmation message for new customer added
            MessageBox.Show("Customer " + txtForename.Text + " " + txtSurname.Text + " information has been saved and added to the Customers file", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            //make the group box holding th grid box visible 
            grpCars.Visible = true;

            //make the group box holding the check box for equipment visible 
            grpEquipCheck.Visible = true;

            //setting the equip ID to 1 for if the check box for equipment is not selected to have no equipment
            txtEquipID.Text = "1";

           
        }



        private void chkBoxEquip_CheckedChanged(object sender, EventArgs e)
        {
            //checking if the checkbox is selected if it is make the group box holding the equipment griid box visible 
            if (chkBoxEquip.Checked)
            {
                grpEquip.Visible = true;
            }
       


        }

        private void btnSearchEquipment_Click(object sender, EventArgs e)
        {
            //fill the grid box with available equipment based on the get available equipment method 
            grdAvailableEquip.DataSource = Rental.getAvailableEquipment().Tables["AvailableEquip"];
            if (grdAvailableEquip.Rows.Count == 1)
            {
                MessageBox.Show("There is no available equipment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void grdAvailableEquip_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Retrieve the price and the equipID of the equipment from the grid box 
            decimal price = Convert.ToDecimal(grdAvailableEquip.Rows[e.RowIndex].Cells[4].Value);
            int equipID = Convert.ToInt32(grdAvailableEquip.Rows[e.RowIndex].Cells[1].Value);

            //setting a variable to hold the new status of the equipID
            string equipStat = "U";

            //invoke update equipment status to update the equipment status based on the equipID 
            equip.updateEquipmentStatus(equipStat, equipID);

            // Calculate the total cost by adding the price of equipment to the initial car cost
            decimal totalCost = initialCarCost + price;


            // Populate the text box with the updated total cost
            txtTotalCost.Text = totalCost.ToString();
            txtEquipID.Text = equipID.ToString();
        }

        private void btnPay_Click_1(object sender, EventArgs e)
        {
               
            //instanciate the variables 
            Rental rent = new Rental(Convert.ToInt32(txtRentNum.Text), txtRegNum.Text, cboCarTypes.Text.Substring(0, 2), dateStart.Value.ToString("yyyy-MM-dd"), dateReturn.Value.ToString("yyyy-MM-dd"), cboTimeFrom.Text.Substring(0), cboTimeTo.Text.Substring(0), Convert.ToDecimal(txtTotalCost.Text), Convert.ToInt32(txtCustID.Text), Convert.ToInt32(txtEquipID.Text), txtStatus.Text);
            
            //invoke the make rental method to create the rental using the instanciated variables
            rent.makeRental();

            //send a comfirmation message of rental 
            MessageBox.Show("Customer " + Forename.Text + " " + Surname.Text + " Rental has been made and their rental information has been saved into the rental file with a rental number of " + txtRentNum.Text + " and their customer information has been saved to the customer file with a customer id of " + txtCustID.Text + "the cars status has also been set to unavailable", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            //reset the UI
            grpCustInfo.Visible = false;
            grpCars.Visible = false;
            grpRental.Visible = true;
            grpEquip.Visible = false;
            grpRentalCosts.Visible = false;
            grpEquipCheck.Visible = false;
            grpRentalPay.Visible = false;   
            txtTotalCost.Clear();
            txtRentNum.Clear();
            txtCustID.Clear();
            txtEmail.Clear();
            txtEquipID.Clear();
            txtForename.Clear();
            txtPhoneNum.Clear();
            txtRegNum.Clear();
            cboTimeTo.SelectedIndex = -1;
            cboTimeFrom.SelectedIndex = -1;
            txtSurname.Clear();
            txtStatus.Clear();
        }
    }
}
