﻿namespace CarRentSys
{
    partial class frmRemoveCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpRemCar = new GroupBox();
            txtStat = new TextBox();
            Status = new Label();
            btnRemove = new Button();
            btnSearch = new Button();
            txtRegNum = new TextBox();
            RegNum = new Label();
            grdRemoveCar = new DataGridView();
            grpRemCar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdRemoveCar).BeginInit();
            SuspendLayout();
            // 
            // grpRemCar
            // 
            grpRemCar.Controls.Add(txtStat);
            grpRemCar.Controls.Add(Status);
            grpRemCar.Controls.Add(btnRemove);
            grpRemCar.Location = new Point(13, 410);
            grpRemCar.Margin = new Padding(4, 2, 4, 2);
            grpRemCar.Name = "grpRemCar";
            grpRemCar.Padding = new Padding(4, 2, 4, 2);
            grpRemCar.Size = new Size(780, 239);
            grpRemCar.TabIndex = 0;
            grpRemCar.TabStop = false;
            grpRemCar.Text = "Remove Car";
            grpRemCar.Visible = false;
            // 
            // txtStat
            // 
            txtStat.Location = new Point(87, 62);
            txtStat.Margin = new Padding(4, 2, 4, 2);
            txtStat.MaxLength = 1;
            txtStat.Name = "txtStat";
            txtStat.ReadOnly = true;
            txtStat.Size = new Size(43, 39);
            txtStat.TabIndex = 9;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(7, 73);
            Status.Margin = new Padding(4, 0, 4, 0);
            Status.Name = "Status";
            Status.Size = new Size(78, 32);
            Status.TabIndex = 8;
            Status.Text = "Status";
            // 
            // btnRemove
            // 
            btnRemove.ForeColor = SystemColors.Highlight;
            btnRemove.Location = new Point(7, 115);
            btnRemove.Margin = new Padding(4, 2, 4, 2);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(215, 113);
            btnRemove.TabIndex = 7;
            btnRemove.Text = "REMOVE";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnSearch
            // 
            btnSearch.ForeColor = SystemColors.Highlight;
            btnSearch.Location = new Point(461, 0);
            btnSearch.Margin = new Padding(4, 2, 4, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(139, 62);
            btnSearch.TabIndex = 6;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtRegNum
            // 
            txtRegNum.Location = new Point(256, 11);
            txtRegNum.Margin = new Padding(4, 2, 4, 2);
            txtRegNum.MaxLength = 10;
            txtRegNum.Name = "txtRegNum";
            txtRegNum.Size = new Size(171, 39);
            txtRegNum.TabIndex = 1;
            // 
            // RegNum
            // 
            RegNum.AutoSize = true;
            RegNum.Location = new Point(13, 9);
            RegNum.Margin = new Padding(4, 0, 4, 0);
            RegNum.Name = "RegNum";
            RegNum.Size = new Size(235, 32);
            RegNum.TabIndex = 0;
            RegNum.Text = "Registration Number";
            // 
            // grdRemoveCar
            // 
            grdRemoveCar.BackgroundColor = SystemColors.ButtonHighlight;
            grdRemoveCar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdRemoveCar.Location = new Point(24, 83);
            grdRemoveCar.Margin = new Padding(4, 2, 4, 2);
            grdRemoveCar.Name = "grdRemoveCar";
            grdRemoveCar.RowHeadersWidth = 82;
            grdRemoveCar.RowTemplate.Height = 41;
            grdRemoveCar.Size = new Size(737, 267);
            grdRemoveCar.TabIndex = 7;
            grdRemoveCar.Visible = false;
            grdRemoveCar.CellClick += grdRemoveCar_CellClick_1;
            // 
            // frmRemoveCar
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(852, 917);
            Controls.Add(grdRemoveCar);
            Controls.Add(grpRemCar);
            Controls.Add(RegNum);
            Controls.Add(txtRegNum);
            Controls.Add(btnSearch);
            Margin = new Padding(4, 2, 4, 2);
            Name = "frmRemoveCar";
            Text = "frmRemoveCar";
            grpRemCar.ResumeLayout(false);
            grpRemCar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdRemoveCar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpRemCar;
        private TextBox txtRegNum;
        private Label RegNum;
        private Button btnSearch;
        private Button btnRemove;
        private TextBox txtStat;
        private Label Status;
        private DataGridView grdRemoveCar;
    }
}