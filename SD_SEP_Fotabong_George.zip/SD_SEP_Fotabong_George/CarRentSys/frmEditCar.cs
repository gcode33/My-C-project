﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmEditCar : Form
    {
        Cars theCar = new Cars();

        public frmEditCar()
        {
            InitializeComponent();
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validation
            if (txtRegNum.Text.Equals("") || !txtRegNum.Text.Any(char.IsDigit) || txtRegNum.Text.Count(char.IsDigit) < 3 || txtRegNum.Text.Length < 9 || txtRegNum.Text.Length > 9)
            {
                MessageBox.Show("Invalid Registration number, must be 9 digits and must have at least three digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRegNum.Focus();
                return; // Exit the method if validation fails
            }

            // If the code reaches here, it means the validation passed
            MessageBox.Show("Valid Registration number, car has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Finding matching Cars based on regnum entered 
            grdCars.DataSource = Cars.findCar(txtRegNum.Text).Tables["cars"];

            //if there is no car with that regnum the display this message 
            if (grdCars.Rows.Count == 1)
            {
                MessageBox.Show("no data found");
                txtRegNum.Focus();
            }
            //make group box holding the grid box info visible 
            grdCars.Visible = true;



        }

        private void grdCars_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //extract the RegNum from column zero on the slected rrow in grid
            String RegNum = grdCars.Rows[grdCars.CurrentCell.RowIndex].Cells[0].Value.ToString();


            //Instanciate theCar
            theCar.getCar(RegNum);


            //move the instance variable values to the form controls
            txtRegNum.Text = theCar.get_regNum();
            txtDescription.Text = theCar.getDescription();
            txtFuelType.Text = theCar.getFuelType();
            txtStat.Text = theCar.getStatus();

            //if the status of the Car is No A for available then send a message saying that the car cant be edited 
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this car may not be edited yet because it is currently in use please choose another car", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                txtRegNum.Clear();
                txtStat.Clear();
                grpEditCar.Visible = false;
                grdCars.Visible = false;
            }





            //make the car data available for updating
            grpEditCar.Visible = true;

        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //validating the new entered data
            if (txtDescription.Text.Equals("") || txtDescription.Text.Any(char.IsDigit) || txtDescription.Text.Length > 10 )
            {
                MessageBox.Show("Desccription must be entered and must not include digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return;
            }
            if (txtFuelType.Text.Equals("") || txtFuelType.Text.Any(char.IsDigit) || txtFuelType.Text.Length > 1)
            {
                MessageBox.Show("Fuel type must be entered", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFuelType.Focus();
                return;
            }
            else if (!txtFuelType.Text.Equals("H", StringComparison.OrdinalIgnoreCase) &&
                     !txtFuelType.Text.Equals("G", StringComparison.OrdinalIgnoreCase) &&
                     !txtFuelType.Text.Equals("D", StringComparison.OrdinalIgnoreCase) &&
                     !txtFuelType.Text.Equals("E", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Invalid fuel type entered. Fuel type must be 'H', 'G', 'D', or 'E'.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFuelType.Focus();
                return;
            }

            //setting the status to A for available
            txtStat.Text = "A";

            //instanciate the object variables 
            theCar.setregNum(txtRegNum.Text);
            theCar.setdescription(txtDescription.Text);
            theCar.setfeulType(txtFuelType.Text);
            theCar.setstatus(txtStat.Text);


            //invoke the update car method to update the data in the database
            theCar.updateCar();


            //display confirmation message
            MessageBox.Show("Car Updated", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);


            //reset UI
            grpEditCar.Visible = false;
            grdCars.Visible = false;
            txtRegNum.Clear();
            txtRegNum.Focus();
            txtDescription.Clear();
        }


    }
}
