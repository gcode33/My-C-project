﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmRemoveEquipment : Form
    {
        //creating a variable named equip of type Equipment and initializes it with a new instance of the Equipment class.
        Equipment equip = new Equipment();
        public frmRemoveEquipment()
        {
            InitializeComponent();
        }



        private void btnSearch_Click(object sender, EventArgs e)
        {
            //validate data enterd 
            if (txtEquipID.Text.Equals("") || !txtEquipID.Text.Any(char.IsDigit) || txtEquipID.Text.Length > 10 || txtEquipID.Text.StartsWith("-"))
            {
                MessageBox.Show("Invalid Equipment ID must no more than 10 digits and must not have any letters or negative numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEquipID.Focus();
                return;
            }

            // If the code reaches here, it means the validation passed
            MessageBox.Show("Valid Equipment ID the Equipment has been found", "Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // filling the grid box with the equipment info based on the EquipID
            grdRemoveEquip.DataSource = Equipment.findEquipment(int.Parse(txtEquipID.Text)).Tables["Equipment"];

            //if no matching equip ID then send error message 
            if (grdRemoveEquip.Rows.Count == 1)
            {
                MessageBox.Show("no data found");
                txtEquipID.Focus();
            }
            //make the grid box for Equipment visible
            grdRemoveEquip.Visible = true;
        }


        private void btnRemove_Click(object sender, EventArgs e)
        {
            //yes or no message to confirm removal
            DialogResult answer = MessageBox.Show("Are you sure you want to remove the Equipment : " + txtEquipID, "Confirm",
  MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                equip.removeEquipment(int.Parse(txtEquipID.Text));

                //confirmation message of removal 
                MessageBox.Show("The Equipment: " + txtEquipID.Text + " has been Removed from the Equipment file and status has been set to R for removed", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //reset UI
                grpRemEquip.Visible = false;
                grdRemoveEquip.Visible = false;
                txtEquipID.Clear();
            }
            //if no reset the UI
            grpRemEquip.Visible = false;
            grdRemoveEquip.Visible = false;
            txtEquipID.Clear();
        }

        private void grdRemoveEquip_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //extract the equipId from column zero on the selected row in grid
            int EquipID = Convert.ToInt32(grdRemoveEquip.Rows[grdRemoveEquip.CurrentCell.RowIndex].Cells[0].Value.ToString());


            //Instanciate equip
            equip.getEquipment(EquipID);


            //move the instance variable values to the form controls
            txtEquipID.Text = equip.getEquipID().ToString("000000000");
            txtStat.Text = equip.getStatus().ToString();

            //if the status is not Avalaibale("A") then send error message 
            if (txtStat.Text != "A")
            {
                MessageBox.Show("this car may not be removed yet because it is currently in use please choose another car", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStat.Focus();
                txtEquipID.Clear();
                txtStat.Clear();


            }
            //make the group box with the remove button visible 
            grpRemEquip.Visible = true;
        }
    }
}
