﻿namespace CarRentSys
{
    partial class frmSetCarType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Type = new Label();
            Description = new Label();
            DailyRate = new Label();
            btnSubmit = new Button();
            txtType = new TextBox();
            txtDescription = new TextBox();
            txtDailyRate = new TextBox();
            FuelType = new Label();
            SuspendLayout();
            // 
            // Type
            // 
            Type.AutoSize = true;
            Type.Location = new Point(0, 73);
            Type.Margin = new Padding(6, 0, 6, 0);
            Type.Name = "Type";
            Type.Size = new Size(65, 32);
            Type.TabIndex = 0;
            Type.Text = "Type";
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(0, 160);
            Description.Margin = new Padding(6, 0, 6, 0);
            Description.Name = "Description";
            Description.Size = new Size(135, 32);
            Description.TabIndex = 1;
            Description.Text = "Description";
            // 
            // DailyRate
            // 
            DailyRate.AutoSize = true;
            DailyRate.Location = new Point(0, 265);
            DailyRate.Margin = new Padding(6, 0, 6, 0);
            DailyRate.Name = "DailyRate";
            DailyRate.Size = new Size(121, 32);
            DailyRate.TabIndex = 2;
            DailyRate.Text = "Daily Rate";
            // 
            // btnSubmit
            // 
            btnSubmit.ForeColor = SystemColors.Highlight;
            btnSubmit.Location = new Point(0, 418);
            btnSubmit.Margin = new Padding(6, 6, 6, 6);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(288, 158);
            btnSubmit.TabIndex = 3;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtType
            // 
            txtType.Location = new Point(69, 73);
            txtType.Margin = new Padding(6, 6, 6, 6);
            txtType.MaxLength = 4;
            txtType.Name = "txtType";
            txtType.Size = new Size(99, 39);
            txtType.TabIndex = 4;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(150, 160);
            txtDescription.Margin = new Padding(6, 6, 6, 6);
            txtDescription.MaxLength = 10;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(171, 39);
            txtDescription.TabIndex = 5;
            // 
            // txtDailyRate
            // 
            txtDailyRate.Location = new Point(143, 265);
            txtDailyRate.Margin = new Padding(6, 6, 6, 6);
            txtDailyRate.MaxLength = 5;
            txtDailyRate.Name = "txtDailyRate";
            txtDailyRate.Size = new Size(95, 39);
            txtDailyRate.TabIndex = 6;
            txtDailyRate.Text = "0.00";
            txtDailyRate.TextAlign = HorizontalAlignment.Right;
            // 
            // FuelType
            // 
            FuelType.AutoSize = true;
            FuelType.Location = new Point(-7, 503);
            FuelType.Margin = new Padding(6, 0, 6, 0);
            FuelType.Name = "FuelType";
            FuelType.Size = new Size(0, 32);
            FuelType.TabIndex = 9;
            // 
            // frmSetCarType
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(526, 747);
            Controls.Add(FuelType);
            Controls.Add(txtDailyRate);
            Controls.Add(txtDescription);
            Controls.Add(txtType);
            Controls.Add(btnSubmit);
            Controls.Add(DailyRate);
            Controls.Add(Description);
            Controls.Add(Type);
            Margin = new Padding(6, 6, 6, 6);
            Name = "frmSetCarType";
            Text = "Car Rentals - [Set Car Type]";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Type;
        private Label Description;
        private Label DailyRate;
        private Button btnSubmit;
        private TextBox txtType;
        private TextBox txtDescription;
        private TextBox txtDailyRate;
        private Label FuelType;
    }
}