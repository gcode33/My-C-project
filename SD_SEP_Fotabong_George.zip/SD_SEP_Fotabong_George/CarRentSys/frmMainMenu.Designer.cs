﻿


namespace CarRentSys
{
    partial class frmMainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainMenu));
            mnumainmenu = new MenuStrip();
            mnuCars = new ToolStripMenuItem();
            setCarTypeToolStripMenuItem = new ToolStripMenuItem();
            addCarToolStripMenuItem = new ToolStripMenuItem();
            editCarToolStripMenuItem = new ToolStripMenuItem();
            removeCarToolStripMenuItem = new ToolStripMenuItem();
            mnuExit = new ToolStripMenuItem();
            mnuequipment = new ToolStripMenuItem();
            addEquipmentToolStripMenuItem = new ToolStripMenuItem();
            editQuipmentToolStripMenuItem = new ToolStripMenuItem();
            removeEquipmentToolStripMenuItem = new ToolStripMenuItem();
            mnuRentals = new ToolStripMenuItem();
            MakeRentalToolStripMenuItem = new ToolStripMenuItem();
            collectCarToolStripMenuItem = new ToolStripMenuItem();
            returnCarToolStripMenuItem = new ToolStripMenuItem();
            cancelRentalToolStripMenuItem = new ToolStripMenuItem();
            mnuadmin = new ToolStripMenuItem();
            MonthlyRevenueAnalysisToolStripMenuItem = new ToolStripMenuItem();
            CustomerAnalysisToolStripMenuItem = new ToolStripMenuItem();
            imageList1 = new ImageList(components);
            pictureBox1 = new PictureBox();
            btnConnect = new Button();
            lblStatus = new Label();
            mnumainmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // mnumainmenu
            // 
            mnumainmenu.BackColor = SystemColors.ActiveCaption;
            mnumainmenu.ImageScalingSize = new Size(32, 32);
            mnumainmenu.Items.AddRange(new ToolStripItem[] { mnuCars, mnuExit, mnuequipment, mnuRentals, mnuadmin });
            mnumainmenu.Location = new Point(0, 0);
            mnumainmenu.Name = "mnumainmenu";
            mnumainmenu.Size = new Size(567, 24);
            mnumainmenu.TabIndex = 0;
            mnumainmenu.Text = "mnumainmenu";
            // 
            // mnuCars
            // 
            mnuCars.DropDownItems.AddRange(new ToolStripItem[] { setCarTypeToolStripMenuItem, addCarToolStripMenuItem, editCarToolStripMenuItem, removeCarToolStripMenuItem });
            mnuCars.Name = "mnuCars";
            mnuCars.Size = new Size(42, 20);
            mnuCars.Text = "Cars";
            // 
            // setCarTypeToolStripMenuItem
            // 
            setCarTypeToolStripMenuItem.Name = "setCarTypeToolStripMenuItem";
            setCarTypeToolStripMenuItem.Size = new Size(138, 22);
            setCarTypeToolStripMenuItem.Text = "Set Car Type";
            setCarTypeToolStripMenuItem.Click += setCarTypeToolStripMenuItem_Click;
            // 
            // addCarToolStripMenuItem
            // 
            addCarToolStripMenuItem.Name = "addCarToolStripMenuItem";
            addCarToolStripMenuItem.Size = new Size(138, 22);
            addCarToolStripMenuItem.Text = "Add Car";
            addCarToolStripMenuItem.Click += addCarToolStripMenuItem_Click;
            // 
            // editCarToolStripMenuItem
            // 
            editCarToolStripMenuItem.Name = "editCarToolStripMenuItem";
            editCarToolStripMenuItem.Size = new Size(138, 22);
            editCarToolStripMenuItem.Text = "Edit Car";
            editCarToolStripMenuItem.Click += editCarToolStripMenuItem_Click;
            // 
            // removeCarToolStripMenuItem
            // 
            removeCarToolStripMenuItem.Name = "removeCarToolStripMenuItem";
            removeCarToolStripMenuItem.Size = new Size(138, 22);
            removeCarToolStripMenuItem.Text = "Remove Car";
            removeCarToolStripMenuItem.Click += removeCarToolStripMenuItem_Click;
            // 
            // mnuExit
            // 
            mnuExit.Alignment = ToolStripItemAlignment.Right;
            mnuExit.ImageAlign = ContentAlignment.MiddleRight;
            mnuExit.Name = "mnuExit";
            mnuExit.Size = new Size(38, 20);
            mnuExit.Text = "Exit";
            mnuExit.TextAlign = ContentAlignment.MiddleRight;
            mnuExit.Click += mnuExit_Click;
            // 
            // mnuequipment
            // 
            mnuequipment.DropDownItems.AddRange(new ToolStripItem[] { addEquipmentToolStripMenuItem, editQuipmentToolStripMenuItem, removeEquipmentToolStripMenuItem });
            mnuequipment.Name = "mnuequipment";
            mnuequipment.Size = new Size(77, 20);
            mnuequipment.Text = "Equipment";
            // 
            // addEquipmentToolStripMenuItem
            // 
            addEquipmentToolStripMenuItem.Name = "addEquipmentToolStripMenuItem";
            addEquipmentToolStripMenuItem.Size = new Size(178, 22);
            addEquipmentToolStripMenuItem.Text = "Add Equipment";
            addEquipmentToolStripMenuItem.Click += addEquipmentToolStripMenuItem_Click;
            // 
            // editQuipmentToolStripMenuItem
            // 
            editQuipmentToolStripMenuItem.Name = "editQuipmentToolStripMenuItem";
            editQuipmentToolStripMenuItem.Size = new Size(178, 22);
            editQuipmentToolStripMenuItem.Text = "Edit Equipment";
            editQuipmentToolStripMenuItem.Click += editQuipmentToolStripMenuItem_Click;
            // 
            // removeEquipmentToolStripMenuItem
            // 
            removeEquipmentToolStripMenuItem.Name = "removeEquipmentToolStripMenuItem";
            removeEquipmentToolStripMenuItem.Size = new Size(178, 22);
            removeEquipmentToolStripMenuItem.Text = "Remove Equipment";
            removeEquipmentToolStripMenuItem.Click += removeEquipmentToolStripMenuItem_Click;
            // 
            // mnuRentals
            // 
            mnuRentals.DropDownItems.AddRange(new ToolStripItem[] { MakeRentalToolStripMenuItem, collectCarToolStripMenuItem, returnCarToolStripMenuItem, cancelRentalToolStripMenuItem });
            mnuRentals.Name = "mnuRentals";
            mnuRentals.Size = new Size(57, 20);
            mnuRentals.Text = "Rentals";
            // 
            // MakeRentalToolStripMenuItem
            // 
            MakeRentalToolStripMenuItem.Name = "MakeRentalToolStripMenuItem";
            MakeRentalToolStripMenuItem.Size = new Size(146, 22);
            MakeRentalToolStripMenuItem.Text = "Make Rental";
            MakeRentalToolStripMenuItem.Click += MakeRentalToolStripMenuItem_Click;
            // 
            // collectCarToolStripMenuItem
            // 
            collectCarToolStripMenuItem.Name = "collectCarToolStripMenuItem";
            collectCarToolStripMenuItem.Size = new Size(146, 22);
            collectCarToolStripMenuItem.Text = "Collect Car";
            collectCarToolStripMenuItem.Click += collectCarToolStripMenuItem_Click;
            // 
            // returnCarToolStripMenuItem
            // 
            returnCarToolStripMenuItem.Name = "returnCarToolStripMenuItem";
            returnCarToolStripMenuItem.Size = new Size(146, 22);
            returnCarToolStripMenuItem.Text = "Return Car";
            returnCarToolStripMenuItem.Click += returnCarToolStripMenuItem_Click;
            // 
            // cancelRentalToolStripMenuItem
            // 
            cancelRentalToolStripMenuItem.Name = "cancelRentalToolStripMenuItem";
            cancelRentalToolStripMenuItem.Size = new Size(146, 22);
            cancelRentalToolStripMenuItem.Text = "Cancel Rental";
            cancelRentalToolStripMenuItem.Click += cancelRentalToolStripMenuItem_Click;
            // 
            // mnuadmin
            // 
            mnuadmin.DropDownItems.AddRange(new ToolStripItem[] { MonthlyRevenueAnalysisToolStripMenuItem, CustomerAnalysisToolStripMenuItem });
            mnuadmin.Name = "mnuadmin";
            mnuadmin.Size = new Size(55, 20);
            mnuadmin.Text = "Admin";
            // 
            // MonthlyRevenueAnalysisToolStripMenuItem
            // 
            MonthlyRevenueAnalysisToolStripMenuItem.Name = "MonthlyRevenueAnalysisToolStripMenuItem";
            MonthlyRevenueAnalysisToolStripMenuItem.Size = new Size(213, 22);
            MonthlyRevenueAnalysisToolStripMenuItem.Text = "Monthly Revenue Analysis";
            MonthlyRevenueAnalysisToolStripMenuItem.Click += MonthlyRevenueAnalysisToolStripMenuItem_Click;
            // 
            // CustomerAnalysisToolStripMenuItem
            // 
            CustomerAnalysisToolStripMenuItem.Name = "CustomerAnalysisToolStripMenuItem";
            CustomerAnalysisToolStripMenuItem.Size = new Size(213, 22);
            CustomerAnalysisToolStripMenuItem.Text = "Customer Analysis";
            CustomerAnalysisToolStripMenuItem.Click += CustomerAnalysisToolStripMenuItem_Click;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ActiveCaption;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(567, 403);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(293, 298);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(75, 23);
            btnConnect.TabIndex = 2;
            btnConnect.Text = "Connect";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(310, 335);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(36, 15);
            lblStatus.TabIndex = 3;
            lblStatus.Text = "Close";
            // 
            // frmMainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(567, 410);
            Controls.Add(lblStatus);
            Controls.Add(btnConnect);
            Controls.Add(mnumainmenu);
            Controls.Add(pictureBox1);
            MainMenuStrip = mnumainmenu;
            Name = "frmMainMenu";
            Text = "Car Rentals - [Main Menu]";
            mnumainmenu.ResumeLayout(false);
            mnumainmenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip mnumainmenu;
        private ToolStripMenuItem mnuCars;
        private ToolStripMenuItem mnuRentals;
        private ToolStripMenuItem mnuadmin;
        private ToolStripMenuItem mnuExit;
        private ToolStripMenuItem mnuequipment;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private ToolStripMenuItem setCarTypeToolStripMenuItem;
        private ToolStripMenuItem addCarToolStripMenuItem;
        private ToolStripMenuItem editCarToolStripMenuItem;
        private ToolStripMenuItem removeCarToolStripMenuItem;
        private ToolStripMenuItem MakeRentalToolStripMenuItem;
        private ToolStripMenuItem cancelRentalToolStripMenuItem;
        private ToolStripMenuItem collectCarToolStripMenuItem;
        private ToolStripMenuItem returnCarToolStripMenuItem;
        private ToolStripMenuItem addEquipmentToolStripMenuItem;
        private ToolStripMenuItem editQuipmentToolStripMenuItem;
        private ToolStripMenuItem removeEquipmentToolStripMenuItem;
        private ToolStripMenuItem MonthlyRevenueAnalysisToolStripMenuItem;
        private ToolStripMenuItem CustomerAnalysisToolStripMenuItem;
        private Button btnConnect;
        private Label lblStatus;
    }
}