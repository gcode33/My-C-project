﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentSys
{
    public partial class frmAddEquipment : Form
    {
        public frmAddEquipment()
        {
            InitializeComponent();
        }

        private void frmAddEquipment_Load(object sender, EventArgs e)
        {
            //get next equipment id 
            txtEquipId.Text = Equipment.getNextEquipID().ToString("0000000000");

            //set the status of the equipment to A for available
            txtStat.Text = "A";

        }


        private void btnAddEquip_Click(object sender, EventArgs e)
        {
            //validation for info entered
            if (txtEquipName.Text.Equals("") || txtEquipName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Equipment name must be entered and must not include digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEquipName.Focus();
                return;
            }
            if (txtEquipDesc.Text.Equals("") || txtEquipDesc.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Description must be entered and must not include digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEquipDesc.Focus();
                return;
            }
            if (txtPrc.Text.Equals("") || !txtPrc.Text.All(char.IsDigit) || txtPrc.Text.StartsWith("-"))
            {
                MessageBox.Show("Cannot enter a negative number and must be a digit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPrc.Focus();
                return;
            }


            //create an instance of equipment and isntanciate with values enterd 
            Equipment equip = new Equipment(Convert.ToInt32(txtEquipId.Text), txtEquipDesc.Text, txtEquipName.Text, Convert.ToDecimal(txtPrc.Text), txtStat.Text);
            
            //invoke the add equipment method to add the equipment to the equpment table
            equip.addEquipment();


            //display confirmation message 
            MessageBox.Show("Equipment has been saved and added to the Equipment file and set to Available", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //reset UI
            txtEquipName.Clear();
            txtEquipDesc.Clear();
            txtPrc.Clear();
            txtEquipId.Clear();
            txtStat.Clear();
        }
    }
}
